//Mateusz Pawlowski. 3D Software Renderer. 2023.

package pkg3d;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.StringTokenizer;
import javax.swing.*;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.image.BufferedImage;

public class R_3D extends JPanel implements Runnable,MouseListener,MouseMotionListener,KeyListener,MouseWheelListener {

    /**
     * @param args the command line arguments
     */
        public JPanel panel;
        
        public JFrame frame = new JFrame("Mateusz Pawlowski. 3D Software Renderer.");
        
        ArrayList<Point3d> vertices=new ArrayList<Point3d>();
        
        static ArrayList<Point3d> vertices_lambo=new ArrayList<Point3d>();
        static ArrayList<Point3d> vertices_gate=new ArrayList<Point3d>();
        ArrayList<Point3d> vertices_enemy=new ArrayList<Point3d>();
        static ArrayList<Point3d> vertices_enemy_d=new ArrayList<Point3d>();
        
        ArrayList<Point3d> vertices_weapon=new ArrayList<Point3d>();
        
        static ArrayList<Point3d> vertices_collision=new ArrayList<Point3d>();
        
        static ArrayList<Point3d> vertices_stairs=new ArrayList<Point3d>();
        
        ArrayList<Point3d> bullets=new ArrayList<Point3d>();
        ArrayList<Point3d> bullets_e=new ArrayList<Point3d>();
        ArrayList<Point3d> additional_vertices=new ArrayList<Point3d>();
        ArrayList<Point3d> vertices_xyz=new ArrayList<Point3d>();
        
        ArrayList<Character> enemies=new ArrayList<Character>();
        
        ArrayList<Lamborghini> cars=new ArrayList<Lamborghini>();
        ArrayList<Gate> gates=new ArrayList<Gate>();
        
        Triangle test_triangle=null;
        Triangle test_triangle_2=null;
        Triangle test_triangle_3=null;
        
        //ArrayList<Point3d> normals=new ArrayList<Point3d>();
        //ArrayList<Integer> normals_index=new ArrayList<Integer>();
        
        ArrayList<Integer> faces=new ArrayList<Integer>();
        static ArrayList<Integer> faces_lambo=new ArrayList<Integer>();
        static ArrayList<Integer> faces_gate=new ArrayList<Integer>();
        ArrayList<Integer> faces_enemy=new ArrayList<Integer>();
        static ArrayList<Integer> faces_enemy_d=new ArrayList<Integer>();
        
        ArrayList<Integer> faces_weapon=new ArrayList<Integer>();
        
        ArrayList<Color> faces_color=new ArrayList<Color>();

        static ArrayList<Triangle> triangles_lambo=new ArrayList<Triangle>();
        static ArrayList<Triangle> triangles_gate=new ArrayList<Triangle>();
        
        static ArrayList<Triangle> triangles_enemy=new ArrayList<Triangle>();
        
        static ArrayList<Triangle> triangles_enemy_standing=new ArrayList<Triangle>();
        static ArrayList<Triangle> triangles_enemy_crouching=new ArrayList<Triangle>();
        
        static ArrayList<Triangle> triangles_enemy_rolling_1=new ArrayList<Triangle>();
        static ArrayList<Triangle> triangles_enemy_rolling_2=new ArrayList<Triangle>();
        static ArrayList<Triangle> triangles_enemy_rolling_3=new ArrayList<Triangle>();
        static ArrayList<Triangle> triangles_enemy_rolling_4=new ArrayList<Triangle>();
        static ArrayList<Triangle> triangles_enemy_rolling_5=new ArrayList<Triangle>();
        
        static ArrayList<Triangle> triangles_enemy_standing_shot=new ArrayList<Triangle>();
        static ArrayList<Triangle> triangles_enemy_standing_reload=new ArrayList<Triangle>();
        
        static ArrayList<Triangle> triangles_enemy_standing_obstacle_shot_2_l=new ArrayList<Triangle>();
        static ArrayList<Triangle> triangles_enemy_standing_obstacle_shot_3_l=new ArrayList<Triangle>();
        static ArrayList<Triangle> triangles_enemy_standing_obstacle_shot_4_l=new ArrayList<Triangle>();
        static ArrayList<Triangle> triangles_enemy_standing_obstacle_shot_5_l=new ArrayList<Triangle>();
        static ArrayList<Triangle> triangles_enemy_standing_obstacle_shot_6_l=new ArrayList<Triangle>();
        
        static ArrayList<Triangle> triangles_enemy_standing_obstacle_shot_2_r=new ArrayList<Triangle>();
        static ArrayList<Triangle> triangles_enemy_standing_obstacle_shot_3_r=new ArrayList<Triangle>();
        static ArrayList<Triangle> triangles_enemy_standing_obstacle_shot_4_r=new ArrayList<Triangle>();
        static ArrayList<Triangle> triangles_enemy_standing_obstacle_shot_5_r=new ArrayList<Triangle>();
        static ArrayList<Triangle> triangles_enemy_standing_obstacle_shot_6_r=new ArrayList<Triangle>();
        //static ArrayList<Triangle> triangles_enemy_d=new ArrayList<Triangle>();
        
        static ArrayList<Triangle> triangles_weapon=new ArrayList<Triangle>();
        
        JButton b1=new JButton("<");
        JButton b2=new JButton(">");
        JButton b5=new JButton("Play");
        JButton b3=new JButton("^");
        JButton b4=new JButton("v");
        
        JButton b6=new JButton("+");
        JButton b7=new JButton("-");
        
        JButton b8=new JButton("WireFrame");
        JButton b9=new JButton("S");
        
        JButton b10=new JButton("1");
        JButton b11=new JButton("2");
        JButton b12=new JButton("3");
        JButton b13=new JButton("4");
        JButton b14=new JButton("5");
        JButton b23=new JButton("6");
        JButton b24=new JButton("F");
        
        
        JButton b15=new JButton("^^");
        JButton b16=new JButton("vv");
        JButton b17=new JButton("<<");
        JButton b18=new JButton(">>");
        
        JButton b19=new JButton("<");
        JButton b20=new JButton(">");
        JButton b21=new JButton("Up");
        JButton b22=new JButton("Down");
        
        static boolean game_mode=true;
        static boolean show_collision=false;
        
        boolean application_running=true;
        boolean load_once=false;
        
        static double cube_angleX=360;
        static double cube_angleY=0;
        boolean change_quater_left=false;
        boolean change_quater_right=false;
        
        public static boolean calculate_lambo=false;
        
        //standard robot 3d mesh
        static boolean robot=true;
        
        double delta=0;
        static boolean shot_anim=false;
        static boolean shot_anim_2=false;
        static int shot_animation=0;
        
        static int shot_counter=0;
        static boolean shot_once=false;
        static boolean shot_pressed=false;
        static boolean forward_pressed=false;
        static boolean backward_pressed=false;
        static boolean left_pressed=false;
        static boolean right_pressed=false;
        
        static int camera=-400;
        static boolean lock_head=false;
        boolean draw_target=true;
        
        double rotate_mesh=0;
        
        int old_mouse_x=0;
        int old_mouse_y=0;
        boolean mouse_pressed=false;
        boolean mouse_2_pressed=false;
        
        boolean play=false;
        
        //int move_scale=70;
        //int move_scale_strafe=2*move_scale;
        //int move_scale=45;
        //int move_scale_strafe=move_scale;
        int move_scale=70;
        int move_scale_strafe=move_scale;
        
        double mouse_speed_x=1;
        double mouse_speed_y=1;
                
        int scale=0;
        
        static Random rn=new Random(System.currentTimeMillis());
        
        Color additional_triangle_color;
        static boolean calculate_normals=true;
          
        static boolean draw_demo=false;
        static boolean tomb_raider=false;
        static boolean tea_pot=false;
        static boolean lamborghini=true;
        static boolean q2dm1=false;
        static boolean crash_bandicoot=false;
        static boolean doom=false;
        static boolean quake=false;
        static boolean quake_standard_shading=true;
        
        static boolean tr_map=false;
        
        static boolean wire_frame=false;
        static boolean set_center=false;
        
        static boolean turn_right=false;
        static boolean turn_left=false;
        
        static boolean turn_up=false;
        static boolean turn_down=false;
        
        int sc=3;
        
        static int triangle_pointer=0;
        
        public static float player_x=0,player_y=0,player_z=0;
        public static float old_player_x=0,old_player_y=0,old_player_z=0;
        
        int robots=0;
        
        public static double energy=100;        
        
        public static boolean elevation_changed=false;
        public static int elevation=0;
        
        double angle=0;
        Graphics g;
        
        public Thread thread;
        
        
        
        
    
    public R_3D()
    {
                /*
                Character enemy=new Character();
                Character enemy_2=new Character();
                Character enemy_3=new Character();
                Character enemy_4=new Character();
                
                enemy_2.move_character(1500,0,0);
                
                enemy_4.move_character(1500,0,3000);
                
                //enemy_3.move_character(1500,0,1500);
                enemy.ai_set=0;
                enemy_2.ai_set=1;
                enemy_4.ai_set=2;
                
                enemy.ai_set=3;
                enemy_2.ai_set=4;
                enemy_4.ai_set=5;
                
                enemies.add(enemy);
                enemies.add(enemy_2);
                enemies.add(enemy_4);
                */
        
                //read .obj file with 3d object
                int count_normals=0;
                
                try{
                BufferedReader bfr=null;
                
                if(lamborghini==true){bfr=new BufferedReader(new FileReader("lamborghini.obj"));}
                
                //if(doom==true){bfr=new BufferedReader(new FileReader("E1M1.obj"));}
                
                if(tr_map==false)
                {
                    if(quake==false)
                    {
                        if(doom==true){bfr=new BufferedReader(new FileReader("new_doom.obj"));}
                        //if(doom==true){bfr=new BufferedReader(new FileReader("guns_fpp.obj"));}
                        
                        //if(doom==true){bfr=new BufferedReader(new FileReader("doom_2.obj"));}
                        
                        //if(doom==true){bfr=new BufferedReader(new FileReader("doom_map_2.obj"));}
                        //if(doom==true){bfr=new BufferedReader(new FileReader("doom_map_3.obj"));}
                    }
                    
                    if(quake==true)
                    {
                        if(doom==true){bfr=new BufferedReader(new FileReader("quake.obj"));}
                        //if(doom==true){bfr=new BufferedReader(new FileReader("quake_test.obj"));}
                    }
                }

                if(tr_map==true)
                {
                    if(doom==true){bfr=new BufferedReader(new FileReader("Tomb_Raider_lv1.obj"));}
                }
                
                //if(doom==true){bfr=new BufferedReader(new FileReader("q2dm1.obj"));}
                //if(lamborghini==true){bfr=new BufferedReader(new FileReader("q2dm1.obj"));}
                
                if(tomb_raider==true){bfr=new BufferedReader(new FileReader("tomb_raider.obj"));}
                
                if(crash_bandicoot==true){bfr=new BufferedReader(new FileReader("crash_bandicoot.obj"));}
                
                
                //if(tomb_raider_2==true){bfr=new BufferedReader(new FileReader("tr_1.obj"));}
                if(tea_pot==true){bfr=new BufferedReader(new FileReader("tea.obj"));}
                
                //loading 3d data of map or object from file
                int count_vertices=0;
                int count_faces=0;
                String linia=bfr.readLine();
                
                while(linia!=null)
                {
                
                
                StringTokenizer st=new StringTokenizer(linia);
                String litera=st.nextToken(" ");
                
                        if(litera.equals("v")){

                        Float vx=Float.parseFloat(st.nextToken(" "));
                        Float vy=Float.parseFloat(st.nextToken(" "));
                        Float vz=Float.parseFloat(st.nextToken(" "));
                        
                        //System.out.println(" "+vx+" "+vy+" "+vz);
                        
                        if(tomb_raider==true)
                        {
                        vertices.add(new Point3d(vx*10,-vy*10,-vz*10));
                        }
                        
                        if(lamborghini==true)
                        {
                        
                        vertices.add(new Point3d(vx*40,-vy*40,-vz*40));
                            //if(q2dm1==false) vertices.add(new Point3d(vx*10,-vy*10,-vz*10));
                            //else {vertices.add(new Point3d(vx*10,-vz*10,-vy*10));}
                        }
                        
                        if(crash_bandicoot==true)
                        {
                        vertices.add(new Point3d(vx*10,-vy*10,-vz*10));
                        }
                        
                        if(tea_pot==true)
                        {
                        vertices.add(new Point3d(vx*10,-vy*10,-vz*10));
                        }
                        
                        if(doom==true)
                        {
                        if(tr_map==true)
                        {
                        vertices.add(new Point3d(vx*300,-vy*300,-vz*300));
                        }
                        
                        if(tr_map==false)
                        {
                            if(quake==true)
                            {
                                vertices.add(new Point3d(vx*2700,-vy*2700,-vz*2700));
                            }
                            if(quake==false){
                                //doom 1
                                //vertices.add(new Point3d(vx*10,-vy*10,-vz*10));
                                
                                
                                //dla doom2
                                //vertices.add(new Point3d(vx*30000,-vy*30000,-vz*30000));
                                //doom 3
                                vertices.add(new Point3d(vx*40,-vy*40,-vz*40));
                            }
                        }
                        
                        }
                        
                        count_vertices++;
                        
                        }
                        
                        
                        if(doom==true&&load_once==false){
                        load_once=true;
                        Point3d pcenter_1=new Point3d(0,0,0);
                        Point3d pcenter_2=new Point3d(150*10,0,0);
                        Point3d pcenter_3=new Point3d(0,-150*10,0);
                        Point3d pcenter_4=new Point3d(0,0,150*10);
                        
                        vertices_xyz.add(pcenter_1);
                        vertices_xyz.add(pcenter_2);
                        vertices_xyz.add(pcenter_3);
                        vertices_xyz.add(pcenter_4);
                        
                        
                        //additional triangle
                        additional_vertices.add(new Point3d(0,0,0));
                        additional_vertices.add(new Point3d(-2500,0,0));
                        additional_vertices.add(new Point3d(-2500,0,0));
                        additional_vertices.add(new Point3d(0,-1000,0));
                        //System.out.println("t");
                        
                        Point3d ttp0=additional_vertices.get(0);
                        Point3d ttp1=additional_vertices.get(1);
                        Point3d ttp2=additional_vertices.get(2);
                        Point3d ttp3=additional_vertices.get(3);
                        
                        ttp0.rotateAxisY(0);ttp0.rotateAxisX(0);ttp0.calculate2dpoint();
                        ttp1.rotateAxisY(0);ttp1.rotateAxisX(0);ttp1.calculate2dpoint();
                        ttp2.rotateAxisY(0);ttp2.rotateAxisX(0);ttp2.calculate2dpoint();
                        ttp3.rotateAxisY(0);ttp3.rotateAxisX(0);ttp3.calculate2dpoint();
                        
                        additional_vertices.add(new Point3d(0,0,0));
                        additional_vertices.add(new Point3d(0,0,-2500));
                        additional_vertices.add(new Point3d(0,0,-2500));
                        additional_vertices.add(new Point3d(0,-1000,0));
                        //System.out.println("t");
                        
                        Point3d ttp4=additional_vertices.get(4);
                        Point3d ttp5=additional_vertices.get(5);
                        Point3d ttp6=additional_vertices.get(6);
                        Point3d ttp7=additional_vertices.get(7);
                        
                        ttp4.rotateAxisY(0);ttp4.rotateAxisX(0);ttp4.calculate2dpoint();
                        ttp5.rotateAxisY(0);ttp5.rotateAxisX(0);ttp5.calculate2dpoint();
                        ttp6.rotateAxisY(0);ttp6.rotateAxisX(0);ttp6.calculate2dpoint();
                        ttp7.rotateAxisY(0);ttp7.rotateAxisX(0);ttp7.calculate2dpoint();
                        
                        test_triangle_2=new Triangle(additional_vertices.get(0),additional_vertices.get(1),additional_vertices.get(2),additional_vertices.get(3));
                        test_triangle_3=new Triangle(additional_vertices.get(4),additional_vertices.get(5),additional_vertices.get(6),additional_vertices.get(7));
                        }
                        
                        
                        
                        //osobny fragment dla lamborghini
                         
                         //System.out.println(linia);
                         if(lamborghini==true||tea_pot==true||doom==true)
                         {
                                if(litera.equals("f"))
                                {
                                //System.out.println(linia);
                                
                                String t1=st.nextToken(" ");
                                String t2=st.nextToken(" ");
                                String t3=st.nextToken(" ");
                                
                                String t4=null;
                                try{
                                    t4=st.nextToken(" ");
                                }catch(Exception exc){}



                                StringTokenizer st_1=new StringTokenizer(t1);
                                String l=st_1.nextToken("//");
                                
                                StringTokenizer st_2=new StringTokenizer(t2);
                                String ll=st_2.nextToken("//");
                                
                                StringTokenizer st_3=new StringTokenizer(t3);
                                String lll=st_3.nextToken("//");
                                
                                //System.out.println(""+t4);
                                
                                if(t4==null)
                                {
                                //System.out.println(" "+l+" "+ll+" "+lll);
                                }
                                
                                
                                String llll="";
                                if(t4!=null)
                                {
                                StringTokenizer st_4=new StringTokenizer(t4);
                                llll=st_4.nextToken("//");
                                //System.out.println(" "+l+" "+ll+" "+lll+" "+llll);
                                }
                                
                                
                                int t_1=Integer.parseInt(l);
                                int t_2=Integer.parseInt(ll);
                                int t_3=Integer.parseInt(lll);

                                Integer t_4=null;
                                if(t4!=null)
                                {
                                t_4=Integer.parseInt(llll);
                                }


                                faces.add(t_1);
                                faces.add(t_2);
                                faces.add(t_3);
                                
                                
                                int rgb=rn.nextInt(8)+0;
                                
                                Color color_1=new Color(188,63,0);
                                Color color_2=new Color(130,114,99);
                                Color color_3=new Color(115,93,81);
                                Color color_4=new Color(83,65,50);
                                Color color_5=new Color(133,116,93);
                                Color color_6=new Color(46,37,29);
                                Color color_7=new Color(42,37,21);
                                Color color_8=new Color(41,31,24);
                                Color color_9=new Color(24,20,13);
                                
                                
                                //int rgb_r=rn.nextInt(180)+50;
                                int rgb_r=rn.nextInt(50)+200;
                                
                                color_1=new Color(0,rgb_r,0);
                                color_2=new Color(0,rgb_r,0);
                                color_3=new Color(0,rgb_r,0);
                                color_4=new Color(0,rgb_r,0);
                                color_5=new Color(0,rgb_r,0);
                                color_6=new Color(0,rgb_r,0);
                                color_7=new Color(0,rgb_r,0);
                                color_8=new Color(0,rgb_r,0);
                                color_9=new Color(0,rgb_r,0);
                                /*
                                color_1=new Color(0,0,rgb_r);
                                color_2=new Color(0,0,rgb_r);
                                color_3=new Color(0,0,rgb_r);
                                color_4=new Color(0,0,rgb_r);
                                color_5=new Color(0,0,rgb_r);
                                color_6=new Color(0,0,rgb_r);
                                color_7=new Color(0,0,rgb_r);
                                color_8=new Color(0,0,rgb_r);
                                color_9=new Color(0,0,rgb_r);
                                */
                                
                                color_1=new Color(rgb_r,rgb_r,rgb_r);
                                color_2=new Color(rgb_r,rgb_r,rgb_r);
                                color_3=new Color(rgb_r,rgb_r,rgb_r);
                                color_4=new Color(rgb_r,rgb_r,rgb_r);
                                color_5=new Color(rgb_r,rgb_r,rgb_r);
                                color_6=new Color(rgb_r,rgb_r,rgb_r);
                                color_7=new Color(rgb_r,rgb_r,rgb_r);
                                color_8=new Color(rgb_r,rgb_r,rgb_r);
                                color_9=new Color(rgb_r,rgb_r,rgb_r);
                                
                                if(rgb==0)
                                {
                                faces_color.add(color_1);
                                faces_color.add(color_1);
                                faces_color.add(color_1);
                                }
                                if(rgb==1)
                                {
                                faces_color.add(color_2);
                                faces_color.add(color_2);
                                faces_color.add(color_2);
                                }
                                if(rgb==2)
                                {
                                faces_color.add(color_3);
                                faces_color.add(color_3);
                                faces_color.add(color_3);
                                }
                                if(rgb==3)
                                {
                                faces_color.add(color_4);
                                faces_color.add(color_4);
                                faces_color.add(color_4);
                                }
                                if(rgb==4)
                                {
                                faces_color.add(color_5);
                                faces_color.add(color_5);
                                faces_color.add(color_5);
                                }
                                if(rgb==5)
                                {
                                faces_color.add(color_6);
                                faces_color.add(color_6);
                                faces_color.add(color_6);
                                }
                                if(rgb==6)
                                {
                                faces_color.add(color_7);
                                faces_color.add(color_7);
                                faces_color.add(color_7);
                                }
                                if(rgb==7)
                                {
                                faces_color.add(color_8);
                                faces_color.add(color_8);
                                faces_color.add(color_8);
                                }
                                if(rgb==8)
                                {
                                faces_color.add(color_9);
                                faces_color.add(color_9);
                                faces_color.add(color_9);
                                }
                                
                               //faces_color.add(new Color(0,rn.nextInt(255),rn.nextInt(255)));
                               //faces_color.add(new Color(0,rn.nextInt(255),rn.nextInt(255)));
                                
                                if(t4!=null)
                                {
                                faces.add(t_4);
                                        if(rgb==0)
                                        {
                                        faces_color.add(color_1);
                                        }
                                        if(rgb==1)
                                        {
                                        faces_color.add(color_2);
                                        }
                                        if(rgb==2)
                                        {
                                        faces_color.add(color_3);
                                        }
                                        if(rgb==3)
                                        {
                                        faces_color.add(color_4);
                                        }
                                        if(rgb==4)
                                        {
                                        faces_color.add(color_5);
                                        }
                                        if(rgb==5)
                                        {
                                        faces_color.add(color_6);
                                        }
                                        if(rgb==6)
                                        {
                                        faces_color.add(color_7);
                                        }
                                        if(rgb==7)
                                        {
                                        faces_color.add(color_8);
                                        }
                                        if(rgb==8)
                                        {
                                        faces_color.add(color_9);
                                        }
                                } else 
                                    {
                                        faces.add(null);
                                        if(rgb==0)
                                        {
                                        faces_color.add(color_1);
                                        }
                                        if(rgb==1)
                                        {
                                        faces_color.add(color_2);
                                        }
                                        if(rgb==2)
                                        {
                                        faces_color.add(color_3);
                                        }
                                        if(rgb==3)
                                        {
                                        faces_color.add(color_4);
                                        }
                                        if(rgb==4)
                                        {
                                        faces_color.add(color_5);
                                        }
                                        if(rgb==5)
                                        {
                                        faces_color.add(color_6);
                                        }
                                        if(rgb==6)
                                        {
                                        faces_color.add(color_7);
                                        }
                                        if(rgb==7)
                                        {
                                        faces_color.add(color_8);
                                        }
                                        if(rgb==8)
                                        {
                                        faces_color.add(color_9);
                                        }
                                    }
                                
                                count_faces++;
                                }
                         }       
                         //osobny fragment dla lamborghini
                        
                        if(lamborghini==false&&tea_pot==false&&doom==false){
                                if(litera.equals("f"))
                                {
                                //System.out.println(linia);

                                String t1=st.nextToken(" ");
                                String t2=st.nextToken(" ");
                                String t3=st.nextToken(" ");





                                StringTokenizer st_1=new StringTokenizer(t1);
                                String l=st_1.nextToken("//");
                                String ll=st_1.nextToken("//");
                                if(crash_bandicoot==true) ll=st_1.nextToken("//");

                                StringTokenizer st_2=new StringTokenizer(t2);
                                String l2=st_2.nextToken("//");
                                String ll2=st_2.nextToken("//");
                                if(crash_bandicoot==true) ll2=st_2.nextToken("//");

                                StringTokenizer st_3=new StringTokenizer(t3);
                                String l3=st_3.nextToken("//");
                                String ll3=st_3.nextToken("//");
                                if(crash_bandicoot==true) ll3=st_3.nextToken("//");

                                String l4="";
                                String t4="";
                                String ll4="";

                                if(st.hasMoreTokens()){
                                t4=st.nextToken(" ");
                                StringTokenizer st_4=new StringTokenizer(t4);
                                l4=st_4.nextToken("//"); 
                                ll4=st_4.nextToken("//");
                                }
                        
                                //System.out.println(t1+" "+t2+" "+t3+" "+t4+" ");

                                //System.out.println(l+" "+l2+" "+l3+" "+l4);

                                //System.out.println(ll+" "+ll2+" "+ll3+" "+ll4);

                                int normal_ind=Integer.parseInt(ll);
                                //normals_index.add(normal_ind);

                                int t_1=Integer.parseInt(l);
                                int t_2=Integer.parseInt(l2);
                                int t_3=Integer.parseInt(l3);




                                faces.add(t_1);
                                faces.add(t_2);
                                faces.add(t_3);

                                    if(l4.equals("")!=true){
                                        int t_4=Integer.parseInt(l4);
                                        faces.add(t_4);
                                    }
                                count_faces++;
                        }
                                
                         
                                
                        }
                linia=bfr.readLine();
                }
                
                
                System.out.println("Vertices "+count_vertices);
                System.out.println("Faces "+count_faces);
                
                
                
                bfr.close();
                }catch(Exception exc){System.out.println("Exception "+exc);}
                //loading file 3d data of map or object from file
                
                
                //loading enemy 3d data
                try{
                    
                BufferedReader bfr=null;
                if(robot==true){
                    bfr=new BufferedReader(new FileReader("enemy_3d_s.obj"));
                }
                else
                {
                    bfr=new BufferedReader(new FileReader("crash_bandicoot_low_poly.obj"));
                }
                
                int count_vertices=0;
                int count_faces=0;
                String linia=bfr.readLine();
                
                while(linia!=null)
                {
                
                
                StringTokenizer st=new StringTokenizer(linia);
                String litera=st.nextToken(" ");
                
                        if(litera.equals("v")){

                        Float vx=Float.parseFloat(st.nextToken(" "));
                        Float vy=Float.parseFloat(st.nextToken(" "));
                        Float vz=Float.parseFloat(st.nextToken(" "));
                        
                        //System.out.println(" "+vx+" "+vy+" "+vz);
                        if(doom==true){
                        //if(crash_bandicoot==true)
                                if(robot==false){
                                    vertices_enemy.add(new Point3d(vx*10,-vy*10,-vz*10));
                                }
                                
                                if(robot==true){
                                    vertices_enemy.add(new Point3d(vx*500,-vy*500,-vz*500));
                                }
                        }
                        //}
                        count_vertices++;
                        }
                        
                        if(doom==true){
                                //crash_bandicoot=true;
                                if(litera.equals("f"))
                                {
                                //System.out.println(linia);

                                String t1=st.nextToken(" ");
                                String t2=st.nextToken(" ");
                                String t3=st.nextToken(" ");

                                
                                
                                String t4=null;
                                
                                if(st.hasMoreTokens()){
                                t4=st.nextToken(" ");
                                //StringTokenizer st_4=new StringTokenizer(t4);
                                //l4=st_4.nextToken("//"); 
                                //ll4=st_4.nextToken("//");
                                }
                                
                                //System.out.println("t1="+t1+" t2="+t2+" t3="+t3+" t4="+t4);
                                
                                
                                /*
                                StringTokenizer st_1=new StringTokenizer(t1);
                                String l=st_1.nextToken("//");
                                String ll=st_1.nextToken("//");
                                if(crash_bandicoot==true) ll=st_1.nextToken("//");

                                StringTokenizer st_2=new StringTokenizer(t2);
                                String l2=st_2.nextToken("//");
                                String ll2=st_2.nextToken("//");
                                if(crash_bandicoot==true) ll2=st_2.nextToken("//");

                                StringTokenizer st_3=new StringTokenizer(t3);
                                String l3=st_3.nextToken("//");
                                String ll3=st_3.nextToken("//");
                                if(crash_bandicoot==true) ll3=st_3.nextToken("//");

                                String l4="";
                                String t4="";
                                String ll4="";

                                if(st.hasMoreTokens()){
                                t4=st.nextToken(" ");
                                StringTokenizer st_4=new StringTokenizer(t4);
                                l4=st_4.nextToken("//"); 
                                ll4=st_4.nextToken("//");
                                }
                                */
                                //System.out.println(t1+" "+t2+" "+t3+" "+t4+" ");

                                //System.out.println(l+" "+l2+" "+l3+" "+l4);

                                //System.out.println(ll+" "+ll2+" "+ll3+" "+ll4);

                                //int normal_ind=Integer.parseInt(ll);
                                //normals_index.add(normal_ind);

                                //int t_1=Integer.parseInt(l);
                                //int t_2=Integer.parseInt(l2);
                                //int t_3=Integer.parseInt(l3);

                                int t_1=Integer.parseInt(t1);
                                int t_2=Integer.parseInt(t2);
                                int t_3=Integer.parseInt(t3);



                                faces_enemy.add(t_1);
                                faces_enemy.add(t_2);
                                faces_enemy.add(t_3);
                                
                                if(t4!=null){
                                int t_4=Integer.parseInt(t4);
                                faces_enemy.add(t_4);
                                }
                                
                                if(t4==null){faces_enemy.add(null);}
                                
                                /*
                                    if(l4.equals("")!=true){
                                        int t_4=Integer.parseInt(l4);
                                        faces_enemy.add(t_4);
                                    }
                                */
                                count_faces++;
                        }
                                
                         
                                
                        }
                linia=bfr.readLine();
                }
                
                System.out.println("Vertices "+count_vertices);
                System.out.println("Faces "+count_faces);
                
                //crash_bandicoot=false;
                
                bfr.close();
                }catch(Exception exc){System.out.println("Exception "+exc);}
                //loading enemy 3d data
                
                //loading weapon 3d data
                try{
                    
                //BufferedReader bfr=new BufferedReader(new FileReader("guns_fpp_q.obj"));
                BufferedReader bfr=new BufferedReader(new FileReader("guns3.obj"));
                
                int count_vertices=0;
                int count_faces=0;
                String linia=bfr.readLine();
                
                while(linia!=null)
                {
                
                
                StringTokenizer st=new StringTokenizer(linia);
                String litera=st.nextToken(" ");
                
                        if(litera.equals("v")){

                        Float vx=Float.parseFloat(st.nextToken(" "));
                        Float vy=Float.parseFloat(st.nextToken(" "));
                        Float vz=Float.parseFloat(st.nextToken(" "));
                        
                        //System.out.println(" "+vx+" "+vy+" "+vz);
                        if(doom==true){
                                    vertices_weapon.add(new Point3d(vx*8,-vy*8,-vz*8+22));
                        }
                        
                        count_vertices++;
                        }
                        
                        if(doom==true){
                                
                                if(litera.equals("f"))
                                {
                                //System.out.println(linia);

                                String t1=st.nextToken(" ");
                                String t2=st.nextToken(" ");
                                String t3=st.nextToken(" ");

                                
                                
                                String t4=null;
                                
                                if(st.hasMoreTokens()){
                                t4=st.nextToken(" ");
                               
                                }
                                
                                

                                int t_1=Integer.parseInt(t1);
                                int t_2=Integer.parseInt(t2);
                                int t_3=Integer.parseInt(t3);



                                faces_weapon.add(t_1);
                                faces_weapon.add(t_2);
                                faces_weapon.add(t_3);
                                
                                if(t4!=null){
                                int t_4=Integer.parseInt(t4);
                                faces_weapon.add(t_4);
                                }
                                
                                if(t4==null){faces_weapon.add(null);}
                                
                                /*
                                    if(l4.equals("")!=true){
                                        int t_4=Integer.parseInt(l4);
                                        faces_enemy.add(t_4);
                                    }
                                */
                                count_faces++;
                        }
                                
                         
                                
                        }
                linia=bfr.readLine();
                }
                
                System.out.println("Vertices "+count_vertices);
                System.out.println("Faces "+count_faces);
                
                //crash_bandicoot=false;
                
                bfr.close();
                }catch(Exception exc){System.out.println("Exception "+exc);}
                //loading weapon 3d data
                
                //creatin trianles list for enemy 3d mesh crash bandicoot
                if(doom==true){
                
                for(Point3d p:vertices_enemy)
                {
                    p.rotateAxisY(0);
                    p.rotateAxisX(0);
                }    
                
                for(Point3d p:vertices_weapon)
                {
                    p.rotateAxisY(0);
                    p.rotateAxisX(0);
                }    
                    
                int q=0;
                
                int fn=0;
                
                if(robot==false) fn=2596;
                if(robot==true) fn=1232;
                //for(int i=0;i<2196;i++)
                for(int i=0;i<fn;i++)
                {
                   
                    q++;
                    
                    int w1=faces_enemy.get(i);
                    i++;
                    int w2=faces_enemy.get(i);
                    i++;
                    int w3=faces_enemy.get(i);
                    i++;
                    Integer w4=faces_enemy.get(i);
                    
                    if(w4==null){

                    Point3d p1=vertices_enemy.get(w1-1);
                    Point3d p2=vertices_enemy.get(w2-1);
                    Point3d p3=vertices_enemy.get(w3-1);
                    //Point3d p4=vertices.get(w4-1);
                    Triangle t=new Triangle(p1,p2,p3);
                    t.tr_color=new Color(30,30,30);
                    
                    triangles_enemy.add(t);
                    }
                    
                    if(w4!=null){

                    Point3d p1=vertices_enemy.get(w1-1);
                    Point3d p2=vertices_enemy.get(w2-1);
                    Point3d p3=vertices_enemy.get(w3-1);
                    Point3d p4=vertices_enemy.get(w4-1);
                    Triangle t=new Triangle(p1,p2,p3,p4);
                    t.tr_color=new Color(50,50,50);
                    
                    triangles_enemy.add(t);
                    }
                    
                }
                
                //creating triangles for gun
                for(int i=0;i<672;i++)
                {
                   
                    q++;
                    
                    int w1=faces_weapon.get(i);
                    i++;
                    int w2=faces_weapon.get(i);
                    i++;
                    int w3=faces_weapon.get(i);
                    i++;
                    Integer w4=faces_weapon.get(i);
                    
                    if(w4==null){

                    Point3d p1=vertices_weapon.get(w1-1);
                    Point3d p2=vertices_weapon.get(w2-1);
                    Point3d p3=vertices_weapon.get(w3-1);
                    //Point3d p4=vertices.get(w4-1);
                    Triangle t=new Triangle(p1,p2,p3);
                    t.tr_color=new Color(30,30,30);
                    
                    triangles_weapon.add(t);
                    }
                    
                    if(w4!=null){

                    Point3d p1=vertices_weapon.get(w1-1);
                    Point3d p2=vertices_weapon.get(w2-1);
                    Point3d p3=vertices_weapon.get(w3-1);
                    Point3d p4=vertices_weapon.get(w4-1);
                    Triangle t=new Triangle(p1,p2,p3,p4);
                    t.tr_color=new Color(50,50,50);
                    
                    triangles_weapon.add(t);
                    }
                    
                }
                //creating triangles for gun
                
                }
                //System.out.println(triangles_enemy.size());
                
                //System.exit(1);
                
                for(Point3d p:vertices)
                {
                    p.rotateAxisY(0);
                    p.rotateAxisX(0);
                    //p.moveVectorOriginal(-200,20,0);
                    
                    if(lamborghini==true){p.moveVectorOriginal(-300,0,0);}
                    //dla doom
                    
                    //player start position
                    //player_x=9300 player_z=-33000
                    //if(doom==true){p.moveVectorOriginal(0,-3000,0);}
                    if(tr_map==false){
                        if(doom==true)
                        {
                            if(quake==false)
                            {
                            //p.moveVectorOriginal(300+900,-2100,3000+600);this.cube_angleY=90;
                                p.moveVectorOriginal(40000,-2100+600,-130000);this.cube_angleY=90;
                            }
                            
                            if(quake==true)
                            {
                                p.moveVectorOriginal(-74650,-1900+5400,-50000);this.cube_angleY=360;
                            }
                            //this.cube_angleY=270;
                        }
                    }
                    if(tr_map==true)
                    {
                        //player_x=22351.577565500153 player_z=-33412.39124283574
                        if(doom==true){p.moveVectorOriginal(-12600,-3100,1100);this.cube_angleY=180;}
                    }
                    
                    //dla q2dm1
                    //if(lamborghini==true){p.moveVectorOriginal(300,0,0);}
                    
                    //if(tomb_raider==true){p.moveVectorOriginal(0,400,300);}
                    //if(crash_bandicoot==true){p.moveVector(0,0,0);}
                }
                        
                if(doom==true){
                        for(Point3d p:vertices_xyz)
                        {
                            
                            p.rotateAxisY(0);
                            p.rotateAxisX(0);
                            //p.moveVectorOriginal(-200,20,0);

                            //player start position
                            //player_x=9300 player_z=-33000
                            if(doom==true){p.moveVectorOriginal(0,-2100,0);}
                            if(tr_map==true){p.moveVectorOriginal(-2600,-2100,1500);}
                            //if(doom==true){p.moveVectorOriginal(0,-2100,0);}
                            //if(doom==true){p.moveVectorOriginal(9300,-2100,-33000);}
                        }
                        
                        for(Point3d p:additional_vertices)
                        {
                            p.rotateAxisY(0);
                            p.rotateAxisX(0);
                            if(doom==true){p.moveVectorOriginal(0,-2100,0);}
                            if(tr_map==true){p.moveVectorOriginal(-2600,-2100,1500);}
                        }
                        
                       //loading enemy crouching 3d data using method
                       
                }
                
                R_3D.triangles_gate=load_3d_object_gate("gate.obj");
                
                R_3D.triangles_lambo=load_3d_object_lamborghini("lambo_2.obj");
                
                R_3D.triangles_enemy_crouching=load_3d_object("enemy_3d_d.obj"); 
                R_3D.triangles_enemy_standing=load_3d_object("enemy_3d_s.obj"); 
                
                R_3D.triangles_enemy_standing_shot=load_3d_object("enemy_s_shot_1.obj"); 
                R_3D.triangles_enemy_standing_reload=load_3d_object("enemy_s_shot_2.obj"); 
                
                R_3D.triangles_enemy_rolling_1=load_3d_object("enemy_rolling_3.obj"); 
                R_3D.triangles_enemy_rolling_2=load_3d_object("enemy_rolling_4.obj"); 
                R_3D.triangles_enemy_rolling_3=load_3d_object("enemy_rolling_5.obj"); 
                R_3D.triangles_enemy_rolling_4=load_3d_object("enemy_rolling_6.obj"); 
                R_3D.triangles_enemy_rolling_5=load_3d_object("enemy_rolling_7.obj"); 
                
                R_3D.triangles_enemy_standing_obstacle_shot_2_l=load_3d_object("l_5.obj"); 
                R_3D.triangles_enemy_standing_obstacle_shot_3_l=load_3d_object("l_4.obj"); 
                R_3D.triangles_enemy_standing_obstacle_shot_4_l=load_3d_object("l_3.obj"); 
                R_3D.triangles_enemy_standing_obstacle_shot_5_l=load_3d_object("l_2.obj"); 
                R_3D.triangles_enemy_standing_obstacle_shot_6_l=load_3d_object("l_1.obj"); 
                        
                R_3D.triangles_enemy_standing_obstacle_shot_2_r=load_3d_object("r_5.obj"); 
                R_3D.triangles_enemy_standing_obstacle_shot_3_r=load_3d_object("r_4.obj"); 
                R_3D.triangles_enemy_standing_obstacle_shot_4_r=load_3d_object("r_3.obj"); 
                R_3D.triangles_enemy_standing_obstacle_shot_5_r=load_3d_object("r_2.obj"); 
                R_3D.triangles_enemy_standing_obstacle_shot_6_r=load_3d_object("r_1.obj"); 
                
                load_collision("collision.obj");
                load_stairs("stairs.obj");
                
                //load_collision("doom_cube_collision.obj");
                
                Lamborghini lambo_1=new Lamborghini();
                lambo_1.gate_color=new Color(0,200,0);
                //lambo_1.move_character(-14000,1100,-15000);
                lambo_1.move_character(-10000,2100,0);
                lambo_1.angle_Y=0;
                lambo_1.angle_X=0;
                cars.add(lambo_1);
                        
                Gate gate_1=new Gate();
                gate_1.gate_color=new Color(0,200,0);
                gate_1.move_character(-14000,1100,-15000);
                gate_1.angle_Y=0;
                gate_1.angle_X=0;
                gates.add(gate_1);
                
                Gate gate_2=new Gate();
                gate_2.gate_color=new Color(0,200,0);
                gate_2.move_character(-60000,1100,-22800+500);
                gate_2.angle_Y=90;
                gate_2.angle_X=0;
                gates.add(gate_2);
                
                Gate gate_3=new Gate();
                gate_3.gate_color=new Color(0,200,0);
                gate_3.move_character(-83500+500,2100,16800+500);
                gate_3.angle_Y=0;
                gate_3.angle_X=0;
                gates.add(gate_3);
                
                Gate gate_4=new Gate();
                gate_4.gate_color=new Color(0,0,255);
                gate_4.move_character(-83500,2100,56800);
                gate_4.angle_Y=0;
                gate_4.angle_X=0;
                gates.add(gate_4);
                
                Character enemy=new Character();
                Character enemy_2=new Character();
                Character enemy_3=new Character();
                Character enemy_4=new Character();
                
                enemy_2.move_character(1500,0,0);
                
                enemy_4.move_character(1500,0,3000);
                
                //enemy_3.move_character(1500,0,1500);
                enemy.ai_set=0;
                enemy_2.ai_set=1;
                enemy_4.ai_set=2;
                
                enemy.ai_set=3;
                enemy_2.ai_set=4;
                enemy_4.ai_set=5;
                
                enemies.add(enemy);
                //enemies.add(enemy_2);
                //enemies.add(enemy_4);

    if(game_mode==false){
    this.add(b1);
    this.add(b2);
    this.add(b5);
    this.add(b3);
    this.add(b4);
    
    
    this.add(b6);
    this.add(b7);
    
    this.add(b8);
    this.add(b9);
    
    this.add(b10);
    this.add(b11);
    this.add(b12);
    
    
    
    if(doom==false)
    {
    this.add(b13);
    this.add(b14);
    this.add(b23);
    this.add(b24);
    }
    
    if(doom==true)
    {
    this.add(b13);
    this.add(b14);
    
    this.add(b15);
    this.add(b16);
    this.add(b17);
    this.add(b18);
    this.add(b19);
    this.add(b20);
    this.add(b21);
    this.add(b22);
    
    this.add(b23);
    
    this.add(b24);
    }
    }
    
    b1.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        rotateLeft();
        }
    
    });
    
    b2.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        rotateRight();
        }
    
    });
    
    b3.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        rotateUp();
        }
    
    });
    
    b4.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        rotateDown();
        }
    
    });
    
    b5.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        play();
        }
    
    });
    
    
    b6.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
            scale=scale-100;
        }
    
    });
    
    b7.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
            scale=scale+100;
        }
    
    });
    
    b8.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
            wire_frame=true;
        }
    
    });
    
    b9.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
            wire_frame=false;
        }
    
    });
    
    b10.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        crash_bandicoot=true;
        lamborghini=false;
        tomb_raider=false;
        tea_pot=false;
        doom=false;
        tr_map=false;
        reload_application();
        }
    
    });
    
    b11.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        crash_bandicoot=false;
        lamborghini=false;
        tomb_raider=true;
        tea_pot=false;
        doom=false;
        tr_map=false;
        reload_application();    
        }
    
    });
    
    b12.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        crash_bandicoot=false;
        lamborghini=true;
        tomb_raider=false;
        tea_pot=false;
        doom=false;
        tr_map=false;
        reload_application();        
        }
    
    });
    
    b13.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        crash_bandicoot=false;
        lamborghini=false;
        tomb_raider=false;
        tea_pot=true;
        doom=false;
        tr_map=false;
        reload_application();        
        }
    
    });
    
    b14.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        crash_bandicoot=false;
        lamborghini=false;
        tomb_raider=false;
        tea_pot=false;
        tr_map=false;
        doom=true;
        
        //if(quake==false) quake=true; else quake=false;
        
        change_quater_left=false;
        change_quater_right=false;
        
        calculate_normals=false;
        reload_application();        
        }
    
    });
    
    b23.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        crash_bandicoot=false;
        lamborghini=false;
        tomb_raider=false;
        tea_pot=false;
        doom=true;
        tr_map=true;
        
        change_quater_left=false;
        change_quater_right=false;
    
        reload_application();    
        }
    });
    
    
    //sterownie dla doom
    b15.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        
        System.out.println("^^");
        
        go_forward();
        }
    });
    
    b16.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        
        System.out.println("vv");
        
        go_backward();
        }
    });
     
     
    b17.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        System.out.println("<<");
        
        strafe_Left();
        }
    });
    
    b18.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        System.out.println(">>");
        
        strafe_Right();
        }
    });
    
    b21.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        up();
        }
    });
    
    b22.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        down();
        }
    });
    
    b24.addActionListener(new ActionListener()
    {
        @Override
        public void actionPerformed(ActionEvent ae) {
        if(calculate_normals==true) calculate_normals=false; else calculate_normals=true;
        }
    });
    
    this.addMouseMotionListener(this);
    this.addMouseListener(this);
    this.addKeyListener(this);
    this.addMouseWheelListener(this);
    
    setFocusable(true);
    setFocusTraversalKeysEnabled(false);
    }
    
    public static ArrayList<Triangle> load_3d_object(String file_name)
    {
    //loading enemy 3d data method
        
                vertices_enemy_d=new ArrayList<Point3d>();
                faces_enemy_d=new ArrayList<Integer>();
                ArrayList<Triangle> triangles_enemy_d=new ArrayList<Triangle>();
                
                try{
                
                    BufferedReader bfr=null;
                
                    //bfr=new BufferedReader(new FileReader("enemy_3d_d.obj"));
                    bfr=new BufferedReader(new FileReader(file_name));
                
                int count_vertices=0;
                int count_faces=0;
                String linia=bfr.readLine();
                
                while(linia!=null)
                {
                
                
                StringTokenizer st=new StringTokenizer(linia);
                String litera=st.nextToken(" ");
                
                        if(litera.equals("v")){

                        Float vx=Float.parseFloat(st.nextToken(" "));
                        Float vy=Float.parseFloat(st.nextToken(" "));
                        Float vz=Float.parseFloat(st.nextToken(" "));
                        
                        //System.out.println(" "+vx+" "+vy+" "+vz);
                        if(doom==true){
                                    vertices_enemy_d.add(new Point3d(vx*500,-vy*500,-vz*500));
                        }
                        //}
                        count_vertices++;
                        }
                        
                        if(doom==true){
                                
                                if(litera.equals("f"))
                                {
                                //System.out.println(linia);

                                String t1=st.nextToken(" ");
                                String t2=st.nextToken(" ");
                                String t3=st.nextToken(" ");

                                
                                
                                String t4=null;
                                
                                if(st.hasMoreTokens()){
                                t4=st.nextToken(" ");
                                }
                                
                                //System.out.println("t1="+t1+" t2="+t2+" t3="+t3+" t4="+t4);
                                
                                int t_1=Integer.parseInt(t1);
                                int t_2=Integer.parseInt(t2);
                                int t_3=Integer.parseInt(t3);

                                faces_enemy_d.add(t_1);
                                faces_enemy_d.add(t_2);
                                faces_enemy_d.add(t_3);
                                
                                if(t4!=null){
                                int t_4=Integer.parseInt(t4);
                                faces_enemy_d.add(t_4);
                                }
                                
                                if(t4==null){faces_enemy_d.add(null);}
                                
                                /*
                                    if(l4.equals("")!=true){
                                        int t_4=Integer.parseInt(l4);
                                        faces_enemy.add(t_4);
                                    }
                                */
                                count_faces++;
                        }
                                
                         
                                
                        }
                linia=bfr.readLine();
                }
                
                System.out.println("Vertices "+count_vertices);
                System.out.println("Faces "+count_faces);
                
                bfr.close();
                }catch(Exception exc){System.out.println("Exception "+exc);}
                //loading enemy 3d data method
                
                
                if(doom==true){
                for(Point3d p:vertices_enemy_d)
                {
                    p.rotateAxisY(0);
                    p.rotateAxisX(0);
                }    
                
                int q=0;
                int fn=1232;
                //for(int i=0;i<2196;i++)
                for(int i=0;i<fn;i++)
                {
                   
                    q++;
                    
                    int w1=faces_enemy_d.get(i);
                    i++;
                    int w2=faces_enemy_d.get(i);
                    i++;
                    int w3=faces_enemy_d.get(i);
                    i++;
                    Integer w4=faces_enemy_d.get(i);
                    
                    if(w4==null){

                    Point3d p1=vertices_enemy_d.get(w1-1);
                    Point3d p2=vertices_enemy_d.get(w2-1);
                    Point3d p3=vertices_enemy_d.get(w3-1);
                    //Point3d p4=vertices.get(w4-1);
                    Triangle t=new Triangle(p1,p2,p3);
                    t.tr_color=new Color(30,30,30);
                    
                    triangles_enemy_d.add(t);
                    }
                    
                    if(w4!=null){

                    Point3d p1=vertices_enemy_d.get(w1-1);
                    Point3d p2=vertices_enemy_d.get(w2-1);
                    Point3d p3=vertices_enemy_d.get(w3-1);
                    Point3d p4=vertices_enemy_d.get(w4-1);
                    Triangle t=new Triangle(p1,p2,p3,p4);
                    t.tr_color=new Color(50,50,50);
                    
                    triangles_enemy_d.add(t);
                    }
                    }
                }
                return triangles_enemy_d;
    }
    
    public static ArrayList<Triangle> load_3d_object_gate(String file_name)
    {
    //loading enemy 3d data method
        
                vertices_gate=new ArrayList<Point3d>();
                faces_gate=new ArrayList<Integer>();
                ArrayList<Triangle> triangles_gate_d=new ArrayList<Triangle>();
                
                try{
                
                    BufferedReader bfr=null;
                
                    //bfr=new BufferedReader(new FileReader("enemy_3d_d.obj"));
                    bfr=new BufferedReader(new FileReader(file_name));
                
                int count_vertices=0;
                int count_faces=0;
                String linia=bfr.readLine();
                
                while(linia!=null)
                {
                
                
                StringTokenizer st=new StringTokenizer(linia);
                String litera=st.nextToken(" ");
                
                        if(litera.equals("v")){

                        Float vx=Float.parseFloat(st.nextToken(" "));
                        Float vy=Float.parseFloat(st.nextToken(" "));
                        Float vz=Float.parseFloat(st.nextToken(" "));
                        
                        //System.out.println(" "+vx+" "+vy+" "+vz);
                        if(doom==true){
                                    vertices_gate.add(new Point3d(vx*500,-vy*500,-vz*500));
                        }
                        //}
                        count_vertices++;
                        }
                        
                        if(doom==true){
                                
                                if(litera.equals("f"))
                                {
                                //System.out.println(linia);

                                String t1=st.nextToken(" ");
                                String t2=st.nextToken(" ");
                                String t3=st.nextToken(" ");

                                
                                
                                String t4=null;
                                
                                if(st.hasMoreTokens()){
                                t4=st.nextToken(" ");
                                }
                                
                                //System.out.println("t1="+t1+" t2="+t2+" t3="+t3+" t4="+t4);
                                
                                int t_1=Integer.parseInt(t1);
                                int t_2=Integer.parseInt(t2);
                                int t_3=Integer.parseInt(t3);

                                faces_gate.add(t_1);
                                faces_gate.add(t_2);
                                faces_gate.add(t_3);
                                
                                if(t4!=null){
                                int t_4=Integer.parseInt(t4);
                                faces_gate.add(t_4);
                                }
                                
                                if(t4==null){faces_gate.add(null);}
                                
                                /*
                                    if(l4.equals("")!=true){
                                        int t_4=Integer.parseInt(l4);
                                        faces_enemy.add(t_4);
                                    }
                                */
                                count_faces++;
                        }
                                
                         
                                
                        }
                linia=bfr.readLine();
                }
                
                System.out.println("Vertices "+count_vertices);
                System.out.println("Faces "+count_faces);
                
                bfr.close();
                }catch(Exception exc){System.out.println("Exception "+exc);}
                //loading enemy 3d data method
                
                
                if(doom==true){
                for(Point3d p:vertices_gate)
                {
                    p.rotateAxisY(0);
                    p.rotateAxisX(0);
                }    
                
                int q=0;
                int fn=24;
                //for(int i=0;i<2196;i++)
                for(int i=0;i<fn;i++)
                {
                   
                    q++;
                    
                    int w1=faces_gate.get(i);
                    i++;
                    int w2=faces_gate.get(i);
                    i++;
                    int w3=faces_gate.get(i);
                    i++;
                    Integer w4=faces_gate.get(i);
                    
                    if(w4==null){

                    Point3d p1=vertices_gate.get(w1-1);
                    Point3d p2=vertices_gate.get(w2-1);
                    Point3d p3=vertices_gate.get(w3-1);
                    //Point3d p4=vertices.get(w4-1);
                    Triangle t=new Triangle(p1,p2,p3);
                    t.tr_color=new Color(30,30,30);
                    
                    triangles_gate_d.add(t);
                    }
                    
                    if(w4!=null){

                    Point3d p1=vertices_gate.get(w1-1);
                    Point3d p2=vertices_gate.get(w2-1);
                    Point3d p3=vertices_gate.get(w3-1);
                    Point3d p4=vertices_gate.get(w4-1);
                    Triangle t=new Triangle(p1,p2,p3,p4);
                    t.tr_color=new Color(50,50,50);
                    
                    triangles_gate_d.add(t);
                    }
                    }
                }
                return triangles_gate_d;
    }
    
    //load lamborghini model
    public static ArrayList<Triangle> load_3d_object_lamborghini(String file_name)
    {
    //loading enemy 3d data method
        
                vertices_lambo=new ArrayList<Point3d>();
                faces_lambo=new ArrayList<Integer>();
                
                ArrayList<Triangle> triangles_gate_d=new ArrayList<Triangle>();
                
                try{
                
                    BufferedReader bfr=null;
                
                    //bfr=new BufferedReader(new FileReader("enemy_3d_d.obj"));
                    bfr=new BufferedReader(new FileReader(file_name));
                
                int count_vertices=0;
                int count_faces=0;
                String linia=bfr.readLine();
                
                while(linia!=null)
                {
                
                
                StringTokenizer st=new StringTokenizer(linia);
                String litera=st.nextToken(" ");
                
                        if(litera.equals("v")){

                        Float vx=Float.parseFloat(st.nextToken(" "));
                        Float vy=Float.parseFloat(st.nextToken(" "));
                        Float vz=Float.parseFloat(st.nextToken(" "));
                        
                        //System.out.println(" "+vx+" "+vy+" "+vz);
                        if(doom==true){
                                    vertices_lambo.add(new Point3d(vx*1000,-vy*1000,-vz*1000));
                        }
                        //}
                        count_vertices++;
                        }
                        
                        if(doom==true){
                                
                                if(litera.equals("f"))
                                {
                                //System.out.println(linia);

                                String t1=st.nextToken(" ");
                                String t2=st.nextToken(" ");
                                String t3=st.nextToken(" ");

                                
                                
                                String t4=null;
                                
                                if(st.hasMoreTokens()){
                                t4=st.nextToken(" ");
                                }
                                
                                //System.out.println("t1="+t1+" t2="+t2+" t3="+t3+" t4="+t4);
                                
                                int t_1=Integer.parseInt(t1);
                                int t_2=Integer.parseInt(t2);
                                int t_3=Integer.parseInt(t3);

                                faces_lambo.add(t_1);
                                faces_lambo.add(t_2);
                                faces_lambo.add(t_3);
                                
                                if(t4!=null){
                                int t_4=Integer.parseInt(t4);
                                faces_lambo.add(t_4);
                                }
                                
                                if(t4==null){faces_lambo.add(null);}
                                
                                /*
                                    if(l4.equals("")!=true){
                                        int t_4=Integer.parseInt(l4);
                                        faces_enemy.add(t_4);
                                    }
                                */
                                count_faces++;
                        }
                                
                         
                                
                        }
                linia=bfr.readLine();
                }
                
                System.out.println("Vertices "+count_vertices);
                System.out.println("Faces "+count_faces);
                
                bfr.close();
                }catch(Exception exc){System.out.println("Exception "+exc);}
                //loading enemy 3d data method
                
                
                if(doom==true){
                for(Point3d p:vertices_lambo)
                {
                    p.rotateAxisY(0);
                    p.rotateAxisX(0);
                }    
                
                int q=0;
                //int fn=14784;
                int fn=5396;
                //for(int i=0;i<2196;i++)
                for(int i=0;i<fn;i++)
                {
                   
                    q++;
                    
                    int w1=faces_lambo.get(i);
                    i++;
                    int w2=faces_lambo.get(i);
                    i++;
                    int w3=faces_lambo.get(i);
                    i++;
                    Integer w4=faces_lambo.get(i);
                    
                    if(w4==null){

                    Point3d p1=vertices_lambo.get(w1-1);
                    Point3d p2=vertices_lambo.get(w2-1);
                    Point3d p3=vertices_lambo.get(w3-1);
                    //Point3d p4=vertices.get(w4-1);
                    Triangle t=new Triangle(p1,p2,p3);
                    t.tr_color=new Color(30,30,30);
                    
                    triangles_gate_d.add(t);
                    }
                    
                    if(w4!=null){

                    Point3d p1=vertices_lambo.get(w1-1);
                    Point3d p2=vertices_lambo.get(w2-1);
                    Point3d p3=vertices_lambo.get(w3-1);
                    Point3d p4=vertices_lambo.get(w4-1);
                    Triangle t=new Triangle(p1,p2,p3,p4);
                    t.tr_color=new Color(50,50,50);
                    
                    triangles_gate_d.add(t);
                    }
                    }
                }
                return triangles_gate_d;
    }
    
    public static void load_collision(String file_name)
    {
    //loading enemy 3d data method
        
                vertices_collision=new ArrayList<Point3d>();
                //ArrayList<Triangle> triangles_enemy_d=new ArrayList<Triangle>();
                
                try{
                
                    BufferedReader bfr=null;
                
                    //bfr=new BufferedReader(new FileReader("enemy_3d_d.obj"));
                    bfr=new BufferedReader(new FileReader(file_name));
                
                int count_vertices=0;
                int count_faces=0;
                String linia=bfr.readLine();
                
                while(linia!=null)
                {
                
                
                StringTokenizer st=new StringTokenizer(linia);
                String litera=st.nextToken(" ");
                
                        if(litera.equals("v")){

                        Float vx=Float.parseFloat(st.nextToken(" "));
                        Float vy=Float.parseFloat(st.nextToken(" "));
                        Float vz=Float.parseFloat(st.nextToken(" "));
                        
                        //System.out.println(" "+vx+" "+vy+" "+vz);
                        if(doom==true){
                                    //vertices_collision.add(new Point3d(vx*40*10000,-vy*40*10000,-vz*40*10000));
                                    vertices_collision.add(new Point3d(vx*40*10000,-vy*40*10000,-vz*40*10000));
                        }
                        //}
                        count_vertices++;
                        }
                        
                linia=bfr.readLine();
                }
                
                System.out.println("Collision Cubes "+count_vertices/8);
                System.out.println("Collision Vertices "+count_vertices);
                
                
                bfr.close();
                }catch(Exception exc){System.out.println("Exception "+exc);}
                //loading enemy 3d data method
                
                
                if(doom==true){
                for(Point3d p:vertices_collision)
                {
                    p.rotateAxisY(0);
                    p.rotateAxisX(0);
                    
                    p.moveVectorOriginal(24800,13000,-122800);
                    
                    //p.moveVectorOriginal(400000+581500,(-2100+600)+1000000+453000,-13000000+540500);
                    
                    //p.moveVectorOriginal(400000+243500,(-2100+600)+1000000+440000,-13000000+649000);
                    
                    //p.moveVectorOriginal(-579000,(-2100+600)+1000000+355000,-13000000+798500);
                    
                    //p.moveVectorOriginal(0,-2100,0);
                }    
                }
                
    }
    
    public static void load_stairs(String file_name)
    {
    //loading enemy 3d data method
        
                vertices_stairs=new ArrayList<Point3d>();
                //ArrayList<Triangle> triangles_enemy_d=new ArrayList<Triangle>();
                
                try{
                
                    BufferedReader bfr=null;
                
                    //bfr=new BufferedReader(new FileReader("enemy_3d_d.obj"));
                    bfr=new BufferedReader(new FileReader(file_name));
                
                int count_vertices=0;
                int count_faces=0;
                String linia=bfr.readLine();
                
                while(linia!=null)
                {
                
                
                StringTokenizer st=new StringTokenizer(linia);
                String litera=st.nextToken(" ");
                
                        if(litera.equals("v")){

                        Float vx=Float.parseFloat(st.nextToken(" "));
                        Float vy=Float.parseFloat(st.nextToken(" "));
                        Float vz=Float.parseFloat(st.nextToken(" "));
                        
                        //System.out.println(" "+vx+" "+vy+" "+vz);
                        if(doom==true){
                                    //vertices_collision.add(new Point3d(vx*40*10000,-vy*40*10000,-vz*40*10000));
                                    vertices_stairs.add(new Point3d(vx*40*10000,-vy*40*10000,-vz*40*10000));
                        }
                        //}
                        count_vertices++;
                        }
                        
                linia=bfr.readLine();
                }
                
                System.out.println("Stairs Cubes "+count_vertices/8);
                System.out.println("Stairs Vertices "+count_vertices);
                
                
                bfr.close();
                }catch(Exception exc){System.out.println("Exception "+exc);}
                //loading enemy 3d data method
                
                
                if(doom==true){
                for(Point3d p:vertices_stairs)
                {
                    p.rotateAxisY(0);
                    p.rotateAxisX(0);
                    
                    p.moveVectorOriginal(24800,13000,-122800);
                    //p.moveVectorOriginal(-579000,(-2100+600)+1000000+354000,-13000000+798500);
                    
                }    
                }
                
    }
    
    public void start_in_game_mode()
    {
        crash_bandicoot=false;
        lamborghini=false;
        tomb_raider=false;
        tea_pot=false;
        tr_map=false;
        doom=true;
        
        //if(quake==false) quake=true; else quake=false;
        
        change_quater_left=false;
        change_quater_right=false;
        
        calculate_normals=false;
        reload_application();        
    }
    
    public void update_game_input()
    {
        
        elevation_changed=false;
        if(player_x>0) calculate_lambo=false; else calculate_lambo=false;
        
        if(shot_once==false){
            if(shot_pressed==true){
                make_shot();shot_counter++; if(shot_counter==4){shot_counter=0;shot_once=true;shot_anim=true;shot_animation=R_3D.rn.nextInt(5);delta=0;}
            }
        }
            
            R_3D.old_player_x=R_3D.player_x;
            R_3D.old_player_z=R_3D.player_z;
            
            //check collision with gates
            try{
            for(Gate gate:gates)
            {
            
            /*
            Point3d p=new Point3d(0,0,0);
            p.xr2=gate.vertices_collision.get(0).xro3;
            p.yr2=gate.vertices_collision.get(0).yro3;
            p.zr2=gate.vertices_collision.get(0).zro3;
            
            Point3d p2=new Point3d(0,0,0);
            p2.xr2=gate.vertices_collision.get(1).xro3;
            p2.yr2=gate.vertices_collision.get(1).yro3;
            p2.zr2=gate.vertices_collision.get(1).zro3;
            
            Point3d p3=new Point3d(0,0,0);
            p3.xr2=gate.vertices_collision.get(2).xro3;
            p3.yr2=gate.vertices_collision.get(2).yro3;
            p3.zr2=gate.vertices_collision.get(2).zro3;
            
            Point3d p5=new Point3d(0,0,0);
            p5.xr2=gate.vertices_collision.get(4).xro3;
            p5.yr2=gate.vertices_collision.get(4).yro3;
            p5.zr2=gate.vertices_collision.get(4).zro3;
            */
            
            Point3d p=gate.vertices_collision.get(0);
            Point3d p2=gate.vertices_collision.get(1);
            Point3d p3=gate.vertices_collision.get(2);
            Point3d p5=gate.vertices_collision.get(4);
            
            p.xr2=gate.vertices_collision.get(0).xro3;
            p.yr2=gate.vertices_collision.get(0).yro3;
            p.zr2=gate.vertices_collision.get(0).zro3;
            
            p2.xr2=gate.vertices_collision.get(1).xro3;
            p2.yr2=gate.vertices_collision.get(1).yro3;
            p2.zr2=gate.vertices_collision.get(1).zro3;
            
            p3.xr2=gate.vertices_collision.get(2).xro3;
            p3.yr2=gate.vertices_collision.get(2).yro3;
            p3.zr2=gate.vertices_collision.get(2).zro3;
            
            p5.xr2=gate.vertices_collision.get(4).xro3;
            p5.yr2=gate.vertices_collision.get(4).yro3;
            p5.zr2=gate.vertices_collision.get(4).zro3;
            
            /*
            g.setColor(new Color(0,0,255));
            g.fillRect(p.x2d, p.y2d, 5, 5);
            g.fillRect(p2.x2d, p2.y2d, 5, 5);
            g.fillRect(p3.x2d, p3.y2d, 5, 5);
            g.fillRect(p5.x2d, p5.y2d, 5, 5);
            */
            
            gate.update_gate_animation();
            
                if(gate.open==false){
                        Vect vo=new Vect(0,0,200);
                        if (check_player_collision_with_walls(p, p2, p3, p5,vo)==true)
                        {
                            go_backward();
                            go_backward();
                            go_backward();
                            //gate.is_opening=true;
                            return;
                        }
                }
                
            }
            }catch(Exception exc){};
            //check collision with gates
            
            //check collision with walls
            for(int q=0;q<vertices_collision.size()-7;q++)
            {
                Point3d p=vertices_collision.get(q);p.calculate2dpoint();q++;
                Point3d p2=vertices_collision.get(q);p2.calculate2dpoint();q++;

                Point3d p3=vertices_collision.get(q);p3.calculate2dpoint();q++;
                Point3d p4=vertices_collision.get(q);p4.calculate2dpoint();q++;
                Point3d p5=vertices_collision.get(q);p5.calculate2dpoint();q++;
                Point3d p6=vertices_collision.get(q);p6.calculate2dpoint();q++;
                Point3d p7=vertices_collision.get(q);p7.calculate2dpoint();q++;
                Point3d p8=vertices_collision.get(q);p8.calculate2dpoint();
                
                Vect vo=new Vect(500,0,250);
                if (check_player_collision_with_walls(p, p2, p3, p5,vo)==true)
                {
                    strafe_Left();
                    return;
                }
                
                vo=new Vect(-500,0,250);
                if (check_player_collision_with_walls(p, p2, p3, p5,vo)==true)
                {
                    strafe_Right();
                    return;
                }
                
                vo=new Vect(0,0,200);
                if (check_player_collision_with_walls(p, p2, p3, p5,vo)==true)
                {
                    go_backward();
                    go_backward();
                    go_backward();
                    
                    return;
                }
                
                vo=new Vect(0,0,-300);
                if (check_player_collision_with_walls(p, p2, p3, p5,vo)==true)
                {
                    go_forward();
                    return;
                }
                
            }
            //check collision with walls
            
            //check collision with stairs
            int stair_c=0;
            for(int q=0;q<vertices_stairs.size()-7;q++)
            {
            stair_c++;
            Point3d p=vertices_stairs.get(q);p.calculate2dpoint();q++;
            Point3d p2=vertices_stairs.get(q);p2.calculate2dpoint();q++;
            
            Point3d p3=vertices_stairs.get(q);p3.calculate2dpoint();q++;
            Point3d p4=vertices_stairs.get(q);p4.calculate2dpoint();q++;
            Point3d p5=vertices_stairs.get(q);p5.calculate2dpoint();q++;
            Point3d p6=vertices_stairs.get(q);p6.calculate2dpoint();q++;
            Point3d p7=vertices_stairs.get(q);p7.calculate2dpoint();q++;
            Point3d p8=vertices_stairs.get(q);p8.calculate2dpoint();
            
            
            if(p.zr2+15000>0){
               
            
            
            Vect vo=new Vect(0,0,100);
            
            if(check_player_collision_with_walls(p,p2,p3,p5,vo)==true)
            {
                elevation_changed=true;
                
                if(stair_c==1) elevation=0;
                if(stair_c==2) elevation=600;
                if(stair_c==3) elevation=1200;
                if(stair_c==4) elevation=1800;
                
                if(stair_c==5) elevation=0;
                if(stair_c==6) elevation=600;
                if(stair_c==7) elevation=1200;
                if(stair_c==8) elevation=1800;
                if(stair_c==9) elevation=2400;
                if(stair_c==10) elevation=3000;
                if(stair_c==11) elevation=3600;
                if(stair_c==12) elevation=4200;
                
                if(stair_c==13) elevation=0;
                if(stair_c==14) elevation=-600;
                if(stair_c==15) elevation=-1200;
                if(stair_c==16) elevation=-1800;
                if(stair_c==17) elevation=-2400;
                if(stair_c==18) elevation=-3000;
                if(stair_c==19) elevation=-3600;
                if(stair_c==20) elevation=-4200;
                
                if(stair_c==21) elevation=-4200;
                if(stair_c==22) elevation=-3600;
                if(stair_c==23) elevation=-3000;
                if(stair_c==24) elevation=-2400;
                if(stair_c==25) elevation=-1800;
                if(stair_c==26) elevation=-1200;
                
            }
            }
            }
            //check collision with stairs
            
        if(forward_pressed==true){go_forward();}
        if(backward_pressed==true){go_backward();}
        if(left_pressed==true){strafe_Left();}
        if(right_pressed==true){strafe_Right();}
        
    }
    
    public void keyPressed(KeyEvent e) {
        if(e.getKeyCode()==69)
        {
            shot_pressed=true;
        }
        //if(e.getKeyCode()==69){make_shot();}
        if(e.getKeyCode()==87){forward_pressed=true;}
        if(e.getKeyCode()==83){backward_pressed=true;}
        if(e.getKeyCode()==65){left_pressed=true;}
        if(e.getKeyCode()==68){right_pressed=true;}
    }
    
     @Override
    public void keyTyped(KeyEvent ke) {
    
    }

    @Override
    public void keyReleased(KeyEvent ke) {
        if(ke.getKeyCode()==69){shot_pressed=false;shot_once=false;}
        if(ke.getKeyCode()==87){forward_pressed=false;}
        if(ke.getKeyCode()==83){backward_pressed=false;}
        if(ke.getKeyCode()==65){left_pressed=false;}
        if(ke.getKeyCode()==68){right_pressed=false;}
    }
    
     @Override
     public void mousePressed(MouseEvent e)
     {
         if(e.getButton()==1)
         {
             mouse_pressed=true;
         }
         
         if(e.getButton()==3){mouse_2_pressed=true;}
          
     }
     
      @Override
    public void mouseReleased(MouseEvent me) {
        mouse_pressed=false;
        mouse_2_pressed=false;
    }
     
     public void mouseMoved(MouseEvent e) {
        //eventOutput("Mouse moved", e);
        
        //System.out.println(""+cube_angleY);
        try{
                    if(doom==true)
                    {
                        turn_left=false;
                        turn_right=false;
                        
                        turn_up=false;
                        turn_down=false;
                        
                        
                        
                        if(e.getY()>old_mouse_y)
                        {
                            if(lock_head==false){
                            this.cube_angleX=this.cube_angleX+0.5*mouse_speed_x;
                            //mouse_moved_up=true;
                            }
                        }

                        if(e.getY()<old_mouse_y)
                        {
                            if(lock_head==false){
                            this.cube_angleX=this.cube_angleX-0.5*mouse_speed_x;
                            //mouse_moved_down=true;
                            }
                        }
                        
                        if(e.getX()>old_mouse_x)
                        {
                        this.cube_angleY=this.cube_angleY-1*mouse_speed_y;
                        //mouse_moved_right=true;
                        }

                        if(e.getX()<old_mouse_x)
                        {
                        this.cube_angleY=this.cube_angleY+1*mouse_speed_y;
                        //mouse_moved_left=true;
                        }

                        if(e.getX()>480)
                        {
                        turn_right=true;
                        }

                        if(e.getX()<160)
                        {
                        turn_left=true;
                        }
                        
                         if(e.getY()>300)
                        {
                        turn_up=true;
                        }

                        if(e.getY()<180)
                        {
                        turn_down=true;
                        }
                        
                        this.old_mouse_x=e.getX();
                        this.old_mouse_y=e.getY();  
                    }
        }catch(Exception exc){}
    }
     
    public void mouseDragged(MouseEvent e) {
        //eventOutput("Mouse dragged", e);
    }
    
    public boolean check_collision_with_player(Point3d p)
    {

    float world_x=R_3D.player_x;
    float world_y=R_3D.player_y;
    float world_z=R_3D.player_z;
    
    world_x=0;
    world_y=0;
    world_z=0;
    
    //Point3d tp=t_list.get(0).v1;
    //tp=new Point3d(world_x,world_y,world_z);
    
    Point3d tp=new Point3d(world_x,world_y,world_z);
    tp.rotateAxisY(cube_angleY);
    tp.rotateAxisX(cube_angleX);
    tp.calculate2dpoint();
    
    //tp.calculate2dpoint_character();
    //if((p.xr2-tp.xro3)*(p.xr2-tp.xro3)+(p.yr2-tp.yro3)*(p.yr2-tp.yro3)+(p.zr2-tp.zro3)*(p.zr2-tp.zro3)<(1000*1000)){return true;}
    
    if((p.xr2-tp.xr2)*(p.xr2-tp.xr2)+(p.yr2-tp.yr2)*(p.yr2-tp.yr2)+(p.zr2-tp.zr2)*(p.zr2-tp.zr2)<(1000*1000)){return true;}
    return false;
    }
    
    public void make_shot()
    {
        //Point3d b=new Point3d(player_x,player_y,player_z);
        Point3d b=new Point3d(0,0,0);
        b.rotateAxisY(cube_angleY);
        b.rotateAxisX(cube_angleX);
        
        //b.moveVectorOriginal(40000,-2100+600,-130000);
        b.isPlayerBullet=true;
        
        int shot_velocity=10;
        float sv=20f;
        
        //int shot_velocity=10;
        //float sv=1f;
        
        
        //b.moveVector(player_x,player_z,player_y);
        
        b.calculate2dpoint();
        
        //System.out.println("Shot");
        //System.out.println("x y z"+b.xr2+" "+b.yr2+" "+b.zr2);
        double alpha = (this.cube_angleY+90) * 3.14 / 180;
        double shot_move_x=Math.cos(alpha)*shot_velocity;
        double shot_move_y=Math.sin(alpha)*shot_velocity;
        
        double theta = (this.cube_angleX) * 3.14 / 180;
        double shot_move_z=Math.sin(theta)*shot_velocity;
        
        //R_3D.player_x=R_3D.player_x-(float)move_x;
        //R_3D.player_z=R_3D.player_z-(float)move_y;
        b.speed_x=(float)shot_move_x*sv;
        b.speed_z=(float)shot_move_y*sv;
        b.speed_y=(float)shot_move_z*sv;;
        //b.moveBullet();
        this.bullets.add(b);
        
        //second point
        b=new Point3d(-(float)shot_move_x*300,-(float)shot_move_z*300,-(float)shot_move_y*300);
        b.rotateAxisY(cube_angleY);
        b.rotateAxisX(cube_angleX);
        
        b.calculate2dpoint();
        b.isPlayerBullet=true;
        
        alpha = (this.cube_angleY+90) * 3.14 / 180;
        shot_move_x=Math.cos(alpha)*shot_velocity;
        shot_move_y=Math.sin(alpha)*shot_velocity;
        
        theta = (this.cube_angleX) * 3.14 / 180;
        shot_move_z=Math.sin(theta)*shot_velocity;
        
        b.speed_x=(float)shot_move_x*sv;
        b.speed_z=(float)shot_move_y*sv;
        b.speed_y=(float)shot_move_z*sv;
        //b.moveBullet();
        this.bullets.add(b);
        
        //make_enemy_shot(0);
        //make_enemy_shot(1);
    }
    
    public void make_enemy_shot(int nr)
    {
        //Point3d b=new Point3d(player_x,player_y,player_z);
        Character enemy=enemies.get(nr);
                            Point3d pc=new Point3d(player_x+enemy.x,player_y+enemy.y,player_z+enemy.z);
                            pc.rotateAxisY(cube_angleY);
                            pc.rotateAxisX(cube_angleX);
                            pc.calculate2dpoint();
                            
                            float snx=(-pc.x)/10000;
                            float snz=(-pc.z)/10000;
                            float sny=(-pc.y)/10000;
                            
                            //Point3d ec=new Point3d(player_x+enemy.x,player_y+enemy.y,player_z+enemy.z);
                            Point3d ec=new Point3d(player_x+enemy.x,player_y+enemy.y,player_z+enemy.z);
                            
                            
                            
                            Point3d ec2=new Point3d(player_x+enemy.x+snx,player_y+enemy.y,player_z+enemy.z+snz);
                            
                           
                            
                            ec.rotateAxisY(cube_angleY);
                            ec.rotateAxisX(cube_angleX);
                            ec.calculate2dpoint();
                            
                            ec2.rotateAxisY(cube_angleY);
                            ec2.rotateAxisX(cube_angleX);
                            ec2.calculate2dpoint();
                            
                            
                            
        Point3d b=new Point3d(ec.x,ec.y,ec.z);
        b.rotateAxisY(cube_angleY);
        b.rotateAxisX(cube_angleX);
        //b.moveVectorOriginal(40000,-2100+600,-130000);
        
        
        //int shot_velocity=20;
        //float sv=10f;
        
        int shot_velocity=10;
        float sv=1f;
        
        
        //b.moveVector(player_x,player_z,player_y);
        
        b.calculate2dpoint();
        
        //System.out.println("Shot");
        //System.out.println("x y z"+b.xr2+" "+b.yr2+" "+b.zr2);
        double alpha = (this.cube_angleY+90) * 3.14 / 180;
        double shot_move_x=Math.cos(alpha)*shot_velocity;
        double shot_move_y=Math.sin(alpha)*shot_velocity;
        
        double theta = (this.cube_angleX) * 3.14 / 180;
        double shot_move_z=Math.sin(theta)*shot_velocity;
        
        //R_3D.player_x=R_3D.player_x-(float)move_x;
        //R_3D.player_z=R_3D.player_z-(float)move_y;
        
        shot_move_x=(-pc.x)/1000;
        shot_move_y=(-pc.z)/1000;
        shot_move_z=(-pc.y)/1000;
        //shot_move_x=ec.x/Math.sqrt(ec.x*ec.x+ec.y*ec.y+ec.z*ec.z);
        //shot_move_y=ec.y/Math.sqrt(ec.x*ec.x+ec.y*ec.y+ec.z*ec.z);
        //shot_move_z=ec.z/Math.sqrt(ec.x*ec.x+ec.y*ec.y+ec.z*ec.z);
        
        b.speed_x=(float)shot_move_x*sv;
        b.speed_z=(float)shot_move_y*sv;
        b.speed_y=(float)shot_move_z*sv;;
        //b.moveBullet();
        this.bullets.add(b);
        
        //second point
        
        //b=new Point3d(-(float)shot_move_x*300,0,-(float)shot_move_y*300);
        
        //ec2=new Point3d(player_x+enemy.x+snx,player_y+enemy.y,player_z+enemy.z+snz);
        //b=new Point3d(ec2.x-(float)shot_move_x*300,ec2.y,ec2.z-(float)shot_move_y*300);
        b=new Point3d(ec2.x-snx*300,ec2.y-sny*300,ec2.z-snz*300);
        b.rotateAxisY(cube_angleY);
        b.rotateAxisX(cube_angleX);
        b.calculate2dpoint();
        alpha = (this.cube_angleY+90) * 3.14 / 180;
        shot_move_x=Math.cos(alpha)*shot_velocity;
        shot_move_y=Math.sin(alpha)*shot_velocity;
        
        theta = (this.cube_angleX) * 3.14 / 180;
        shot_move_z=Math.sin(theta)*shot_velocity;
        
        
        shot_move_x=(-pc.x)/1000;
        shot_move_y=(-pc.z)/1000;
        shot_move_z=(-pc.y)/1000;
        //shot_move_x=ec2.x/Math.sqrt(ec2.x*ec2.x+ec2.y*ec2.y+ec2.z*ec2.z);
        //shot_move_y=ec2.y/Math.sqrt(ec2.x*ec2.x+ec2.y*ec2.y+ec2.z*ec2.z);
        //shot_move_z=ec2.z/Math.sqrt(ec2.x*ec2.x+ec2.y*ec2.y+ec2.z*ec2.z);
        
        b.speed_x=(float)shot_move_x*sv;
        b.speed_z=(float)shot_move_y*sv;
        b.speed_y=(float)shot_move_z*sv;
        //b.moveBullet();
        this.bullets.add(b);
    }
    
    public void up_elevation()
    {
        //System.out.println("Up");
        for(Point3d p:vertices)
        {
        //move_scale 100 
        p.y=p.y+200;
        p.calculate2dpoint();
        }
        
        for(Point3d p:vertices_collision)
        {
        //move_scale 100 
        p.y=p.y+200;
        p.calculate2dpoint();
        }
        
        for(Point3d p:vertices_stairs)
        {
        //move_scale 100 
        p.y=p.y+200;
        p.calculate2dpoint();
        }
        
        for(Point3d p:additional_vertices)
        {
        //move_scale 100 
        p.y=p.y+200;
        p.calculate2dpoint();
        }
        
        //bullets
        for(Point3d p:bullets)
        {
        //move_scale 100 
        p.y=p.y+200;
        p.calculate2dpoint();
        }
        
        R_3D.player_y=R_3D.player_y+200;
    }
    
    public void down_elevation()
    {
        //System.out.println("Down");
        for(Point3d p:vertices)
        {
        //move_scale 100
        p.y=p.y-200;
        p.calculate2dpoint();
        }
        
        for(Point3d p:vertices_collision)
        {
        //move_scale 100
        p.y=p.y-200;
        p.calculate2dpoint();
        }
        
        for(Point3d p:vertices_stairs)
        {
        //move_scale 100
        p.y=p.y-200;
        p.calculate2dpoint();
        }
                
        for(Point3d p:additional_vertices)
        {
        //move_scale 100
        p.y=p.y-200;
        p.calculate2dpoint();
        }
        
        //bullets
        for(Point3d p:bullets)
        {
        //move_scale 100
        p.y=p.y-200;
        p.calculate2dpoint();
        }
        
        R_3D.player_y=R_3D.player_y-200;
    }
    
    public void up()
    {
        //System.out.println("Up");
        for(Point3d p:vertices)
        {
        //move_scale 100 
        p.y=p.y+3*move_scale;
        p.calculate2dpoint();
        }
        
        for(Point3d p:vertices_collision)
        {
        //move_scale 100 
        p.y=p.y+3*move_scale;
        p.calculate2dpoint();
        }
        
        for(Point3d p:vertices_stairs)
        {
        //move_scale 100 
        p.y=p.y+3*move_scale;
        p.calculate2dpoint();
        }
        
        for(Point3d p:additional_vertices)
        {
        //move_scale 100 
        p.y=p.y+3*move_scale;
        p.calculate2dpoint();
        }
        
        //bullets
        for(Point3d p:bullets)
        {
        //move_scale 100 
        p.y=p.y+3*move_scale;
        p.calculate2dpoint();
        }
        
        R_3D.player_y=R_3D.player_y+3*move_scale;
    }
    
    public void down()
    {
        //System.out.println("Down");
        for(Point3d p:vertices)
        {
        //move_scale 100
        p.y=p.y-3*move_scale;
        p.calculate2dpoint();
        }
        
        for(Point3d p:vertices_collision)
        {
        //move_scale 100
        p.y=p.y-3*move_scale;
        p.calculate2dpoint();
        }
        
        for(Point3d p:vertices_stairs)
        {
        //move_scale 100
        p.y=p.y-3*move_scale;
        p.calculate2dpoint();
        }
                
        for(Point3d p:additional_vertices)
        {
        //move_scale 100
        p.y=p.y-3*move_scale;
        p.calculate2dpoint();
        }
        
        //bullets
        for(Point3d p:bullets)
        {
        //move_scale 100
        p.y=p.y-3*move_scale;
        p.calculate2dpoint();
        }
        
        R_3D.player_y=R_3D.player_y-3*move_scale;
    }
    
    public void go_forward()
    {
        //System.out.println("player_x="+R_3D.player_x+" player_z="+R_3D.player_z);
        
        double alpha = (this.cube_angleY+90) * 3.14 / 180;
        
        //move_scale 100
        double move_x=Math.cos(alpha)*move_scale;
        double move_y=Math.sin(alpha)*move_scale;
        
        R_3D.player_x=R_3D.player_x-(float)move_x;
        R_3D.player_z=R_3D.player_z-(float)move_y;
        
        
        
        for(Point3d p:vertices)
        {
        //p.z=p.z-300;
            p.x=p.x-(float)move_x;
            p.z=p.z-(float)move_y;
            
        p.calculate2dpoint();
        }
        
        for(Point3d p:vertices_collision)
        {
        //p.z=p.z-300;
            p.x=p.x-(float)move_x;
            p.z=p.z-(float)move_y;
            
        p.calculate2dpoint();
        }
        
        for(Point3d p:vertices_stairs)
        {
        //p.z=p.z-300;
            p.x=p.x-(float)move_x;
            p.z=p.z-(float)move_y;
            
        p.calculate2dpoint();
        }
        
        for(Point3d p:additional_vertices)
        {
        //p.z=p.z-300;
            p.x=p.x-(float)move_x;
            p.z=p.z-(float)move_y;
            
        p.calculate2dpoint();
        }
        
        //bullets
        for(Point3d p:bullets)
        {
        //p.z=p.z-300;
            p.x=p.x-(float)move_x;
            p.z=p.z-(float)move_y;
            
        p.calculate2dpoint();
        }
    }
    
    public void go_backward()
    {
        //System.out.println("player_x="+R_3D.player_x+" player_z="+R_3D.player_z);
        
        double alpha = (this.cube_angleY+90) * 3.14 / 180;
        
        double move_x=Math.cos(alpha)*move_scale;
        double move_y=Math.sin(alpha)*move_scale;
        
        R_3D.player_x=R_3D.player_x+(float)move_x;
        R_3D.player_z=R_3D.player_z+(float)move_y;
        
        for(Point3d p:vertices)
        {
        //p.z=p.z+300;
            p.x=p.x+(float)move_x;
            p.z=p.z+(float)move_y;
        p.calculate2dpoint();
        }    
        
        for(Point3d p:vertices_collision)
        {
        //p.z=p.z+300;
            p.x=p.x+(float)move_x;
            p.z=p.z+(float)move_y;
        p.calculate2dpoint();
        }
        
        for(Point3d p:vertices_stairs)
        {
        //p.z=p.z+300;
            p.x=p.x+(float)move_x;
            p.z=p.z+(float)move_y;
        p.calculate2dpoint();
        } 
        
        for(Point3d p:additional_vertices)
        {
        //p.z=p.z+300;
            p.x=p.x+(float)move_x;
            p.z=p.z+(float)move_y;
        p.calculate2dpoint();
        }    
        
        //bullets
        for(Point3d p:bullets)
        {
        //p.z=p.z+300;
            p.x=p.x+(float)move_x;
            p.z=p.z+(float)move_y;
        p.calculate2dpoint();
        }    
    }
    
    public void strafe_Left()
    {
        //System.out.println("player_x="+R_3D.player_x+" player_z="+R_3D.player_z);
        double alpha = this.cube_angleY * 3.14 / 180;
        
        double move_x=Math.cos(alpha)*move_scale_strafe;
        double move_y=Math.sin(alpha)*move_scale_strafe;
        
        R_3D.player_x=R_3D.player_x+(float)move_x;
        R_3D.player_z=R_3D.player_z+(float)move_y;
        
        for(Point3d p:vertices)
        {
        //p.x=p.x+300;
            p.x=p.x+(float)move_x;
            p.z=p.z+(float)move_y;
            
        p.calculate2dpoint();
        }
        
        for(Point3d p:vertices_collision)
        {
        //p.x=p.x+300;
            p.x=p.x+(float)move_x;
            p.z=p.z+(float)move_y;
            
        p.calculate2dpoint();
        }
        
        for(Point3d p:vertices_stairs)
        {
        //p.x=p.x+300;
            p.x=p.x+(float)move_x;
            p.z=p.z+(float)move_y;
            
        p.calculate2dpoint();
        }
        
        for(Point3d p:additional_vertices)
        {
        //p.x=p.x+300;
            p.x=p.x+(float)move_x;
            p.z=p.z+(float)move_y;
            
        p.calculate2dpoint();
        }
        
        //bullets
        for(Point3d p:bullets)
        {
        //p.x=p.x+300;
            p.x=p.x+(float)move_x;
            p.z=p.z+(float)move_y;
            
        p.calculate2dpoint();
        }
    }
    
    public void strafe_Right()
    {
        //System.out.println("player_x="+R_3D.player_x+" player_z="+R_3D.player_z);
        double alpha = this.cube_angleY * 3.14 / 180;
        
        double move_x=Math.cos(alpha)*move_scale_strafe;
        double move_y=Math.sin(alpha)*move_scale_strafe;
        
        R_3D.player_x=R_3D.player_x-(float)move_x;
        R_3D.player_z=R_3D.player_z-(float)move_y;
        
        for(Point3d p:vertices)
        {
        //p.x=p.x-300;
              p.x=p.x-(float)move_x;
              p.z=p.z-(float)move_y;
        p.calculate2dpoint();
        }
        
        for(Point3d p:vertices_collision)
        {
        //p.x=p.x-300;
              p.x=p.x-(float)move_x;
              p.z=p.z-(float)move_y;
        p.calculate2dpoint();
        }
        
        for(Point3d p:vertices_stairs)
        {
        //p.x=p.x-300;
              p.x=p.x-(float)move_x;
              p.z=p.z-(float)move_y;
        p.calculate2dpoint();
        }
        
        for(Point3d p:additional_vertices)
        {
        //p.x=p.x-300;
              p.x=p.x-(float)move_x;
              p.z=p.z-(float)move_y;
        p.calculate2dpoint();
        }
        
        //bullets
        for(Point3d p:bullets)
        {
        //p.x=p.x-300;
              p.x=p.x-(float)move_x;
              p.z=p.z-(float)move_y;
        p.calculate2dpoint();
        }
    }
    
    public void reload_application()
    {
        this.application_running=false;
        this.frame.dispose();
                
        R_3D r=new R_3D();
        
        r.panel = r;
        
        r.frame = new JFrame("Mateusz Pawlowski. 3D Software Renderer.");
        
        r.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
       
        
        r.thread=new Thread(r);
        r.thread.start();
        
        r.frame.getContentPane().add(r.panel);
        r.frame.setLocation(500, 300);
        
        //hide mouse pointer
        BufferedImage cursorImg = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);
        Cursor blankCursor = Toolkit.getDefaultToolkit().createCustomCursor(
        cursorImg, new Point(0, 0), "blank cursor");
        r.frame.getContentPane().setCursor(blankCursor);
                        
        r.frame.pack();
        r.frame.show();
        
        if(tomb_raider==true){ r.scale=r.scale+300;}
        
        if(doom==false)
        {
        r.rotateDown();
        r.rotateDown();
        r.rotateDown();
        }
        
        if(play==true) r.play=true;
        
        //r.up();
        //r.up();
        //r.up();
        //r.up();
        //r.up();
        
    }
    
    public void play()
    {
    this.play=true;
    }
    
    public void stop()
    {
    this.play=false;
    }
    
    public void auto_calibration()
    {
                        //System.out.println(""+cube_angleY);
                        
                        if(cube_angleY<100) change_quater_left=false;
                        if(change_quater_left==false){
                            if(cube_angleY<90){cube_angleY=360+90;change_quater_left=true;}
                        }    
                        
                        if(cube_angleY>(350+180)) change_quater_right=false;
                        if(change_quater_right==false){
                            if(cube_angleY>(360+180)){cube_angleY=180;change_quater_right=true;}
                        }    
    }
    
    public void rotateLeft()
    {
    stop();
    this.cube_angleY=this.cube_angleY+5;
    System.out.println("cube_angleY"+this.cube_angleY);
    //if (this.cube_angleY>=360){this.cube_angleY=0;}
    //if (this.cube_angleY==0){this.cube_angleY=360-this.cube_angleY;}
    
    }
    
    public void rotateRight()
    {
    stop();
    this.cube_angleY=this.cube_angleY-5;
    System.out.println("cube_angleY"+this.cube_angleY);
    
    }
    
    public void rotateUp()
    {
    stop();
    this.cube_angleX=this.cube_angleX-5;
    }
    
    public void rotateDown()
    {
    stop();
    this.cube_angleX=this.cube_angleX+5;
    }
    
    public void update_elevation()
    {
        if(elevation_changed==true){
                if(R_3D.player_y<elevation){
                    up_elevation();
                    
                    if(show_collision==true) System.out.println("Stairs player h="+R_3D.player_y);
                }else if(R_3D.player_y>elevation){
                    down_elevation();
                    if(show_collision==true) System.out.println("Stairs player h="+R_3D.player_y);
                }
        }
    
    }
    
    public Vect intersect_plane(Vect plane_p,Vect plane_n,Vect start_line,Vect end_line)
    {
        float plane_d=-Vect.getDotProduct(plane_n, plane_p);
        float ad=Vect.getDotProduct(start_line, plane_p);
        float bd=Vect.getDotProduct(end_line, plane_n);
        float t=(-plane_d-ad)/(bd-ad);
        Vect line_start_to_end=new Vect(start_line.x-end_line.x,start_line.y-end_line.y,start_line.z-end_line.z);
        Vect line_to_intersect=new Vect(line_start_to_end.x*t,line_start_to_end.y*t,line_start_to_end.z*t);
        return new Vect(start_line.x+line_to_intersect.x,start_line.y+line_to_intersect.y,start_line.z+line_to_intersect.z);
    }
    
    public boolean wich_side_of_plane_point_is(Vect A,Vect B,Vect C,Vect test_point)
    {
    //A B C vectors of plane
    // cross product of (B-A)x(C-A) is nomal of plane
    //(P−A)⋅n>0 left side
    //(P−A)⋅n<0 right side
        
        Vect AA=new Vect(B.x-A.x,B.y-A.y,B.z-A.z);
        Vect BB=new Vect(C.x-A.x,C.y-A.y,C.z-A.z);
        Vect n=Vect.getNormal(AA, BB);
        
        Vect PmA=new Vect(test_point.x-A.x,test_point.y-A.y,test_point.z-A.z);
        
        double side=Vect.getDotProduct(PmA, n);
        
        if(side>=0){return true;} else return false;
    }
    
    public boolean check_player_collision_with_walls(Point3d p,Point3d p2,Point3d p3,Point3d p5,Vect o)
    {
            //check player at (0,0,0) collision with walls
            
            Vect i=new Vect(p2.xr2-p.xr2,p2.yr2-p.yr2,p2.zr2-p.zr2);
            Vect j=new Vect(p3.xr2-p.xr2,p3.yr2-p.yr2,p3.zr2-p.zr2);
            Vect k=new Vect(p5.xr2-p.xr2,p5.yr2-p.yr2,p5.zr2-p.zr2);
            
            //Vect v=new Vect(0-p.xr2,0-p.yr2,0-p.zr2);
            Vect v=new Vect(o.x-p.xr2,o.y-p.yr2,o.z-p.zr2);
            
            //when these all equations with dot products are true the point v is inside cube created by vectors i j k
            //0<v⋅i<i⋅i
            //0<v⋅j<j⋅j
            //0<v⋅k<k⋅k
            float a_col=Vect.getDotProduct(v, i);
            float b_col=Vect.getDotProduct(v, j);
            float c_col=Vect.getDotProduct(v, k);
            
            float d_col=Vect.getDotProduct(i, i);
            float e_col=Vect.getDotProduct(j, j);
            float f_col=Vect.getDotProduct(k, k);
            
            boolean isPlayerColliding=false;
            if(a_col>0&&a_col<d_col)
            {
                if(b_col>0&&b_col<e_col)
                {
                    if(c_col>0&&c_col<f_col)
                    {
                        isPlayerColliding=true;
                        //System.out.println("Wall Collision");
                    }
                }
            }
            //check player at (0,0,0) collision with walls
            return isPlayerColliding;
    }
    
    public void run()
    {
    try{    
        while(application_running){
            try{
            
                if(quake==true){Thread.sleep(1);}
                if(quake==false){Thread.sleep(5);}
                
            }catch(InterruptedException exc){return;}
           
            //angle=this.cube_angle;
            //if (angle>=360){angle=0;} else angle=angle+1;
            if(this.play==true)
            {
            //cube_angleX++;
            //cube_angleY++;
            if(cube_angleY>=360){cube_angleY=0;}
            cube_angleY=cube_angleY+1;
            if(tea_pot==true) cube_angleX++;
            //cube_angleX=cube_angleX+1;
            }
            
            double a=angle; 
       
            if(doom==true)
            {
                
                        if(doom==true){
                                    //rotate enemy
                                    for(Character enemy:enemies){
                                           
                                        for(int q=0;q<enemy.t_list.size();q++)
                                        {
                                           Triangle t=enemy.t_list.get(q);
                                           
                                           if(t.v4==null){
                                                    Point3d e1=t.v1;
                                                    Point3d e2=t.v2;
                                                    Point3d e3=t.v3;
                                                    //Point3d e4=t.v4;


                                                    enemy.character_angleY=cube_angleY;
                                                    enemy.character_angleX=cube_angleX;

                                                    rotate_mesh=rotate_mesh+0.05;
                                                    if(rotate_mesh==360) rotate_mesh=0;

                                                    //enemy.angle_Y=enemy.angle_Y+0.01;
                                                    
                                                    enemy.angle_Y=360-cube_angleY;
                                                    if(enemy.angle_Y==360) enemy.angle_Y=0;
                                                    
                                                    //enemy.angle_Y=rotate_mesh;
                                                    
                                                    e1.rotateAxisY_character_original(enemy.angle_Y);
                                                    e1.rotateAxisX_character_original(enemy.angle_X);
                                                    e1.moveCharacter(player_x+enemy.x,player_y+enemy.y,player_z+enemy.z);
                                                    e1.rotateAxisY_character(cube_angleY);
                                                    e1.rotateAxisX_character(cube_angleX);
                                                    //e1.calculate2dpoint_character();

                                                    e2.rotateAxisY_character_original(enemy.angle_Y);
                                                    e2.rotateAxisX_character_original(enemy.angle_X);
                                                    e2.moveCharacter(player_x+enemy.x,player_y+enemy.y,player_z+enemy.z);
                                                    e2.rotateAxisY_character(cube_angleY);
                                                    e2.rotateAxisX_character(cube_angleX);
                                                    //e2.calculate2dpoint_character();

                                                    e3.rotateAxisY_character_original(enemy.angle_Y);
                                                    e3.rotateAxisX_character_original(enemy.angle_X);
                                                    e3.moveCharacter(player_x+enemy.x,player_y+enemy.y,player_z+enemy.z);
                                                    e3.rotateAxisY_character(cube_angleY);
                                                    e3.rotateAxisX_character(cube_angleX);
                                                    //e3.calculate2dpoint_character();

                                                    //e4.rotateAxisY_character_original(rotate_mesh);
                                                    //e4.rotateAxisX_character_original(rotate_mesh);
                                                    //e4.moveCharacter(player_x+enemy.x,player_y+enemy.y,player_z+enemy.z);
                                                    //e4.rotateAxisY_character(cube_angleY);
                                                    //e4.rotateAxisX_character(cube_angleX);
                                                    //e4.calculate2dpoint_character();


                                                    e1.calculate2dpoint_character();
                                                    e2.calculate2dpoint_character();
                                                    e3.calculate2dpoint_character();
                                                    //e4.calculate2dpoint_character();

                                                    t.z=(t.v1.zro3+t.v2.zro3+t.v3.zro3)/3.0f;
                                           }
                                           
                                           if(t.v4!=null){
                                                    Point3d e1=t.v1;
                                                    Point3d e2=t.v2;
                                                    Point3d e3=t.v3;
                                                    Point3d e4=t.v4;


                                                    enemy.character_angleY=cube_angleY;
                                                    enemy.character_angleX=cube_angleX;

                                                    rotate_mesh=rotate_mesh+0.05;
                                                    
                                                    //enemy.angle_Y=enemy.angle_Y+0.05;
                                                    
                                                    if(enemy.angle_Y==360) enemy.angle_Y=0;
                                                    
                                                    if(rotate_mesh==360) rotate_mesh=0;

                                                    e1.rotateAxisY_character_original(enemy.angle_Y);
                                                    e1.rotateAxisX_character_original(enemy.angle_X);
                                                    e1.moveCharacter(player_x+enemy.x,player_y+enemy.y,player_z+enemy.z);
                                                    e1.rotateAxisY_character(cube_angleY);
                                                    e1.rotateAxisX_character(cube_angleX);
                                                    //e1.calculate2dpoint_character();

                                                    e2.rotateAxisY_character_original(enemy.angle_Y);
                                                    e2.rotateAxisX_character_original(enemy.angle_X);
                                                    e2.moveCharacter(player_x+enemy.x,player_y+enemy.y,player_z+enemy.z);
                                                    e2.rotateAxisY_character(cube_angleY);
                                                    e2.rotateAxisX_character(cube_angleX);
                                                    //e2.calculate2dpoint_character();

                                                    e3.rotateAxisY_character_original(enemy.angle_Y);
                                                    e3.rotateAxisX_character_original(enemy.angle_X);
                                                    e3.moveCharacter(player_x+enemy.x,player_y+enemy.y,player_z+enemy.z);
                                                    e3.rotateAxisY_character(cube_angleY);
                                                    e3.rotateAxisX_character(cube_angleX);
                                                    //e3.calculate2dpoint_character();

                                                    e4.rotateAxisY_character_original(enemy.angle_Y);
                                                    e4.rotateAxisX_character_original(enemy.angle_X);
                                                    e4.moveCharacter(player_x+enemy.x,player_y+enemy.y,player_z+enemy.z);
                                                    e4.rotateAxisY_character(cube_angleY);
                                                    e4.rotateAxisX_character(cube_angleX);
                                                    //e4.calculate2dpoint_character();


                                                    e1.calculate2dpoint_character();
                                                    e2.calculate2dpoint_character();
                                                    e3.calculate2dpoint_character();
                                                    e4.calculate2dpoint_character();

                                                    t.z=(t.v1.zro3+t.v2.zro3+t.v3.zro3+t.v4.zro3)/4.0f;
                                           }
                                        }
                                        
                                    }
                                    
                                    //rotate enemy
                                    
                                    //rotate lamborghini
                                    if(calculate_lambo==true){
                                    for(Lamborghini lambo:cars){
                                        
                                        /*
                                        for(Point3d p:lambo.vertices_collision)
                                        {
                                                    p.rotateAxisY_character_original(lambo.angle_Y);
                                                    p.rotateAxisX_character_original(lambo.angle_X);
                                                    p.moveCharacter(player_x+lambo.x,player_y+lambo.y,player_z+lambo.z);
                                                    p.rotateAxisY_character(cube_angleY);
                                                    p.rotateAxisX_character(cube_angleX);
                                                    p.calculate2dpoint_character();
                                                    
                                                    //g.setColor(new Color(255,0,0));
                                                    //g.fillRect(p.x2d, p.y2d, 5, 5);
                                        }
                                        */
                                        
                                        for(int q=0;q<lambo.t_list.size();q++)
                                        {
                                           Triangle t=lambo.t_list.get(q);
                                           
                                           if(t.v4==null){
                                                    Point3d e1=t.v1;
                                                    Point3d e2=t.v2;
                                                    Point3d e3=t.v3;
                                                    //Point3d e4=t.v4;


                                                    lambo.character_angleY=cube_angleY;
                                                    lambo.character_angleX=cube_angleX;

                                                    rotate_mesh=rotate_mesh+0.05;
                                                    if(rotate_mesh==360) rotate_mesh=0;

                                                    //enemy.angle_Y=enemy.angle_Y+0.01;
                                                    
                                                    //lambo.angle_Y=360-cube_angleY;
                                                    //if(lambo.angle_Y==360) lambo.angle_Y=0;
                                                    
                                                    //enemy.angle_Y=rotate_mesh;
                                                    
                                                    e1.rotateAxisY_character_original(lambo.angle_Y);
                                                    e1.rotateAxisX_character_original(lambo.angle_X);
                                                    e1.moveCharacter(player_x+lambo.x,player_y+lambo.y,player_z+lambo.z);
                                                    e1.rotateAxisY_character(cube_angleY);
                                                    e1.rotateAxisX_character(cube_angleX);
                                                    //e1.calculate2dpoint_character();

                                                    e2.rotateAxisY_character_original(lambo.angle_Y);
                                                    e2.rotateAxisX_character_original(lambo.angle_X);
                                                    e2.moveCharacter(player_x+lambo.x,player_y+lambo.y,player_z+lambo.z);
                                                    e2.rotateAxisY_character(cube_angleY);
                                                    e2.rotateAxisX_character(cube_angleX);
                                                    //e2.calculate2dpoint_character();

                                                    e3.rotateAxisY_character_original(lambo.angle_Y);
                                                    e3.rotateAxisX_character_original(lambo.angle_X);
                                                    e3.moveCharacter(player_x+lambo.x,player_y+lambo.y,player_z+lambo.z);
                                                    e3.rotateAxisY_character(cube_angleY);
                                                    e3.rotateAxisX_character(cube_angleX);
                                                    //e3.calculate2dpoint_character();

                                                    //e4.rotateAxisY_character_original(rotate_mesh);
                                                    //e4.rotateAxisX_character_original(rotate_mesh);
                                                    //e4.moveCharacter(player_x+enemy.x,player_y+enemy.y,player_z+enemy.z);
                                                    //e4.rotateAxisY_character(cube_angleY);
                                                    //e4.rotateAxisX_character(cube_angleX);
                                                    //e4.calculate2dpoint_character();


                                                    e1.calculate2dpoint_character();
                                                    e2.calculate2dpoint_character();
                                                    e3.calculate2dpoint_character();
                                                    //e4.calculate2dpoint_character();

                                                    t.z=(t.v1.zro3+t.v2.zro3+t.v3.zro3)/3.0f;
                                           }
                                           
                                           if(t.v4!=null){
                                                    Point3d e1=t.v1;
                                                    Point3d e2=t.v2;
                                                    Point3d e3=t.v3;
                                                    Point3d e4=t.v4;


                                                    lambo.character_angleY=cube_angleY;
                                                    lambo.character_angleX=cube_angleX;

                                                    rotate_mesh=rotate_mesh+0.05;
                                                    
                                                    //enemy.angle_Y=enemy.angle_Y+0.05;
                                                    
                                                    if(lambo.angle_Y==360) lambo.angle_Y=0;
                                                    
                                                    if(rotate_mesh==360) rotate_mesh=0;

                                                    e1.rotateAxisY_character_original(lambo.angle_Y);
                                                    e1.rotateAxisX_character_original(lambo.angle_X);
                                                    e1.moveCharacter(player_x+lambo.x,player_y+lambo.y,player_z+lambo.z);
                                                    e1.rotateAxisY_character(cube_angleY);
                                                    e1.rotateAxisX_character(cube_angleX);
                                                    //e1.calculate2dpoint_character();

                                                    e2.rotateAxisY_character_original(lambo.angle_Y);
                                                    e2.rotateAxisX_character_original(lambo.angle_X);
                                                    e2.moveCharacter(player_x+lambo.x,player_y+lambo.y,player_z+lambo.z);
                                                    e2.rotateAxisY_character(cube_angleY);
                                                    e2.rotateAxisX_character(cube_angleX);
                                                    //e2.calculate2dpoint_character();

                                                    e3.rotateAxisY_character_original(lambo.angle_Y);
                                                    e3.rotateAxisX_character_original(lambo.angle_X);
                                                    e3.moveCharacter(player_x+lambo.x,player_y+lambo.y,player_z+lambo.z);
                                                    e3.rotateAxisY_character(cube_angleY);
                                                    e3.rotateAxisX_character(cube_angleX);
                                                    //e3.calculate2dpoint_character();

                                                    e4.rotateAxisY_character_original(lambo.angle_Y);
                                                    e4.rotateAxisX_character_original(lambo.angle_X);
                                                    e4.moveCharacter(player_x+lambo.x,player_y+lambo.y,player_z+lambo.z);
                                                    e4.rotateAxisY_character(cube_angleY);
                                                    e4.rotateAxisX_character(cube_angleX);
                                                    //e4.calculate2dpoint_character();


                                                    e1.calculate2dpoint_character();
                                                    e2.calculate2dpoint_character();
                                                    e3.calculate2dpoint_character();
                                                    e4.calculate2dpoint_character();

                                                    t.z=(t.v1.zro3+t.v2.zro3+t.v3.zro3+t.v4.zro3)/4.0f;
                                           }
                                        }
                                        
                                    }
                                    }
                                    //rotate lamborghini
                                    
                                    //rotate gates
                                    for(Gate gate:gates){
                                        
                                        for(Point3d p:gate.vertices_collision)
                                        {
                                                    p.rotateAxisY_character_original(gate.angle_Y);
                                                    p.rotateAxisX_character_original(gate.angle_X);
                                                    p.moveCharacter(player_x+gate.x,player_y+gate.y,player_z+gate.z);
                                                    p.rotateAxisY_character(cube_angleY);
                                                    p.rotateAxisX_character(cube_angleX);
                                                    p.calculate2dpoint_character();
                                                    
                                                    //g.setColor(new Color(255,0,0));
                                                    //g.fillRect(p.x2d, p.y2d, 5, 5);
                                        }
                                        
                                        for(int q=0;q<gate.t_list.size();q++)
                                        {
                                           Triangle t=gate.t_list.get(q);
                                           
                                           if(t.v4==null){
                                                    Point3d e1=t.v1;
                                                    Point3d e2=t.v2;
                                                    Point3d e3=t.v3;
                                                    //Point3d e4=t.v4;


                                                    gate.character_angleY=cube_angleY;
                                                    gate.character_angleX=cube_angleX;

                                                    rotate_mesh=rotate_mesh+0.05;
                                                    if(rotate_mesh==360) rotate_mesh=0;

                                                    //enemy.angle_Y=enemy.angle_Y+0.01;
                                                    
                                                    gate.angle_Y=360-cube_angleY;
                                                    if(gate.angle_Y==360) gate.angle_Y=0;
                                                    
                                                    //enemy.angle_Y=rotate_mesh;
                                                    
                                                    e1.rotateAxisY_character_original(gate.angle_Y);
                                                    e1.rotateAxisX_character_original(gate.angle_X);
                                                    e1.moveCharacter(player_x+gate.x,player_y+gate.y,player_z+gate.z);
                                                    e1.rotateAxisY_character(cube_angleY);
                                                    e1.rotateAxisX_character(cube_angleX);
                                                    //e1.calculate2dpoint_character();

                                                    e2.rotateAxisY_character_original(gate.angle_Y);
                                                    e2.rotateAxisX_character_original(gate.angle_X);
                                                    e2.moveCharacter(player_x+gate.x,player_y+gate.y,player_z+gate.z);
                                                    e2.rotateAxisY_character(cube_angleY);
                                                    e2.rotateAxisX_character(cube_angleX);
                                                    //e2.calculate2dpoint_character();

                                                    e3.rotateAxisY_character_original(gate.angle_Y);
                                                    e3.rotateAxisX_character_original(gate.angle_X);
                                                    e3.moveCharacter(player_x+gate.x,player_y+gate.y,player_z+gate.z);
                                                    e3.rotateAxisY_character(cube_angleY);
                                                    e3.rotateAxisX_character(cube_angleX);
                                                    //e3.calculate2dpoint_character();

                                                    //e4.rotateAxisY_character_original(rotate_mesh);
                                                    //e4.rotateAxisX_character_original(rotate_mesh);
                                                    //e4.moveCharacter(player_x+enemy.x,player_y+enemy.y,player_z+enemy.z);
                                                    //e4.rotateAxisY_character(cube_angleY);
                                                    //e4.rotateAxisX_character(cube_angleX);
                                                    //e4.calculate2dpoint_character();


                                                    e1.calculate2dpoint_character();
                                                    e2.calculate2dpoint_character();
                                                    e3.calculate2dpoint_character();
                                                    //e4.calculate2dpoint_character();

                                                    t.z=(t.v1.zro3+t.v2.zro3+t.v3.zro3)/3.0f;
                                           }
                                           
                                           if(t.v4!=null){
                                                    Point3d e1=t.v1;
                                                    Point3d e2=t.v2;
                                                    Point3d e3=t.v3;
                                                    Point3d e4=t.v4;


                                                    gate.character_angleY=cube_angleY;
                                                    gate.character_angleX=cube_angleX;

                                                    rotate_mesh=rotate_mesh+0.05;
                                                    
                                                    //enemy.angle_Y=enemy.angle_Y+0.05;
                                                    
                                                    if(gate.angle_Y==360) gate.angle_Y=0;
                                                    
                                                    if(rotate_mesh==360) rotate_mesh=0;

                                                    e1.rotateAxisY_character_original(gate.angle_Y);
                                                    e1.rotateAxisX_character_original(gate.angle_X);
                                                    e1.moveCharacter(player_x+gate.x,player_y+gate.y,player_z+gate.z);
                                                    e1.rotateAxisY_character(cube_angleY);
                                                    e1.rotateAxisX_character(cube_angleX);
                                                    //e1.calculate2dpoint_character();

                                                    e2.rotateAxisY_character_original(gate.angle_Y);
                                                    e2.rotateAxisX_character_original(gate.angle_X);
                                                    e2.moveCharacter(player_x+gate.x,player_y+gate.y,player_z+gate.z);
                                                    e2.rotateAxisY_character(cube_angleY);
                                                    e2.rotateAxisX_character(cube_angleX);
                                                    //e2.calculate2dpoint_character();

                                                    e3.rotateAxisY_character_original(gate.angle_Y);
                                                    e3.rotateAxisX_character_original(gate.angle_X);
                                                    e3.moveCharacter(player_x+gate.x,player_y+gate.y,player_z+gate.z);
                                                    e3.rotateAxisY_character(cube_angleY);
                                                    e3.rotateAxisX_character(cube_angleX);
                                                    //e3.calculate2dpoint_character();

                                                    e4.rotateAxisY_character_original(gate.angle_Y);
                                                    e4.rotateAxisX_character_original(gate.angle_X);
                                                    e4.moveCharacter(player_x+gate.x,player_y+gate.y,player_z+gate.z);
                                                    e4.rotateAxisY_character(cube_angleY);
                                                    e4.rotateAxisX_character(cube_angleX);
                                                    //e4.calculate2dpoint_character();


                                                    e1.calculate2dpoint_character();
                                                    e2.calculate2dpoint_character();
                                                    e3.calculate2dpoint_character();
                                                    e4.calculate2dpoint_character();

                                                    t.z=(t.v1.zro3+t.v2.zro3+t.v3.zro3+t.v4.zro3)/4.0f;
                                           }
                                        }
                                        
                                    }
                                    //rotate gates
                                    }
                                    
                                    
                        auto_calibration();
                        
                        if(turn_right==true){
                        this.cube_angleY=this.cube_angleY-0.7;
                        }
                        if(turn_left==true){
                        this.cube_angleY=this.cube_angleY+0.7;
                        }
                        
                        if(turn_up==true){
                            if(lock_head==false){
                            this.cube_angleX=this.cube_angleX+0.5;
                            }
                        }
                        if(turn_down==true){
                            if(lock_head==false){
                            this.cube_angleX=this.cube_angleX-0.5;
                            }
                        }
                        
                        if(mouse_pressed==true) go_forward();
                        if(mouse_2_pressed==true) go_backward();
            }
            
            
                        for(Point3d p:additional_vertices)
                        {
                        p.rotateAxisY(cube_angleY);
                        p.rotateAxisX(cube_angleX);
                         //doom
                        if(quake==false){


                            if(doom==true)
                            {
                                if(tr_map==false){
                                p.moveVector(-500,2550,0+scale);
                                }
                                if(tr_map==true){
                                p.moveVector(0,2550,0+scale);
                                }
                            }

                        }

                        if(quake==true){
                            if(doom==true){p.moveVector(0,2550,0+scale-400);}
                        }
                        p.calculate2dpoint();
                        }
                        
                        //bullets
                        
                                    for(int q=0;q<bullets.size();q++)
                                    {
                                    Point3d p=bullets.get(q);
                                    p.rotateAxisY(cube_angleY);
                                    p.rotateAxisX(cube_angleX);
                                     //doom
                                    if(quake==false){


                                        if(doom==true)
                                        {
                                            if(tr_map==false){
                                            //p.moveVector(-500+player_x,2550+player_y,0+scale+player_z);
                                            p.moveVector(player_x,player_y,player_z);
                                            }
                                            if(tr_map==true){
                                            p.moveVector(0,2550,0+scale);
                                            }
                                        }

                                    }

                                    if(quake==true){
                                        //if(doom==true){p.moveVector(0,2550,0+scale-400);}
                                    }

                                    p.moveBullet();
                                    p.calculate2dpoint();
                                    }
                                    
            for(Point3d p:vertices_collision)
            {
            p.rotateAxisY(cube_angleY);
            p.rotateAxisX(cube_angleX);
            p.moveVector(-500,2550,0+scale);
            p.calculate2dpoint();
            }          
            
            for(Point3d p:vertices_stairs)
            {
            p.rotateAxisY(cube_angleY);
            p.rotateAxisX(cube_angleX);
            p.moveVector(-500,2550,0+scale);
            p.calculate2dpoint();
            }          
                                    
            for(Point3d p:vertices)
            {
            p.rotateAxisY(cube_angleY);
            p.rotateAxisX(cube_angleX);
            
            if(lamborghini==true){p.moveVector(50,50,0+scale);}
            
            //doom
            if(quake==false){
                
                
                if(doom==true)
                {
                    if(tr_map==false){
                    p.moveVector(0,2550,0);
                    //p.moveVector(-500,2550,0+scale);
                    }
                    if(tr_map==true){
                    p.moveVector(0,2550,0+scale);
                    }
                }
                
            }
            
            if(quake==true){
                if(doom==true){p.moveVector(0,2550,0+scale-400);}
            }
            
            //q2dm1
            //if(lamborghini==true){p.moveVector(0,0,5000+scale);}
            
            if(crash_bandicoot==true){p.moveVector(350,800,2000+scale);}
            if(tomb_raider==true){p.moveVector(100,350,450+scale);}
            
            if(tea_pot==true){p.moveVector(150,200,1200+scale);}
            
            p.calculate2dpoint();
            }
            
            for(Point3d p:vertices_xyz)
            {
            p.rotateAxisY(cube_angleY);
            p.rotateAxisX(cube_angleX);
            
            //doom
            
            if(tr_map==false){
                if(doom==true){p.moveVector(-500,2550,0+scale);}
            }
            
            if(tr_map==true){
                //if(doom==true){p.moveVector(-500-2600,2550,0+scale);}
                //p.moveVector(-500+12600,2550,0+scale);
            }
            
            p.calculate2dpoint();
            }
            
            this.repaint();
            
            update_game_input();
            
            update_elevation();
            
            
        }
    }catch(Exception exc){System.out.println(""+exc);exc.printStackTrace();}
    }
      public void paintComponent(Graphics g){
        
	super.paintComponent(g);
     
        g.setColor(Color.white);
        
        
        if(quake==true){
        g.setColor(Color.white);
        //g.setColor(new Color(0,0,255));
        }
        
        g.fillRect(0, 0, 640, 480);
        g.setColor(Color.black);
        
        
        this.g=g;
        
        g.setColor(Color.black);
        
        /*
        for(Point3d p:vertices)
        {
            p.calculate2dpoint();
            g.drawLine(p.x2d,p.y2d, p.x2d,p.y2d);
        }
        */
        
            g.setColor(Color.black);
            //punkt 0,0,0
            
        ArrayList<Triangle> triangles=new ArrayList<Triangle>();

        
        
        Triangle.total_trianles_number=0;

try{
        if(doom==true){
            
            
            
            
            g.setColor(Color.red);
        
            Point3d pc1=vertices_xyz.get(0);
            Point3d pc2=vertices_xyz.get(1);
            Point3d pc3=vertices_xyz.get(2);
            Point3d pc4=vertices_xyz.get(3);
            
            //p.rotateAxisY(angle);
            //p.rotateAxisX(angle);
            pc1.calculate2dpoint();
            pc2.calculate2dpoint();
            pc3.calculate2dpoint();
            pc4.calculate2dpoint();
            g.drawLine(pc1.x2d,pc1.y2d, pc2.x2d,pc2.y2d);
            g.drawLine(pc1.x2d,pc1.y2d, pc3.x2d,pc3.y2d);
            g.drawLine(pc1.x2d,pc1.y2d, pc4.x2d,pc4.y2d);
        
            //punkt 0,0,0
            
                //doom
                int qf=4688;
                
                
                
                
                if(tr_map==false)
                { 
                    if(quake==true) 
                    {
                        qf=65006;
                        
                        //quake test
                        //qf=33306;
                        //cube_angleX=cube_angleX+5;
                        //cube_angleX=360;
                    }
                    
                    if(quake==false) qf=4688;
                    
                    //guns fpp
                    //qf=416;
                    
                    //doom e1m2
                    //if(quake==false) qf=6900;
                    //if(quake==false) qf=111000;
                }
                
                
                if(tr_map==true) qf=3236;
                
                //for(int i=0;i<4688;i++)
                for(int i=0;i<qf;i++)
                {
                    int w1=faces.get(i);
                    
                    
                    i++;
                    int w2=faces.get(i);
                    i++;
                    int w3=faces.get(i);
                    i++;
                    
                    Integer w4=null;
                    
                    
                    if(faces.get(i)!=null)
                    {
                    
                    w4=faces.get(i);
                    
                    }
                    
                    Point3d p1=vertices.get(w1-1);
                    Point3d p2=vertices.get(w2-1);
                    Point3d p3=vertices.get(w3-1);
                    
                    Point3d p4=null;
                    
                    if(w4!=null)
                    {
                       
                    p4=vertices.get(w4-1);
                    }
                    
                    
                    
                    if(p4==null)
                    {
                    Triangle ap=new Triangle(p1,p2,p3);
                    
                    int rc=(i/10);
                    if(rc<0) rc=0;
                    if(rc>255) rc=255;
                    
                    Color c=new Color(100,100,100);
                    if(faces_color.get(i)!=null){
                    c=faces_color.get(i);
                    }
                    
                    //if(((p1.y<=p2.y+1000&&p1.y>=p2.y)&&(p1.y<=p3.y+1000&&p1.y>=p3.y))&&p1.y>-5500&&p2.y>-5500&&p3.y>-5500){c=new Color(0,0,255);ap.z=ap.z+1000000f;}
                    ArrayList<Float> min=new ArrayList<Float>();
                    min.add(p1.zr2);
                    min.add(p2.zr2);
                    min.add(p3.zr2);
                    Collections.sort(min);
                    
                    ap.z=(p1.zr2+p2.zr2+p3.zr2)/3.0f;
                    
                    if(p1.isClipped==true||p2.isClipped==true||p3.isClipped==true)
                    {
                        //c=new Color(0,0,255);
                        //ap.z=ap.z+8000f;
                        ap.z=min.get(2);
                        //ap.z=ap.z-8000f;
                    }
                    //if(p1.yr2>1000&&p2.yr2>1000&&p3.yr2>1000){c=new Color(0,0,255);}
                    
                    ap.tr_color=c;
                    
                    triangles.add(ap);
                    }
                    else
                    {
                    Triangle ap=new Triangle(p1,p2,p3,p4);
                    int rc=(i/10);
                    if(rc<0) rc=0;
                    if(rc>255) rc=255;
                    
                    Color c=faces_color.get(i);
                    
                    ArrayList<Float> min=new ArrayList<Float>();
                    min.add(p1.zr2);
                    min.add(p2.zr2);
                    min.add(p3.zr2);
                    min.add(p4.zr2);
                    Collections.sort(min);
                    
                    ap.z=(p1.zr2+p2.zr2+p3.zr2+p4.zr2)/4.0f;
                    if(p1.isClipped==true||p2.isClipped==true||p3.isClipped==true||p4.isClipped==true)
                    {
                        //c=new Color(0,0,255);
                        //ap.z=ap.z+8000f;
                        ap.z=min.get(3);
                        //ap.z=ap.z-3000f;
                    }
                    ap.tr_color=c;
                    
                    triangles.add(ap);
                    }
                    
                   
                }
                  
                       
                
                try{
                Collections.sort(triangles);
                }catch(Exception exc){};
                
                float color_v=0;

                
                
                
                
               
                
        
        
                
                //draw enemy
                //draw enemy
                        //Collections.sort(enemy.t_list);
                        ArrayList<Triangle> enemy_t=new ArrayList<Triangle>();
                        for(int i=0;i<enemies.size();i++){
                            Character enemy=enemies.get(i);
                            Point3d ec=new Point3d(player_x+enemy.x,player_y+enemy.y,player_z+enemy.z);
                            
                            
                            ec.rotateAxisY(cube_angleY);
                            ec.rotateAxisX(cube_angleX);
                            ec.calculate2dpoint();
                            //g.setColor(new Color(255,0,0));
                            //g.drawOval(ec.x2d-100,ec.y2d-100, 200,200);
                            
                         //add enemy triangles
                        //for(Triangle t:enemy.t_list)
                        for(int q=0;q<enemy.t_list.size();q++)
                        {
                        Triangle t=enemy.t_list.get(q);
                        
                        Triangle nt=null;
                        
                        if(t.v4==null){
                            nt=new Triangle(t.v1,t.v2,t.v3);
                        }
                        
                        if(t.v4!=null){
                            nt=new Triangle(t.v1,t.v2,t.v3,t.v4);
                        }
                        nt.z=t.z;
                        nt.ai_set=enemy.ai_set;
                        nt.tr_color=t.tr_color;
                        
                        //if(enemy.alive==false) nt.tr_color=new Color(255,0,0);
                        
                        enemy_t.add(nt);
                        }
                        }
                        
                        try{
                        Collections.sort(enemy_t);
                        }catch(Exception exc){}
                        
                        //for(int q=0;q<enemy.t_list.size();q++)
                        for(int q=0;q<enemy_t.size();q++)
                        {
                        
                        //Triangle t=enemy.t_list.get(q);
                        Triangle t=enemy_t.get(q);
                        
                        t.ai_set=t.ai_set;
                        
                        
                        
                        
                        Point3d e1=t.v1;
                        Point3d e2=t.v2;
                        Point3d e3=t.v3;
                        Point3d e4=null;
                        if(t.v4!=null){
                            e4=t.v4;
                        }
                        
                        try{
                        t.v1.calculate2dpoint_character();
                        t.v2.calculate2dpoint_character();
                        t.v3.calculate2dpoint_character();
                        
                        if(t.v4!=null){
                        t.v4.calculate2dpoint_character();
                        }
                        
                        if(t.v4==null){
                        //Polygon poly=new Polygon();
                        //poly.addPoint(t.v1.x2d, t.v1.y2d);
                        //poly.addPoint(t.v2.x2d, t.v2.y2d);
                        //poly.addPoint(t.v3.x2d, t.v3.y2d);
                        //g.setColor(t.tr_color);
                        
                        //g.fillPolygon(poly);
                        
                        //g.setColor(new Color(0,0,0));
                        //g.drawLine(e1.x2d,e1.y2d, e2.x2d,e2.y2d);
                        //g.drawLine(e2.x2d,e2.y2d, e3.x2d,e3.y2d);
                        //g.drawLine(e3.x2d,e3.y2d, e1.x2d,e1.y2d);
                        
                        
                        t.v1.zr2=t.v1.zro3;
                        t.v2.zr2=t.v2.zro3;
                        t.v3.zr2=t.v3.zro3;
                        
                        //t.tr_color=new Color(0,0,0);
                        }
                        
                        if(t.v4!=null){
                        //Polygon poly=new Polygon();
                        //poly.addPoint(t.v1.x2d, t.v1.y2d);
                        //poly.addPoint(t.v2.x2d, t.v2.y2d);
                        //poly.addPoint(t.v3.x2d, t.v3.y2d);
                        //poly.addPoint(t.v4.x2d, t.v4.y2d);
                        //g.setColor(t.tr_color);
                        
                        //g.fillPolygon(poly);
                        
                        //g.setColor(new Color(0,0,0));
                        //g.drawLine(e1.x2d,e1.y2d, e2.x2d,e2.y2d);
                        //g.drawLine(e2.x2d,e2.y2d, e3.x2d,e3.y2d);
                        //g.drawLine(e3.x2d,e3.y2d, e4.x2d,e4.y2d);
                        //g.drawLine(e4.x2d,e4.y2d, e1.x2d,e1.y2d);
                        
                        
                        t.v1.zr2=t.v1.zro3;
                        t.v2.zr2=t.v2.zro3;
                        t.v3.zr2=t.v3.zro3;
                        t.v4.zr2=t.v4.zro3;
                        
                        /*
                        int red=t.tr_color.getRed()+(int)(t.v1.zr2*0.02);
                        int green=t.tr_color.getGreen()+(int)(t.v1.zr2*0.02);
                        int blue=t.tr_color.getBlue()+(int)(t.v1.zr2*0.02);
                        if(green>255) green=255;if(green<0) green=0;
                        if(blue>255) blue=255;if(blue<0) blue=0;
                        if(red>255) red=255;if(red<0) red=0;
                        */
                        
                        //t.tr_color=new Color(255,255,255);
                        
                        }
                        
                        }catch(Exception exc){};
                        
                        t.isCharacter=true;
                        triangles.add(t);
                        }
                        
                        try{
                        Collections.sort(triangles);
                        }catch(Exception exc){};
                //draw enemy
                
                
                //draw lamborghini
                if(calculate_lambo==true){
                        //Collections.sort(enemy.t_list);
                        ArrayList<Triangle> lambo_t=new ArrayList<Triangle>();
                        for(int i=0;i<cars.size();i++){
                            Lamborghini lambo=cars.get(i);
                            Point3d ec=new Point3d(player_x+lambo.x,player_y+lambo.y,player_z+lambo.z);
                            
                            
                            ec.rotateAxisY(cube_angleY);
                            ec.rotateAxisX(cube_angleX);
                            ec.calculate2dpoint();
                            //g.setColor(new Color(255,0,0));
                            //g.drawOval(ec.x2d-100,ec.y2d-100, 200,200);
                            
                         //add enemy triangles
                        //for(Triangle t:enemy.t_list)
                        for(int q=0;q<lambo.t_list.size();q++)
                        {
                        Triangle t=lambo.t_list.get(q);
                        
                        Triangle nt=null;
                        
                        if(t.v4==null){
                            nt=new Triangle(t.v1,t.v2,t.v3);
                        }
                        
                        if(t.v4!=null){
                            nt=new Triangle(t.v1,t.v2,t.v3,t.v4);
                        }
                        nt.z=t.z;
                        
                        nt.tr_color=t.tr_color;
                        nt.tr_color=lambo.gate_color;
                        
                        nt.isLambo=true;
                        
                        //if(enemy.alive==false) nt.tr_color=new Color(255,0,0);
                        
                        lambo_t.add(nt);
                        }
                        }
                        
                        try{
                        Collections.sort(lambo_t);
                        }catch(Exception exc){}
                        
                        //for(int q=0;q<enemy.t_list.size();q++)
                        for(int q=0;q<lambo_t.size();q++)
                        {
                        
                        //Triangle t=enemy.t_list.get(q);
                        Triangle t=lambo_t.get(q);
                        
                        Point3d e1=t.v1;
                        Point3d e2=t.v2;
                        Point3d e3=t.v3;
                        Point3d e4=null;
                        if(t.v4!=null){
                            e4=t.v4;
                        }
                        
                        try{
                        t.v1.calculate2dpoint_character();
                        t.v2.calculate2dpoint_character();
                        t.v3.calculate2dpoint_character();
                        
                        if(t.v4!=null){
                        t.v4.calculate2dpoint_character();
                        }
                        
                        if(t.v4==null){
                        //Polygon poly=new Polygon();
                        //poly.addPoint(t.v1.x2d, t.v1.y2d);
                        //poly.addPoint(t.v2.x2d, t.v2.y2d);
                        //poly.addPoint(t.v3.x2d, t.v3.y2d);
                        //g.setColor(t.tr_color);
                        
                        //g.fillPolygon(poly);
                        
                        //g.setColor(new Color(0,0,0));
                        //g.drawLine(e1.x2d,e1.y2d, e2.x2d,e2.y2d);
                        //g.drawLine(e2.x2d,e2.y2d, e3.x2d,e3.y2d);
                        //g.drawLine(e3.x2d,e3.y2d, e1.x2d,e1.y2d);
                        
                        
                        t.v1.zr2=t.v1.zro3;
                        t.v2.zr2=t.v2.zro3;
                        t.v3.zr2=t.v3.zro3;
                        
                        //t.tr_color=new Color(0,0,0);
                        }
                        
                        if(t.v4!=null){
                        //Polygon poly=new Polygon();
                        //poly.addPoint(t.v1.x2d, t.v1.y2d);
                        //poly.addPoint(t.v2.x2d, t.v2.y2d);
                        //poly.addPoint(t.v3.x2d, t.v3.y2d);
                        //poly.addPoint(t.v4.x2d, t.v4.y2d);
                        //g.setColor(t.tr_color);
                        
                        //g.fillPolygon(poly);
                        
                        //g.setColor(new Color(0,0,0));
                        //g.drawLine(e1.x2d,e1.y2d, e2.x2d,e2.y2d);
                        //g.drawLine(e2.x2d,e2.y2d, e3.x2d,e3.y2d);
                        //g.drawLine(e3.x2d,e3.y2d, e4.x2d,e4.y2d);
                        //g.drawLine(e4.x2d,e4.y2d, e1.x2d,e1.y2d);
                        
                        
                        t.v1.zr2=t.v1.zro3;
                        t.v2.zr2=t.v2.zro3;
                        t.v3.zr2=t.v3.zro3;
                        t.v4.zr2=t.v4.zro3;
                        
                        /*
                        int red=t.tr_color.getRed()+(int)(t.v1.zr2*0.02);
                        int green=t.tr_color.getGreen()+(int)(t.v1.zr2*0.02);
                        int blue=t.tr_color.getBlue()+(int)(t.v1.zr2*0.02);
                        if(green>255) green=255;if(green<0) green=0;
                        if(blue>255) blue=255;if(blue<0) blue=0;
                        if(red>255) red=255;if(red<0) red=0;
                        */
                        
                        //t.tr_color=new Color(255,255,255);
                        
                        }
                        
                        }catch(Exception exc){};
                        
                        t.isCharacter=false;
                        t.isLambo=true;
                        
                        triangles.add(t);
                        }
                        
                        try{
                        Collections.sort(triangles);
                        }catch(Exception exc){};
                }
                //draw lamborghini
                
                //draw gates
                        //Collections.sort(enemy.t_list);
                        ArrayList<Triangle> gate_t=new ArrayList<Triangle>();
                        for(int i=0;i<gates.size();i++){
                            Gate gate=gates.get(i);
                            Point3d ec=new Point3d(player_x+gate.x,player_y+gate.y,player_z+gate.z);
                            
                            
                            ec.rotateAxisY(cube_angleY);
                            ec.rotateAxisX(cube_angleX);
                            ec.calculate2dpoint();
                            //g.setColor(new Color(255,0,0));
                            //g.drawOval(ec.x2d-100,ec.y2d-100, 200,200);
                            
                         //add enemy triangles
                        //for(Triangle t:enemy.t_list)
                        for(int q=0;q<gate.t_list.size();q++)
                        {
                        Triangle t=gate.t_list.get(q);
                        
                        Triangle nt=null;
                        
                        if(t.v4==null){
                            nt=new Triangle(t.v1,t.v2,t.v3);
                        }
                        
                        if(t.v4!=null){
                            nt=new Triangle(t.v1,t.v2,t.v3,t.v4);
                        }
                        nt.z=t.z;
                        
                        nt.tr_color=t.tr_color;
                        nt.tr_color=gate.gate_color;
                        
                        nt.isGate=true;
                        
                        //if(enemy.alive==false) nt.tr_color=new Color(255,0,0);
                        
                        gate_t.add(nt);
                        }
                        }
                        
                        try{
                        Collections.sort(gate_t);
                        }catch(Exception exc){}
                        
                        //for(int q=0;q<enemy.t_list.size();q++)
                        for(int q=0;q<gate_t.size();q++)
                        {
                        
                        //Triangle t=enemy.t_list.get(q);
                        Triangle t=gate_t.get(q);
                        
                        Point3d e1=t.v1;
                        Point3d e2=t.v2;
                        Point3d e3=t.v3;
                        Point3d e4=null;
                        if(t.v4!=null){
                            e4=t.v4;
                        }
                        
                        try{
                        t.v1.calculate2dpoint_character();
                        t.v2.calculate2dpoint_character();
                        t.v3.calculate2dpoint_character();
                        
                        if(t.v4!=null){
                        t.v4.calculate2dpoint_character();
                        }
                        
                        if(t.v4==null){
                        //Polygon poly=new Polygon();
                        //poly.addPoint(t.v1.x2d, t.v1.y2d);
                        //poly.addPoint(t.v2.x2d, t.v2.y2d);
                        //poly.addPoint(t.v3.x2d, t.v3.y2d);
                        //g.setColor(t.tr_color);
                        
                        //g.fillPolygon(poly);
                        
                        //g.setColor(new Color(0,0,0));
                        //g.drawLine(e1.x2d,e1.y2d, e2.x2d,e2.y2d);
                        //g.drawLine(e2.x2d,e2.y2d, e3.x2d,e3.y2d);
                        //g.drawLine(e3.x2d,e3.y2d, e1.x2d,e1.y2d);
                        
                        
                        t.v1.zr2=t.v1.zro3;
                        t.v2.zr2=t.v2.zro3;
                        t.v3.zr2=t.v3.zro3;
                        
                        //t.tr_color=new Color(0,0,0);
                        }
                        
                        if(t.v4!=null){
                        //Polygon poly=new Polygon();
                        //poly.addPoint(t.v1.x2d, t.v1.y2d);
                        //poly.addPoint(t.v2.x2d, t.v2.y2d);
                        //poly.addPoint(t.v3.x2d, t.v3.y2d);
                        //poly.addPoint(t.v4.x2d, t.v4.y2d);
                        //g.setColor(t.tr_color);
                        
                        //g.fillPolygon(poly);
                        
                        //g.setColor(new Color(0,0,0));
                        //g.drawLine(e1.x2d,e1.y2d, e2.x2d,e2.y2d);
                        //g.drawLine(e2.x2d,e2.y2d, e3.x2d,e3.y2d);
                        //g.drawLine(e3.x2d,e3.y2d, e4.x2d,e4.y2d);
                        //g.drawLine(e4.x2d,e4.y2d, e1.x2d,e1.y2d);
                        
                        
                        t.v1.zr2=t.v1.zro3;
                        t.v2.zr2=t.v2.zro3;
                        t.v3.zr2=t.v3.zro3;
                        t.v4.zr2=t.v4.zro3;
                        
                        /*
                        int red=t.tr_color.getRed()+(int)(t.v1.zr2*0.02);
                        int green=t.tr_color.getGreen()+(int)(t.v1.zr2*0.02);
                        int blue=t.tr_color.getBlue()+(int)(t.v1.zr2*0.02);
                        if(green>255) green=255;if(green<0) green=0;
                        if(blue>255) blue=255;if(blue<0) blue=0;
                        if(red>255) red=255;if(red<0) red=0;
                        */
                        
                        //t.tr_color=new Color(255,255,255);
                        
                        }
                        
                        }catch(Exception exc){};
                        
                        t.isCharacter=false;
                        t.isGate=true;
                        
                        triangles.add(t);
                        }
                        
                        try{
                        Collections.sort(triangles);
                        }catch(Exception exc){};
                //draw gates
                
                
                //draw guns
                //delta=1;
                int shot_anim_range=0;
                
                if(shot_animation==0) shot_anim_range=20;
                if(shot_animation==1) shot_anim_range=20;
                if(shot_animation==2) shot_anim_range=45;
                if(shot_animation==3) shot_anim_range=45;
                if(shot_animation==4) shot_anim_range=90;
                if(shot_animation==5) shot_anim_range=90;
                
                
                if(shot_anim==true){
                //if(shot_once==false){
                    //if(shot_pressed==true)
                    //{
                            if(delta<shot_anim_range){
                                
                                if(shot_anim_range==90) delta=delta+3; else delta=delta+2;
                                
                                if(delta>=shot_anim_range)
                                {
                                    shot_anim=false;
                                    if(shot_anim_range!=90) delta=0;
                                    shot_anim_2=true;
                                }
                            }
                    
                    //}
                //}
                }
                if(shot_anim_2==true)
                {
                delta=delta-1;
                if(delta<=0){delta=0;shot_anim_2=false;}
                }
                
                for(Triangle t:triangles_weapon)
                {
                Point3d w1=t.v1;
                Point3d w2=t.v2;
                Point3d w3=t.v3;
                Point3d w4=t.v4;
                
                w1.rotateAxisY(90);
                w1.rotateAxisX(delta+0.1);
                w2.rotateAxisY(90);
                w2.rotateAxisX(delta+0.1);
                w3.rotateAxisY(90);
                w3.rotateAxisX(delta+0.1);
                
                
                w1.xr2=w1.xr2-120;
                w2.xr2=w2.xr2-120;
                w3.xr2=w3.xr2-120;
                
                w1.yr2=w1.yr2+50;
                w2.yr2=w2.yr2+50;
                w3.yr2=w3.yr2+50;
                
                w1.zr2=w1.zr2-50;
                w2.zr2=w2.zr2-50;
                w3.zr2=w3.zr2-50;
                
                t.z=(w1.zr2+w2.zr2+w3.zr2)/3f;
                
                if(w4!=null)
                {
                w4.rotateAxisY(90);
                w4.rotateAxisX(delta+0.1);
                w4.xr2=w4.xr2-120;
                w4.yr2=w4.yr2+50;
                w4.zr2=w4.zr2-50;
                t.z=(w1.zr2+w2.zr2+w3.zr2+w4.zr2)/4f;
                }
                
                w1.calculate2dpoint();
                w2.calculate2dpoint();
                w3.calculate2dpoint();
                if(w4!=null)
                {
                w4.calculate2dpoint();
                }
                
                }
                Collections.sort(triangles_weapon);
                
                
                
                //Collections.sort(triangles);
                
                
                //draw main arraylist of triangles - draw map
                for(Triangle t:triangles)
                {
                    Polygon poly=new Polygon();
                    poly.addPoint(t.v1.x2d,t.v1.y2d);
                    poly.addPoint(t.v2.x2d,t.v2.y2d);
                    poly.addPoint(t.v3.x2d,t.v3.y2d);
                    
                    
                    
                    Polygon poly2=new Polygon();
                   
                    quake_standard_shading=false;
                    if(quake_standard_shading==true) color_v=t.v1.zr2*0.01f;
                    
                    
                    if(t.v4!=null)
                    {
                    poly.addPoint(t.v4.x2d,t.v4.y2d);
                         
                    poly2.addPoint(t.v1.x2d,t.v1.y2d);
                    poly2.addPoint(t.v3.x2d,t.v3.y2d);
                    poly2.addPoint(t.v4.x2d,t.v4.y2d);
                    }
                   
                    
                    int color=250;
                    color=250-(int)color_v;
                    //color=250;
                    
                    
                    //color=100-(int)(33*t.v1.zr2);
                    if(color>255) color=255;
                    if(color<0) color=0;
                    
                    Polygon t_raster=new Polygon();
                     
                    if(tr_map==true){
                        t.minus=true;

                        if(calculate_normals==true){
                            t.m=100;
                            
                            float n=250-t.calculateNormal();
                            color=(int)(n);
                            if(color>255) color=255;
                            if(color<200) color=200;
                        }
                    }
                    
                    if(tr_map==false){
                        t.minus=true;
                        
                        color=250-(int)(color_v);
                        if(color>255) color=100;
                        if(color<100) color=100;
                            
                        if(calculate_normals==true){
                            float n=t.calculateNormal();
                            
                            color=200-(int)(n);
                            //color=100+(int)n;
                            
                            
                            if(color>255) color=255;
                            if(color<0) color=0;
                        }
                    }
                    
                    
                    g.setColor(new Color(color,color,color));
                    
                    if(quake==true){
                        color=(int)(color);
                        if(color>255) color=255;
                        if(color<0) color=0;
                        g.setColor(new Color(color,color,color));
                    }
                    
                    
                                    
                    int dd=0;
                    //dd=-7500;
                    
                    dd=-20000;
                    //dd=0;
                    //dla doom2
                    //dd=-5000;
                    //if(t.calculateNormal()>0){
                    
                    if(t.v1.zr2>dd&&t.v2.zr2>dd&&t.v3.zr2>dd&&(t.v4==null||t.v4.zr2>dd)&&t.isBullet==true){
                        Point3d p=t.v1;
                        Point3d p2=t.v2;
                        Point3d bp1=t.v3;
                        Point3d bp2=t.v4;
                    g.setColor(t.tr_color);
                    g.drawLine(p.x2d,p.y2d, p2.x2d,p2.y2d);
                    g.drawLine(bp1.x2d,bp1.y2d, bp2.x2d,bp2.y2d);
                    g.drawLine(p.x2d,p.y2d, bp1.x2d,bp1.y2d);
                    g.drawLine(p2.x2d,p2.y2d, bp2.x2d,bp2.y2d);
                    }
                
                    if(t.v1.zr2>dd&&t.v2.zr2>dd&&t.v3.zr2>dd&&(t.v4==null||t.v4.zr2>dd)&&t.isBullet==false){
                            if(wire_frame==false)
                            {
                            //(x–x1)/(x2–x1)  = (y–y1)/(y2–y1) = (z–z1)/(z2–z1)  
                            //(x–x1)/(x2–x1)  = (y–y1)/(y2–y1) = (0–z1)/(z2–z1)  
                                //g.setColor(new Color(255,255,255));
                                
                                
                                //if(t.v1.zr2<=0&&t.v2.zr2<=0&&t.v3.zr2<=0&&(t.v4==null||t.v4.zr2<=0))
                                //{
                                boolean visible_t=true;
                                    g.setColor(t.tr_color);
                                    //g.setColor(new Color(255,255,255));
                                    
                                    if(t.isLambo==true)
                                    {
                                    g.setColor(new Color(50,50,50));
                                    }
                                    
                                    if(t.isGate==true)
                                    {
                                    //g.setColor(new Color(0,0,255));
                                    }
                                    
                                    if(((t.v1.x2d<0||t.v1.x2d>640)&&(t.v2.x2d<0||t.v2.x2d>640)&&(t.v3.x2d<0||t.v3.x2d>640)&&(t.v4==null||(t.v4.x2d<0||t.v4.x2d>640)))&&((t.v1.y2d<0||t.v1.y2d>480)&&(t.v2.y2d<0||t.v2.y2d>480)&&(t.v3.y2d<0||t.v3.y2d>480)&&(t.v4==null||(t.v4.y2d<0||t.v4.y2d>480)))){visible_t=false;}
                                    
                                    
                                    if(visible_t==true&&t.isBullet==false) g.fillPolygon(poly);
                                    
                                //s}

                            //g.fillPolygon(poly2);
                            //g.fillPolygon(poly3);
                            //g.fillPolygon(poly4);
                            }
                    
                            g.setColor(new Color(0,0,0));
                    
                            if(t.isGate==true)
                            {
                                //g.setColor(new Color(0,0,255));
                            }
                            
                            g.drawLine(t.v1.x2d,t.v1.y2d, t.v2.x2d,t.v2.y2d);
                            g.drawLine(t.v2.x2d,t.v2.y2d, t.v3.x2d,t.v3.y2d);
                            
                            
                            if(t.v4==null)
                            {
                                g.drawLine(t.v3.x2d,t.v3.y2d, t.v1.x2d,t.v1.y2d);
                            }

                            if(t.v4!=null)
                            {
                                
                                g.drawLine(t.v3.x2d,t.v3.y2d, t.v4.x2d,t.v4.y2d);
                                g.drawLine(t.v4.x2d,t.v4.y2d, t.v1.x2d,t.v1.y2d);
                                
                            }
                            
                            g.setColor(new Color(color,color,color));
                            
                            /*
                            if(t.isCharacter==true)
                            {
                                  if(t.ai_set==3){    
                                        g.setColor(new Color(0,0,0));
                                        g.drawLine(t.v1.x2d-10,t.v1.y2d, t.v2.x2d-10,t.v2.y2d);
                                        g.drawLine(t.v1.x2d-15,t.v1.y2d, t.v2.x2d-15,t.v2.y2d);
                                        g.drawLine(t.v1.x2d-20,t.v1.y2d, t.v2.x2d-20,t.v2.y2d);
                                  }
                                  
                                  if(t.ai_set==4){    
                                        g.setColor(new Color(0,0,0));
                                        g.drawLine(t.v1.x2d+10,t.v1.y2d, t.v2.x2d+10,t.v2.y2d);
                                        g.drawLine(t.v1.x2d+15,t.v1.y2d, t.v2.x2d+15,t.v2.y2d);
                                        g.drawLine(t.v1.x2d+20,t.v1.y2d, t.v2.x2d+20,t.v2.y2d);
                                  }
                                        
                                        g.setColor(new Color(0,0,0));
                                        g.drawLine(t.v1.x2d,t.v1.y2d, t.v2.x2d,t.v2.y2d);
                                        g.drawLine(t.v2.x2d,t.v2.y2d, t.v3.x2d,t.v3.y2d);

                                        if(t.v4==null)
                                        {
                                        g.drawLine(t.v3.x2d,t.v3.y2d, t.v1.x2d,t.v1.y2d);
                                        }

                                        if(t.v4!=null)
                                        {
                                        g.drawLine(t.v3.x2d,t.v3.y2d, t.v4.x2d,t.v4.y2d);
                                        g.drawLine(t.v4.x2d,t.v4.y2d, t.v1.x2d,t.v1.y2d);
                                        }

                                        g.setColor(new Color(color,color,color));
                                   
                            }*/
                   }
                   
                   //} 
                    
                    //additional triangle list
                    else
                    {
                        //test_triangle=new Triangle(additional_vertices.get(0),additional_vertices.get(1),additional_vertices.get(2),additional_vertices.get(3));
                        //triangles_2.add(t);
                        
                        //triangles_2.add(t);
                        
                    }
                    //triangle list for clipping 
                }
                        
                        
                        
                        
                        //move enemies
                        for(int q=0;q<enemies.size();q++){
                            //enemies.get(q).move_character(enemies.get(q).x,enemies.get(q).y,enemies.get(q).z);
                            enemies.get(q).update_character_ai();
                            
                            //enemies.get(q).rotate_character(45, 45);
                        }
                        
                        
        //draw bullets
        ArrayList<Point3d> bullets_2=new ArrayList<Point3d>();
        //java.util.List<Point3d> bullets_2=new ArrayList<Point3d>();
        
        
        
        for(int q=0;q<bullets.size()-1;q++)
        {
            Point3d p=bullets.get(q);
            p.rotateAxisY(cube_angleY);
            p.rotateAxisX(cube_angleX);
            p.calculate2dpoint();
            g.setColor(new Color(255,0,0));
            
            
            
            
            q++;
            Point3d p2=bullets.get(q);
            p2.rotateAxisY(cube_angleY);
            p2.rotateAxisX(cube_angleX);
            p2.calculate2dpoint();
            g.setColor(new Color(255,0,0));
            
            
            
            //if(p.bullet_live<2800){
            int bullet_time_to_live=1550;
            
            if(p.isPlayerBullet==true){bullet_time_to_live=150;}
            
            if(p.bullet_live<bullet_time_to_live){
            Point3d bp1=new Point3d(p.xr2,p.yr2,p.zr2);
            Point3d bp2=new Point3d(p2.xr2,p2.yr2-30,p2.zr2);
            bp1.rotateAxisY(0);
            bp1.rotateAxisX(0);
            bp2.rotateAxisY(0);
            bp2.rotateAxisX(0);
            bp1.calculate2dpoint();
            bp2.calculate2dpoint();
            p2.moveVector(0,30,0);
            p2.calculate2dpoint();
            
            if(p.isPlayerBullet==true&&p.bullet_live<33){}else{
                Polygon bullet_poly=new Polygon();
                g.setColor(Color.red);
                bullet_poly.addPoint(p.x2d,p.y2d);
                bullet_poly.addPoint(p2.x2d,p2.y2d);
                bullet_poly.addPoint(bp2.x2d,bp2.y2d);
                bullet_poly.addPoint(bp1.x2d,bp1.y2d);
                g.fillPolygon(bullet_poly);
            
            
                //create quad triangle of bullet to draw
                Triangle tb=new Triangle(p,p2,p,p2);
                tb.tr_color=new Color(255,0,0);
                tb.isBullet=true;

                //triangles.add(tb);

                    g.drawLine(p.x2d,p.y2d, p2.x2d,p2.y2d);
                    g.drawLine(bp1.x2d,bp1.y2d, bp2.x2d,bp2.y2d);
                    g.drawLine(p.x2d,p.y2d, bp1.x2d,bp1.y2d);
                    g.drawLine(p2.x2d,p2.y2d, bp2.x2d,bp2.y2d);
            }    
            //g.drawOval(p.x2d,p.y2d,5,5);
            bullets_2.add(p);
            bullets_2.add(p2);
            
            
            
            Random r=new Random();
            int rnd=r.nextInt(3);
            
            int random_location_x=r.nextInt(5000);
            int random_location_y=r.nextInt(1000);
            int random_location_z=r.nextInt(5000);
           
            
            //check_collision_with_player
            if(p.isPlayerBullet==false)
            {
                if(check_collision_with_player(p)==true)
                {
                //System.out.println("Player get hit");
                    if(energy>0) energy=energy-0.3;
                };
            }
            
            
            //check collision bullets with enemies
            if(p.isPlayerBullet==true){
                        for(Character enemy:enemies){
                            if((enemy.collision(p))==true)
                            {
                                //System.out.println("shot down 1");


                                if(enemy.alive==true)
                                {
                                    enemy.alive=false;
                                    
                                    robots++;
                                    
                                    if(robots<5){
                                    enemy.set_character_location(-random_location_x, 0, -random_location_z);
                                    }
                                    
                                    //gate_2.move_character(-60000,1100,-22800);
                                    //gate_3.move_character(-83500,2100,16800);
                                    //gate_4.move_character(-83500,2100,56800);
                                    
                                    if(robots==5) gates.get(0).is_opening=true;
                                    if(robots==5)
                                    {
                                    enemy.set_character_location(-40000,0,-22800);
                                    }
                                    
                                    
                                    if(robots==6) gates.get(1).is_opening=true;
                                    if(robots==6)
                                    {
                                    enemy.set_character_location(-83500,600,5800);
                                    }
                                    
                                    if(robots==7) gates.get(2).is_opening=true;
                                    if(robots==7)
                                    {
                                    enemy.set_character_location(-83500,600,47800);
                                    }
                                    
                                    if(robots==8) gates.get(3).is_opening=true;
                                    if(robots==8)
                                    {
                                    enemy.set_character_location(-40000,0,-25500);
                                    }
                                    
                                    //enemy.set_character_location(100,100,100);
                                    //if(rnd==0) enemy.move_character(-300,0,0);
                                    //if(rnd==1) enemy.move_character(300,0,0);
                                    //if(rnd==2) enemy.move_character(0,0,-300);
                                    //if(rnd==3) enemy.move_character(0,0,300);

                                } else 
                                {
                                    enemy.alive=true;

                                    //if(rnd==0) enemy.move_character(-300,0,0);
                                    //if(rnd==1) enemy.move_character(300,0,0);
                                    //if(rnd==2) enemy.move_character(0,0,-300);
                                    //if(rnd==3) enemy.move_character(0,0,300);
                                }
                            }
                        }
            }
            /*
            if((enemies.get(0).collision(p))==true)
            {
                //System.out.println("shot down 1");
                if(enemies.get(0).alive==true)
                {
                    enemies.get(0).alive=false;
                } else enemies.get(0).alive=true;
            }
            
            if((enemies.get(1).collision(p))==true)
            {
                //System.out.println("shot down 2");
                if(enemies.get(1).alive==true)
                {
                enemies.get(1).alive=false;
                }else enemies.get(1).alive=true;
            }
            */
            
            //System.out.println(enemies.get(0).collision(p));
            //System.out.println(enemies.get(1).collision(p));
            }
            //if(p.bullet_live>20) bullets.
     
        }
        bullets=bullets_2;
        //System.out.println(bullets.size());
        //draw bullets
        
        
                    int shot_r=rn.nextInt(300);
                    if(shot_r==1){make_enemy_shot(0);}
                    if(shot_r==2){make_enemy_shot(1);}
                    if(shot_r==3){make_enemy_shot(2);}
                    
        //draw target circle
        if(draw_target==true){
        for(Character enemy:enemies){
                            
                            Point3d ec=new Point3d(player_x+enemy.x,player_y+enemy.y,player_z+enemy.z);
                            Point3d ec2=new Point3d(player_x+enemy.x+500,player_y+enemy.y+500,player_z+enemy.z+500);
                            
                            ec.rotateAxisY(cube_angleY);
                            ec.rotateAxisX(cube_angleX);
                            ec.calculate2dpoint();
                            
                            ec2.rotateAxisY(cube_angleY);
                            ec2.rotateAxisX(cube_angleX);
                            ec2.calculate2dpoint();
                            
                            g.setColor(new Color(255,0,0));
                            g.drawOval(ec.x2d-25,ec.y2d-25,50,50);
        }
        }
        //draw target circle


        
                                           Character enemy2=enemies.get(0);
                                           
                                           Point3d ec=new Point3d(enemy2.x,enemy2.y,enemy2.z);
                                           Point3d ec2=new Point3d(player_x,player_y,player_z);
                            
                                           ec.rotateAxisY(cube_angleY);
                                           ec.rotateAxisX(cube_angleX);
                                           ec.calculate2dpoint();
                                           
                                           ec2.rotateAxisY(cube_angleY);
                                           ec2.rotateAxisX(cube_angleX);
                                           ec2.calculate2dpoint();
                            
                                           //g.setColor(Color.BLACK);
                                           //g.drawString(""+ec.x+" "+ec.y+" "+ec.z, 10, 370);
                                           //g.drawString(""+ec2.x+" "+ec2.y+" "+ec2.z, 10, 380);
        //draw weapon
        Collections.sort(triangles_weapon);
        for(Triangle t:triangles_weapon)
        {
            
            Polygon poly=new Polygon();
            poly.addPoint(t.v1.x2d, t.v1.y2d);
            poly.addPoint(t.v2.x2d, t.v2.y2d);
            poly.addPoint(t.v3.x2d, t.v3.y2d);
            if(t.v4!=null)
            {
            poly.addPoint(t.v4.x2d, t.v4.y2d);
            }
            
            
            g.setColor(new Color(100,100,100));
            g.fillPolygon(poly);
            
            g.setColor(new Color(0,0,0));
            g.drawLine(t.v1.x2d, t.v1.y2d,t.v2.x2d, t.v2.y2d);
            g.drawLine(t.v2.x2d, t.v2.y2d,t.v3.x2d, t.v3.y2d);
            
            if(t.v4==null){
            g.drawLine(t.v3.x2d, t.v3.y2d,t.v1.x2d, t.v1.y2d);
            } else
            {
            g.drawLine(t.v3.x2d, t.v3.y2d,t.v4.x2d, t.v4.y2d);
            g.drawLine(t.v4.x2d, t.v4.y2d,t.v1.x2d, t.v1.y2d);
            }    
            
        }
        //celownik
        g.setColor(Color.BLACK);
        g.drawOval(320-1,320-1,2,2);
        
        
        g.drawLine(320-20, 320,320-10,320);
        g.drawLine(320+20, 320,320+10,320);
        
        g.drawLine(320,320-20, 320,320-10);
        g.drawLine(320,320+20, 320,320+10);
        
        //energia
            if(game_mode==false){
            g.drawRect(630-300, 70, 300, 15);
            g.setColor(new Color(0,255,0));
            g.fillRect(630-299, 71, (int)energy*3-1, 14);
            }
            
            if(game_mode==true){
            g.fillRect(0, 0, 640, 60);
            
            //g.fillRect(0, 480, 640, 480+60);
            //g.drawRect(10, 10, 300, 15);
            //g.setColor(new Color(0,255,0));
            //g.fillRect(11, 11, (int)energy*3-1, 14);
            g.drawRect(630-300, 70, 300, 15);
            g.setColor(new Color(0,255,0));
            g.fillRect(630-299, 71, (int)energy*3-1, 14);
            }
            
            
            
            if(show_collision==true){
            //draw collision boxes
            //for(Point3d p:vertices_collision)
            for(int q=0;q<vertices_collision.size()-7;q++)
            {
            
            Point3d p=vertices_collision.get(q);p.calculate2dpoint();q++;
            Point3d p2=vertices_collision.get(q);p2.calculate2dpoint();q++;
            
            Point3d p3=vertices_collision.get(q);p3.calculate2dpoint();q++;
            Point3d p4=vertices_collision.get(q);p4.calculate2dpoint();q++;
            Point3d p5=vertices_collision.get(q);p5.calculate2dpoint();q++;
            Point3d p6=vertices_collision.get(q);p6.calculate2dpoint();q++;
            Point3d p7=vertices_collision.get(q);p7.calculate2dpoint();q++;
            Point3d p8=vertices_collision.get(q);p8.calculate2dpoint();
            
            
            if(p.zr2>0){
            g.setColor(new Color(0,0,255));
            
            g.fillRect(p.x2d,p.y2d,5,5);
            g.fillRect(p2.x2d,p2.y2d,5,5);
            g.fillRect(p3.x2d,p3.y2d,5,5);
            g.fillRect(p4.x2d,p4.y2d,5,5);
            
            g.fillRect(p5.x2d,p5.y2d,5,5);
            g.fillRect(p6.x2d,p6.y2d,5,5);
            g.fillRect(p7.x2d,p7.y2d,5,5);
            g.fillRect(p8.x2d,p8.y2d,5,5);
            
            g.setColor(new Color(0,0,0));
            
            Vect vo=new Vect(0,0,100);
            
            if(check_player_collision_with_walls(p,p2,p3,p5,vo)==true)
            {
                            g.setColor(new Color(250,0,0));
                        
                            Polygon poly=new Polygon();
                            poly.addPoint(p.x2d, p.y2d);
                            poly.addPoint(p2.x2d, p2.y2d);
                            poly.addPoint(p4.x2d, p4.y2d);
                            poly.addPoint(p3.x2d, p3.y2d);
                            g.fillPolygon(poly);
                            
                            Polygon poly2=new Polygon();
                            poly2.addPoint(p5.x2d, p5.y2d);
                            poly2.addPoint(p6.x2d, p6.y2d);
                            poly2.addPoint(p8.x2d, p8.y2d);
                            poly2.addPoint(p7.x2d, p7.y2d);
                            g.fillPolygon(poly2);

                            Polygon poly3=new Polygon();
                            poly3.addPoint(p.x2d, p.y2d);
                            poly3.addPoint(p5.x2d, p5.y2d);
                            poly3.addPoint(p6.x2d, p6.y2d);
                            poly3.addPoint(p2.x2d, p2.y2d);
                            g.fillPolygon(poly3);

                            Polygon poly4=new Polygon();
                            poly4.addPoint(p4.x2d, p4.y2d);
                            poly4.addPoint(p8.x2d, p8.y2d);
                            poly4.addPoint(p7.x2d, p7.y2d);
                            poly4.addPoint(p3.x2d, p3.y2d);
                            g.fillPolygon(poly4);
            }
             
            g.drawLine(p.x2d,p.y2d, p2.x2d,p2.y2d);
            g.drawLine(p3.x2d,p3.y2d, p4.x2d,p4.y2d);
            
            g.drawLine(p5.x2d,p5.y2d, p6.x2d,p6.y2d);
            g.drawLine(p7.x2d,p7.y2d, p8.x2d,p8.y2d);
            
            g.drawLine(p.x2d,p.y2d, p3.x2d,p3.y2d);
            g.drawLine(p5.x2d,p5.y2d, p7.x2d,p7.y2d);
            
            g.drawLine(p.x2d,p.y2d, p5.x2d,p5.y2d);
            g.drawLine(p3.x2d,p3.y2d, p7.x2d,p7.y2d);
            
            g.drawLine(p2.x2d,p2.y2d, p4.x2d,p4.y2d);
            g.drawLine(p6.x2d,p6.y2d, p8.x2d,p8.y2d);
            
            g.drawLine(p2.x2d,p2.y2d, p6.x2d,p6.y2d);
            g.drawLine(p4.x2d,p4.y2d, p8.x2d,p8.y2d);
            
            /*
            g.setColor(new Color(0,255,0));
            g.drawLine(p.x2d,p.y2d, p2.x2d,p2.y2d);
            g.drawLine(p.x2d,p.y2d, p3.x2d,p3.y2d);
            g.drawLine(p.x2d,p.y2d, p5.x2d,p5.y2d);
            */
            }
            }
            
            //show stairs collision
            //draw collision boxes
            //for(Point3d p:vertices_collision)
            int stair_c=0;
            for(int q=0;q<vertices_stairs.size()-7;q++)
            {
            stair_c++;
            Point3d p=vertices_stairs.get(q);p.calculate2dpoint();q++;
            Point3d p2=vertices_stairs.get(q);p2.calculate2dpoint();q++;
            
            Point3d p3=vertices_stairs.get(q);p3.calculate2dpoint();q++;
            Point3d p4=vertices_stairs.get(q);p4.calculate2dpoint();q++;
            Point3d p5=vertices_stairs.get(q);p5.calculate2dpoint();q++;
            Point3d p6=vertices_stairs.get(q);p6.calculate2dpoint();q++;
            Point3d p7=vertices_stairs.get(q);p7.calculate2dpoint();q++;
            Point3d p8=vertices_stairs.get(q);p8.calculate2dpoint();
            
            
            if(p.zr2>0){
               
            g.fillRect(p.x2d,p.y2d,5,5);
            g.fillRect(p2.x2d,p2.y2d,5,5);
            g.fillRect(p3.x2d,p3.y2d,5,5);
            g.fillRect(p4.x2d,p4.y2d,5,5);
            
            g.fillRect(p5.x2d,p5.y2d,5,5);
            g.fillRect(p6.x2d,p6.y2d,5,5);
            g.fillRect(p7.x2d,p7.y2d,5,5);
            g.fillRect(p8.x2d,p8.y2d,5,5);
            
            g.setColor(new Color(0,0,0));
            
            Vect vo=new Vect(0,0,100);
            
            if(check_player_collision_with_walls(p,p2,p3,p5,vo)==true)
            {
                
                
                            /*
                            g.setColor(new Color(250,0,0));
                            
                            Polygon poly=new Polygon();
                            poly.addPoint(p.x2d, p.y2d);
                            poly.addPoint(p2.x2d, p2.y2d);
                            poly.addPoint(p4.x2d, p4.y2d);
                            poly.addPoint(p3.x2d, p3.y2d);
                            g.fillPolygon(poly);
                            
                            Polygon poly2=new Polygon();
                            poly2.addPoint(p5.x2d, p5.y2d);
                            poly2.addPoint(p6.x2d, p6.y2d);
                            poly2.addPoint(p8.x2d, p8.y2d);
                            poly2.addPoint(p7.x2d, p7.y2d);
                            g.fillPolygon(poly2);

                            Polygon poly3=new Polygon();
                            poly3.addPoint(p.x2d, p.y2d);
                            poly3.addPoint(p5.x2d, p5.y2d);
                            poly3.addPoint(p6.x2d, p6.y2d);
                            poly3.addPoint(p2.x2d, p2.y2d);
                            g.fillPolygon(poly3);

                            Polygon poly4=new Polygon();
                            poly4.addPoint(p4.x2d, p4.y2d);
                            poly4.addPoint(p8.x2d, p8.y2d);
                            poly4.addPoint(p7.x2d, p7.y2d);
                            poly4.addPoint(p3.x2d, p3.y2d);
                            g.fillPolygon(poly4);
                            */
                            
                /*
                if(stair_c==1){
                    elevation=0;
                }
            
                if(stair_c==2){
                    elevation=600;
                }
                if(stair_c==3){
                    elevation=1200;
                }
                if(stair_c==4){
                    elevation=1800;
                }
                
                if(stair_c==5){
                    elevation=2400;
                }
            
                if(stair_c==6){
                    elevation=3000;
                }
                if(stair_c==7){
                    elevation=3600;
                }
                if(stair_c==8){
                    elevation=4200;
                }
                */
                    
                
            }
            
            
            g.setColor(new Color(0,0,0));
                
            if(stair_c>=1&&stair_c<=4) g.setColor(new Color(0,255,0));
            
            if(stair_c>=5&&stair_c<=12) g.setColor(new Color(0,0,200));
            
            if(stair_c>=13&&stair_c<=20) g.setColor(new Color(255,0,0));
            
            if(stair_c>=21&&stair_c<=26) g.setColor(new Color(0,200,0));
            
            g.drawLine(p.x2d,p.y2d, p2.x2d,p2.y2d);
            g.drawLine(p3.x2d,p3.y2d, p4.x2d,p4.y2d);
            
            g.drawLine(p5.x2d,p5.y2d, p6.x2d,p6.y2d);
            g.drawLine(p7.x2d,p7.y2d, p8.x2d,p8.y2d);
            
            g.drawLine(p.x2d,p.y2d, p3.x2d,p3.y2d);
            g.drawLine(p5.x2d,p5.y2d, p7.x2d,p7.y2d);
            
            g.drawLine(p.x2d,p.y2d, p5.x2d,p5.y2d);
            g.drawLine(p3.x2d,p3.y2d, p7.x2d,p7.y2d);
            
            g.drawLine(p2.x2d,p2.y2d, p4.x2d,p4.y2d);
            g.drawLine(p6.x2d,p6.y2d, p8.x2d,p8.y2d);
            
            g.drawLine(p2.x2d,p2.y2d, p6.x2d,p6.y2d);
            g.drawLine(p4.x2d,p4.y2d, p8.x2d,p8.y2d);
            
            /*
            g.setColor(new Color(0,255,0));
            g.drawLine(p.x2d,p.y2d, p2.x2d,p2.y2d);
            g.drawLine(p.x2d,p.y2d, p3.x2d,p3.y2d);
            g.drawLine(p.x2d,p.y2d, p5.x2d,p5.y2d);
            */
            }
            }
            //show stairs collision
            
            
            
            
            }
            //draw collision
            
            
            
                
        }
        
            

}catch(Exception exc){};


        //wyswietlanie dla lamborghini
        if(lamborghini==true){
            
                for(int i=0;i<14784;i++)
                
                //guns fpp
                //for(int i=0;i<416;i++)
                //doom
                //for(int i=0;i<4796;i++)
                
                //q2dm1
                //for(int i=0;i<32796;i++)
                {
                    int w1=faces.get(i);
                    
                    
                    i++;
                    int w2=faces.get(i);
                    i++;
                    int w3=faces.get(i);
                    i++;
                    
                    Integer w4=null;
                    
                    
                    if(faces.get(i)!=null)
                    {
                    
                    w4=faces.get(i);
                    
                    }
                    
                    Point3d p1=vertices.get(w1-1);
                    Point3d p2=vertices.get(w2-1);
                    Point3d p3=vertices.get(w3-1);
                    
                    Point3d p4=null;
                    
                    if(w4!=null)
                    {
                       
                    p4=vertices.get(w4-1);
                    }
                    
                    if(p4==null)
                    {
                    triangles.add(new Triangle(p1,p2,p3));
                    }
                    else
                    {
                    triangles.add(new Triangle(p1,p2,p3,p4));
                    }
                   
                }
                
                try{
                Collections.sort(triangles);
                }catch(Exception exc){};
                
                
                for(Triangle t:triangles)
                {
                    Polygon poly=new Polygon();
                    poly.addPoint(t.v1.x2d,t.v1.y2d);
                    poly.addPoint(t.v2.x2d,t.v2.y2d);
                    poly.addPoint(t.v3.x2d,t.v3.y2d);
                    
                    
                    Polygon poly2=new Polygon();
                   
                    
                    if(t.v4!=null)
                    {
                    poly.addPoint(t.v4.x2d,t.v4.y2d);
                         
                    poly2.addPoint(t.v1.x2d,t.v1.y2d);
                    poly2.addPoint(t.v3.x2d,t.v3.y2d);
                    poly2.addPoint(t.v4.x2d,t.v4.y2d);
                    }
                     
                    int color=250;
                    
                    
                    //color=100-(int)(33*t.v1.zr2);
                    if(color>255) color=255;
                    if(color<0) color=0;
                    
                    
                    
                    if(calculate_normals==true){
                        
                        //System.out.println(""+0.1*t.calculateNormal());
                        float n=5*t.calculateNormal();
                        //if(n<=0) n=0;
                        
                        color=255+(int)(n*0.1);
                        
                        if(color>255) color=255;
                        if(color<200) color=200;
                    }
                    
                    g.setColor(new Color(color,color,color));
                    
                    
                    int dd=0;
                    //if(t.v1.zr2>dd&&t.v2.zr2>dd&&t.v3.zr2>dd){
                    if(t.v1.x2d>0&&t.v2.x2d>0&&t.v3.x2d>0&&t.v1.x2d<640&&t.v2.x2d<640&&t.v3.x2d<640)
                    if(t.v1.y2d>0&&t.v2.y2d>0&&t.v3.y2d>0&&t.v1.y2d<480&&t.v2.y2d<480&&t.v3.y2d<480)
                    {
                    {    
                        
                            if(wire_frame==false)
                            {
                            g.fillPolygon(poly);

                            //g.fillPolygon(poly2);
                            //g.fillPolygon(poly3);
                            //g.fillPolygon(poly4);
                            }
                    
                    
                            g.setColor(new Color(0,0,0));
                            g.drawLine(t.v1.x2d,t.v1.y2d, t.v2.x2d,t.v2.y2d);
                            g.drawLine(t.v2.x2d,t.v2.y2d, t.v3.x2d,t.v3.y2d);

                            if(t.v4==null)
                            {
                            g.drawLine(t.v3.x2d,t.v3.y2d, t.v1.x2d,t.v1.y2d);
                            }

                            if(t.v4!=null)
                            {
                            g.drawLine(t.v3.x2d,t.v3.y2d, t.v4.x2d,t.v4.y2d);
                            g.drawLine(t.v4.x2d,t.v4.y2d, t.v1.x2d,t.v1.y2d);
                            }
                            
                            
                    }
                    }
                   //}
                    
                     
                }
        }
        
        
         if(tomb_raider==true){
                for(int i=0;i<21414;i++)
                {
                    int w1=faces.get(i);
                    i++;
                    int w2=faces.get(i);
                    i++;
                    int w3=faces.get(i);
                    //i++;
                    //int w4=faces.get(i);

                    Point3d p1=vertices.get(w1-1);
                    Point3d p2=vertices.get(w2-1);
                    Point3d p3=vertices.get(w3-1);
                    //Point3d p4=vertices.get(w4-1);

                    triangles.add(new Triangle(p1,p2,p3));
                     
                    Polygon poly=new Polygon();
                    poly.addPoint(p1.x2d,p1.y2d);
                    poly.addPoint(p2.x2d,p2.y2d);
                    poly.addPoint(p3.x2d,p3.y2d);
                }
                
                try{
                Collections.sort(triangles);
                }catch(Exception exc){};
                
                for(Triangle t:triangles)
                {
                    
                    
                    
                    
                    
                    Polygon poly=new Polygon();
                    poly.addPoint(t.v1.x2d,t.v1.y2d);
                    poly.addPoint(t.v2.x2d,t.v2.y2d);
                    poly.addPoint(t.v3.x2d,t.v3.y2d);
                    //int color=255-(int)(0.01f*t.v1.zr2);
                    int color=250;
                    
                     if(calculate_normals==true){
                        
                        //System.out.println(""+0.1*t.calculateNormal());
                        float n=t.calculateNormal();
                        //if(n<=0) n=0;
                        
                        color=250+(int)(n);
                        
                        if(color>255) color=255;
                        if(color<0) color=0;
                    }
                     
                    g.setColor(new Color(color,color,color));
                   
                    if(wire_frame==false)
                    {
                    g.fillPolygon(poly);
                    }
                    
                    g.setColor(new Color(0,0,0));
                    g.drawLine(t.v1.x2d,t.v1.y2d, t.v2.x2d,t.v2.y2d);
                    g.drawLine(t.v2.x2d,t.v2.y2d, t.v3.x2d,t.v3.y2d);
                    g.drawLine(t.v3.x2d,t.v3.y2d, t.v1.x2d,t.v1.y2d);
                }
        }
         
        
         
         if(crash_bandicoot==true){
             int q=0;
                for(int i=0;i<2196;i++)
                {
                   
                    q++;
                    
                    int w1=faces.get(i);
                    i++;
                    int w2=faces.get(i);
                    i++;
                    int w3=faces.get(i);
                    //i++;
                    //int w4=faces.get(i);

                    Point3d p1=vertices.get(w1-1);
                    Point3d p2=vertices.get(w2-1);
                    Point3d p3=vertices.get(w3-1);
                    //Point3d p4=vertices.get(w4-1);
                    triangles.add(new Triangle(p1,p2,p3));
                    
                    
                }
                
                try{
                Collections.sort(triangles);
                }catch(Exception exc){};
                
                for(Triangle t:triangles)
                {
                    t.v1.calculate2dpoint();
                    t.v2.calculate2dpoint();
                    t.v3.calculate2dpoint();
                    
                    
                    Polygon poly=new Polygon();
                    poly.addPoint(t.v1.x2d,t.v1.y2d);
                    poly.addPoint(t.v2.x2d,t.v2.y2d);
                    poly.addPoint(t.v3.x2d,t.v3.y2d);
                    int color=255-(int)(0.01f*t.v1.zr2);
                    color=250;
                    if(color>=255) color=255;
                    if(color<=0) color=0;
                    
                     if(calculate_normals==true){
                        
                        //System.out.println(""+0.1*t.calculateNormal());
                        float n=5*t.calculateNormal();
                        //if(n<=0) n=0;
                        
                        color=250+(int)(n*0.1);
                        
                        if(color>255) color=255;
                        if(color<0) color=0;
                    }
                     
                    g.setColor(new Color(color,color,color));

                    if(wire_frame==false)
                    {
                    g.fillPolygon(poly);
                    }

                    g.setColor(new Color(0,0,0));
                    g.drawLine(t.v1.x2d,t.v1.y2d, t.v2.x2d,t.v2.y2d);
                    g.drawLine(t.v2.x2d,t.v2.y2d, t.v3.x2d,t.v3.y2d);
                    g.drawLine(t.v3.x2d,t.v3.y2d, t.v1.x2d,t.v1.y2d);
                }
        }
         
        //teapot
        if(tea_pot==true){
                for(int i=0;i<30000;i++)
                {
                    int w1=faces.get(i);
                    
                    
                    i++;
                    int w2=faces.get(i);
                    i++;
                    int w3=faces.get(i);
                    i++;
                    
                    Integer w4=null;
                    
                    
                    if(faces.get(i)!=null)
                    {
                    
                    w4=faces.get(i);
                    
                    }
                    
                    Point3d p1=vertices.get(w1-1);
                    Point3d p2=vertices.get(w2-1);
                    Point3d p3=vertices.get(w3-1);
                    
                    Point3d p4=null;
                    
                    if(w4!=null)
                    {
                       
                    p4=vertices.get(w4-1);
                    }
                    
                    if(p4==null)
                    {
                    triangles.add(new Triangle(p1,p2,p3));
                    }
                    else
                    {
                    triangles.add(new Triangle(p1,p2,p3,p4));
                    }
                   
                }
                
                try{
                Collections.sort(triangles);
                }catch(Exception exc){};
                
                
                for(Triangle t:triangles)
                {
                    Polygon poly=new Polygon();
                    poly.addPoint(t.v1.x2d,t.v1.y2d);
                    poly.addPoint(t.v2.x2d,t.v2.y2d);
                    poly.addPoint(t.v3.x2d,t.v3.y2d);
                    
                    
                    Polygon poly2=new Polygon();
                   
                    
                    if(t.v4!=null)
                    {
                    poly.addPoint(t.v4.x2d,t.v4.y2d);
                         
                    poly2.addPoint(t.v1.x2d,t.v1.y2d);
                    poly2.addPoint(t.v3.x2d,t.v3.y2d);
                    poly2.addPoint(t.v4.x2d,t.v4.y2d);
                    }
                     
                    int color=250;
                    
                    
                    //color=100-(int)(33*t.v1.zr2);
                    if(color>255) color=255;
                    if(color<0) color=0;
                    
                     if(calculate_normals==true){
                        
                        //System.out.println(""+0.1*t.calculateNormal());
                        float n=5*t.calculateNormal();
                        //if(n<=0) n=0;
                        
                        color=200-(int)(n*0.1);
                        
                        if(color>255) color=255;
                        if(color<0) color=0;
                    }
                     
                    g.setColor(new Color(color,color,color));
                    
                    if(wire_frame==false)
                    {
                    g.fillPolygon(poly);
                    
                    //g.fillPolygon(poly2);
                    //g.fillPolygon(poly3);
                    //g.fillPolygon(poly4);
                    }
                    
                    g.setColor(new Color(0,0,0));
                    g.drawLine(t.v1.x2d,t.v1.y2d, t.v2.x2d,t.v2.y2d);
                    g.drawLine(t.v2.x2d,t.v2.y2d, t.v3.x2d,t.v3.y2d);
                    
                    if(t.v4==null)
                    {
                    g.drawLine(t.v3.x2d,t.v3.y2d, t.v1.x2d,t.v1.y2d);
                    }
                    
                    if(t.v4!=null)
                    {
                    g.drawLine(t.v3.x2d,t.v3.y2d, t.v4.x2d,t.v4.y2d);
                    g.drawLine(t.v4.x2d,t.v4.y2d, t.v1.x2d,t.v1.y2d);
                    }
                     
                }
        }
         
        g.setColor(Color.black);
        g.setFont(new Font("System", Font.BOLD, 10));
        g.drawString("Mateusz Pawlowski. 3D Software Renderer. 2023.", 190, 450);
        
        g.drawString("x="+R_3D.player_x, 10, 460);
        g.drawString("z="+R_3D.player_z, 10, 470);
        
    }

    public void line(int x,int y,int x2,int y2)
    {
    g.drawLine(x+60, y-20,x2+60,y2-20);
    }
    
    public Dimension getPreferredSize(){
        return new Dimension(640, 480);
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        R_3D rds=new R_3D();
        
        
        rds.panel=rds;
        
        rds.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       
       
        
        rds.thread=new Thread(rds);
        rds.thread.start();
        
        rds.frame.getContentPane().add(rds.panel);
        rds.frame.setLocation(500, 300);
        
        rds.frame.pack();
        rds.frame.show();
        
        if(lock_head==false){
        rds.rotateDown();
        rds.rotateDown();
        rds.rotateDown();
        }
        //rds.play();
        
            if(game_mode==true){
                rds.start_in_game_mode();
            }
    }

    @Override
    public void mouseClicked(MouseEvent me) {
        
    }

   

    @Override
    public void mouseEntered(MouseEvent me) {
        
    }

    @Override
    public void mouseExited(MouseEvent me) {
        
    }

    @Override
    public void mouseWheelMoved(MouseWheelEvent mwe) {
       double whell_rotation=mwe.getPreciseWheelRotation();
       if(whell_rotation>0)
       {
           //camera=camera+10;
           up();
           //triangle_pointer++;
       }
       
       if(whell_rotation<0)
       {
           //camera=camera-10;
           down();
           //triangle_pointer--;
       }
    }
}
