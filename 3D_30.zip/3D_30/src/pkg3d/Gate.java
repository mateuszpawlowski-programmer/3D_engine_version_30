/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg3d;


import java.awt.Color;
import java.util.ArrayList;
/**
 *
 * @author M
 */

public class Gate {

//character position in world space player_x+enemy.x,player_y+enemy.y,player_z+enemy.z
//Point3d ec=new Point3d(player_x+enemy.x,player_y+enemy.y,player_z+enemy.z);
public float x=0f;
public float y=0f;
public float z=0f;

public float world_x=0f;
public float world_y=0f;
public float world_z=0f;

double character_angleY=0;
double character_angleX=0;

double angle_X=0;
double angle_Y=0;

boolean alive=true;

public Color gate_color=null;

int counter=0;
boolean is_opening=false;
boolean open=false;

int dist=20;


ArrayList<Triangle> t_list=null;

ArrayList<Triangle> t_list_s=null;
ArrayList<Triangle> t_list_d=null;

ArrayList<Point3d> vertices_collision=null;

public boolean collision(Point3d p)
{

    this.world_x=R_3D.player_x+this.x;
    this.world_y=R_3D.player_y+this.y;
    this.world_z=R_3D.player_z+this.z;
    
    //Point3d tp=t_list.get(0).v1;
    //tp=new Point3d(world_x,world_y,world_z);
    
    Point3d tp=new Point3d(world_x,world_y,world_z);
    tp.rotateAxisY(R_3D.cube_angleY);
    tp.rotateAxisX(R_3D.cube_angleX);
    tp.calculate2dpoint();
    
    //tp.calculate2dpoint_character();
    //if((p.xr2-tp.xro3)*(p.xr2-tp.xro3)+(p.yr2-tp.yro3)*(p.yr2-tp.yro3)+(p.zr2-tp.zro3)*(p.zr2-tp.zro3)<(1000*1000)){return true;}
    
if((p.xr2-tp.xr2)*(p.xr2-tp.xr2)+(p.yr2-tp.yr2)*(p.yr2-tp.yr2)+(p.zr2-tp.zr2)*(p.zr2-tp.zr2)<(500*500)){return true;}
return false;
}

Gate()
{
this.world_x=R_3D.player_x+this.x;
this.world_y=R_3D.player_y+this.y;
this.world_z=R_3D.player_z+this.z;
    
t_list=new ArrayList<Triangle>();
t_list_s=new ArrayList<Triangle>();
t_list_d=new ArrayList<Triangle>();

vertices_collision=new ArrayList<Point3d>();

for(int q=0;q<R_3D.vertices_gate.size();q++)
{
    Point3d e=R_3D.vertices_gate.get(q);
    Point3d p_col=new Point3d(e.x,e.y,e.z);
    vertices_collision.add(p_col);
}

//for(Triangle t:R_3D.triangles_enemy)
//character default posture standing
for(int q=0;q<R_3D.triangles_gate.size();q++)
{
    Triangle t=R_3D.triangles_gate.get(q);
    
    float x=t.v1.xr2;
    float y=t.v1.yr2;
    float z=t.v1.zr2;
    Point3d te1=new Point3d(x,y,z);
    
    float x2=t.v2.xr2;
    float y2=t.v2.yr2;
    float z2=t.v2.zr2;
    Point3d te2=new Point3d(x2,y2,z2);
    
    float x3=t.v3.xr2;
    float y3=t.v3.yr2;
    float z3=t.v3.zr2;
    Point3d te3=new Point3d(x3,y3,z3);
    
    //Point3d te1=new Point3d(0,0,5000);
    //Point3d te2=new Point3d(0,0,0);
    //Point3d te3=new Point3d(5000,0,0);
    if(t.v4==null){
    Triangle nt=new Triangle(te1,te2,te3);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_s.add(nt);
    }
    
    if(t.v4!=null){
    
    float x4=t.v4.xr2;
    float y4=t.v4.yr2;
    float z4=t.v4.zr2;
    Point3d te4=new Point3d(x4,y4,z4);    
        
    Triangle nt=new Triangle(te1,te2,te3,te4);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_s.add(nt);
    }
    
}

t_list=t_list_s;

//move_center(-2750,0,0);
//move_center(0,1000,0);
}

public void set_gate_open()
{
    is_opening=true;
}

public void set_character_location(float a,float b,float c)
{
x=a;
y=b;
z=c;
}

public void update_gate_animation()
{
    if(is_opening==true){
    counter++;
                        if(counter<300){
                            move_character(0,-10,0);
                        }
                        if(counter>=300){open=true;is_opening=false;}
    }
}

public void move_character(float a,float b,float c)
{
x=x+a;
y=y+b;
z=z+c;
}

public void move_center(float a,float b,float c)
{

for(int q=0;q<t_list.size();q++)
    {
    Triangle t=t_list.get(q);
   
    t.v1.xo=t.v1.xo+a;
    t.v1.yo=t.v1.yo+b;
    t.v1.zo=t.v1.zo+c;
    
    t.v2.xo=t.v2.xo+a;
    t.v2.yo=t.v2.yo+b;
    t.v2.zo=t.v2.zo+c;
    
    t.v3.xo=t.v3.xo+a;
    t.v3.yo=t.v3.yo+b;
    t.v3.zo=t.v3.zo+c;
    
    if(t.v4!=null){
        t.v4.xo=t.v4.xo+a;
        t.v4.yo=t.v4.yo+b;
        t.v4.zo=t.v4.zo+c;
    }
    
    }

}




}
