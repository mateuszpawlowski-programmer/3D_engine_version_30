/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg3d;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author M
 */
public class Character {

//character position in world space player_x+enemy.x,player_y+enemy.y,player_z+enemy.z
//Point3d ec=new Point3d(player_x+enemy.x,player_y+enemy.y,player_z+enemy.z);
public float x=0f;
public float y=0f;
public float z=0f;

public float world_x=0f;
public float world_y=0f;
public float world_z=0f;

double character_angleY=0;
double character_angleX=0;

double angle_X=0;
double angle_Y=0;

boolean alive=true;

int counter=0;
int ai_set=0;

int dist=20;


ArrayList<Triangle> t_list=null;

ArrayList<Triangle> t_list_s=null;
ArrayList<Triangle> t_list_d=null;

ArrayList<Triangle> t_list_shot=null;
ArrayList<Triangle> t_list_reload=null;

ArrayList<Triangle> t_list_roll_1=null;
ArrayList<Triangle> t_list_roll_2=null;
ArrayList<Triangle> t_list_roll_3=null;
ArrayList<Triangle> t_list_roll_4=null;
ArrayList<Triangle> t_list_roll_5=null;

//ArrayList<Triangle> t_list_o_shot_1=null;

ArrayList<Triangle> t_list_o_shot_2_l=null;
ArrayList<Triangle> t_list_o_shot_3_l=null;
ArrayList<Triangle> t_list_o_shot_4_l=null;
ArrayList<Triangle> t_list_o_shot_5_l=null;
ArrayList<Triangle> t_list_o_shot_6_l=null;

ArrayList<Triangle> t_list_o_shot_2_r=null;
ArrayList<Triangle> t_list_o_shot_3_r=null;
ArrayList<Triangle> t_list_o_shot_4_r=null;
ArrayList<Triangle> t_list_o_shot_5_r=null;
ArrayList<Triangle> t_list_o_shot_6_r=null;

public boolean collision(Point3d p)
{

    this.world_x=R_3D.player_x+this.x;
    this.world_y=R_3D.player_y+this.y;
    this.world_z=R_3D.player_z+this.z;
    
    //Point3d tp=t_list.get(0).v1;
    //tp=new Point3d(world_x,world_y,world_z);
    
    Point3d tp=new Point3d(world_x,world_y,world_z);
    tp.rotateAxisY(R_3D.cube_angleY);
    tp.rotateAxisX(R_3D.cube_angleX);
    tp.calculate2dpoint();
    
    //tp.calculate2dpoint_character();
    //if((p.xr2-tp.xro3)*(p.xr2-tp.xro3)+(p.yr2-tp.yro3)*(p.yr2-tp.yro3)+(p.zr2-tp.zro3)*(p.zr2-tp.zro3)<(1000*1000)){return true;}
    
if((p.xr2-tp.xr2)*(p.xr2-tp.xr2)+(p.yr2-tp.yr2)*(p.yr2-tp.yr2)+(p.zr2-tp.zr2)*(p.zr2-tp.zr2)<(500*500))
{
    //R_3D.gates.get(0).is_opening=true;
    
    return true;
}
return false;
}

Character()
{
this.world_x=R_3D.player_x+this.x;
this.world_y=R_3D.player_y+this.y;
this.world_z=R_3D.player_z+this.z;
    
t_list=new ArrayList<Triangle>();
t_list_s=new ArrayList<Triangle>();
t_list_d=new ArrayList<Triangle>();

t_list_shot=new ArrayList<Triangle>();
t_list_reload=new ArrayList<Triangle>();

t_list_roll_1=new ArrayList<Triangle>();
t_list_roll_2=new ArrayList<Triangle>();
t_list_roll_3=new ArrayList<Triangle>();
t_list_roll_4=new ArrayList<Triangle>();
t_list_roll_5=new ArrayList<Triangle>();

t_list_o_shot_2_l=new ArrayList<Triangle>();
t_list_o_shot_3_l=new ArrayList<Triangle>();
t_list_o_shot_4_l=new ArrayList<Triangle>();
t_list_o_shot_5_l=new ArrayList<Triangle>();
t_list_o_shot_6_l=new ArrayList<Triangle>();

t_list_o_shot_2_r=new ArrayList<Triangle>();
t_list_o_shot_3_r=new ArrayList<Triangle>();
t_list_o_shot_4_r=new ArrayList<Triangle>();
t_list_o_shot_5_r=new ArrayList<Triangle>();
t_list_o_shot_6_r=new ArrayList<Triangle>();

//for(Triangle t:R_3D.triangles_enemy)
//character default posture standing
for(int q=0;q<R_3D.triangles_enemy_standing.size();q++)
{
    Triangle t=R_3D.triangles_enemy_standing.get(q);
    
    float x=t.v1.xr2;
    float y=t.v1.yr2;
    float z=t.v1.zr2;
    Point3d te1=new Point3d(x,y,z);
    
    float x2=t.v2.xr2;
    float y2=t.v2.yr2;
    float z2=t.v2.zr2;
    Point3d te2=new Point3d(x2,y2,z2);
    
    float x3=t.v3.xr2;
    float y3=t.v3.yr2;
    float z3=t.v3.zr2;
    Point3d te3=new Point3d(x3,y3,z3);
    
    //Point3d te1=new Point3d(0,0,5000);
    //Point3d te2=new Point3d(0,0,0);
    //Point3d te3=new Point3d(5000,0,0);
    if(t.v4==null){
    Triangle nt=new Triangle(te1,te2,te3);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_s.add(nt);
    }
    
    if(t.v4!=null){
    
    float x4=t.v4.xr2;
    float y4=t.v4.yr2;
    float z4=t.v4.zr2;
    Point3d te4=new Point3d(x4,y4,z4);    
        
    Triangle nt=new Triangle(te1,te2,te3,te4);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_s.add(nt);
    }
    
}

//character crouching
for(int q=0;q<R_3D.triangles_enemy_crouching.size();q++)
{
    Triangle t=R_3D.triangles_enemy_crouching.get(q);
    
    int h=1100;
    
    float x=t.v1.xr2;
    float y=t.v1.yr2+h;
    float z=t.v1.zr2;
    Point3d te1=new Point3d(x,y,z);
    
    float x2=t.v2.xr2;
    float y2=t.v2.yr2+h;
    float z2=t.v2.zr2;
    Point3d te2=new Point3d(x2,y2,z2);
    
    float x3=t.v3.xr2;
    float y3=t.v3.yr2+h;
    float z3=t.v3.zr2;
    Point3d te3=new Point3d(x3,y3,z3);
    
    //Point3d te1=new Point3d(0,0,5000);
    //Point3d te2=new Point3d(0,0,0);
    //Point3d te3=new Point3d(5000,0,0);
    if(t.v4==null){
    Triangle nt=new Triangle(te1,te2,te3);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_d.add(nt);
    }
    
    if(t.v4!=null){
    
    float x4=t.v4.xr2;
    float y4=t.v4.yr2+h;
    float z4=t.v4.zr2;
    Point3d te4=new Point3d(x4,y4,z4);    
        
    Triangle nt=new Triangle(te1,te2,te3,te4);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_d.add(nt);
    }
    
    t_list=t_list_s;
}

//character shooting standing
for(int q=0;q<R_3D.triangles_enemy_standing_shot.size();q++)
{
    Triangle t=R_3D.triangles_enemy_standing_shot.get(q);
    
    int h=1100;
    
    float x=t.v1.xr2;
    float y=t.v1.yr2+h;
    float z=t.v1.zr2;
    Point3d te1=new Point3d(x,y,z);
    
    float x2=t.v2.xr2;
    float y2=t.v2.yr2+h;
    float z2=t.v2.zr2;
    Point3d te2=new Point3d(x2,y2,z2);
    
    float x3=t.v3.xr2;
    float y3=t.v3.yr2+h;
    float z3=t.v3.zr2;
    Point3d te3=new Point3d(x3,y3,z3);
    
    //Point3d te1=new Point3d(0,0,5000);
    //Point3d te2=new Point3d(0,0,0);
    //Point3d te3=new Point3d(5000,0,0);
    if(t.v4==null){
    Triangle nt=new Triangle(te1,te2,te3);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_shot.add(nt);
    }
    
    if(t.v4!=null){
    
    float x4=t.v4.xr2;
    float y4=t.v4.yr2+h;
    float z4=t.v4.zr2;
    Point3d te4=new Point3d(x4,y4,z4);    
        
    Triangle nt=new Triangle(te1,te2,te3,te4);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_shot.add(nt);
    }
}
//character shooting standing

//character standing reload
for(int q=0;q<R_3D.triangles_enemy_standing_reload.size();q++)
{
    Triangle t=R_3D.triangles_enemy_standing_reload.get(q);
    
    int h=1100;
    
    float x=t.v1.xr2;
    float y=t.v1.yr2+h;
    float z=t.v1.zr2;
    Point3d te1=new Point3d(x,y,z);
    
    float x2=t.v2.xr2;
    float y2=t.v2.yr2+h;
    float z2=t.v2.zr2;
    Point3d te2=new Point3d(x2,y2,z2);
    
    float x3=t.v3.xr2;
    float y3=t.v3.yr2+h;
    float z3=t.v3.zr2;
    Point3d te3=new Point3d(x3,y3,z3);
    
    //Point3d te1=new Point3d(0,0,5000);
    //Point3d te2=new Point3d(0,0,0);
    //Point3d te3=new Point3d(5000,0,0);
    if(t.v4==null){
    Triangle nt=new Triangle(te1,te2,te3);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_reload.add(nt);
    }
    
    if(t.v4!=null){
    
    float x4=t.v4.xr2;
    float y4=t.v4.yr2+h;
    float z4=t.v4.zr2;
    Point3d te4=new Point3d(x4,y4,z4);    
        
    Triangle nt=new Triangle(te1,te2,te3,te4);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_reload.add(nt);
    }
}
//character standing reload

//character rolling 1
for(int q=0;q<R_3D.triangles_enemy_rolling_1.size();q++)
{
    Triangle t=R_3D.triangles_enemy_rolling_1.get(q);
    
    int h=1100;
    
    float x=t.v1.xr2;
    float y=t.v1.yr2+h;
    float z=t.v1.zr2;
    Point3d te1=new Point3d(x,y,z);
    
    float x2=t.v2.xr2;
    float y2=t.v2.yr2+h;
    float z2=t.v2.zr2;
    Point3d te2=new Point3d(x2,y2,z2);
    
    float x3=t.v3.xr2;
    float y3=t.v3.yr2+h;
    float z3=t.v3.zr2;
    Point3d te3=new Point3d(x3,y3,z3);
    
    //Point3d te1=new Point3d(0,0,5000);
    //Point3d te2=new Point3d(0,0,0);
    //Point3d te3=new Point3d(5000,0,0);
    if(t.v4==null){
    Triangle nt=new Triangle(te1,te2,te3);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_roll_1.add(nt);
    }
    
    if(t.v4!=null){
    
    float x4=t.v4.xr2;
    float y4=t.v4.yr2+h;
    float z4=t.v4.zr2;
    Point3d te4=new Point3d(x4,y4,z4);    
        
    Triangle nt=new Triangle(te1,te2,te3,te4);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_roll_1.add(nt);
    }
}
//character rolling 1

//character rolling 2
for(int q=0;q<R_3D.triangles_enemy_rolling_2.size();q++)
{
    Triangle t=R_3D.triangles_enemy_rolling_2.get(q);
    
    int h=1100;
    
    float x=t.v1.xr2;
    float y=t.v1.yr2+h;
    float z=t.v1.zr2;
    Point3d te1=new Point3d(x,y,z);
    
    float x2=t.v2.xr2;
    float y2=t.v2.yr2+h;
    float z2=t.v2.zr2;
    Point3d te2=new Point3d(x2,y2,z2);
    
    float x3=t.v3.xr2;
    float y3=t.v3.yr2+h;
    float z3=t.v3.zr2;
    Point3d te3=new Point3d(x3,y3,z3);
    
    //Point3d te1=new Point3d(0,0,5000);
    //Point3d te2=new Point3d(0,0,0);
    //Point3d te3=new Point3d(5000,0,0);
    if(t.v4==null){
    Triangle nt=new Triangle(te1,te2,te3);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_roll_2.add(nt);
    }
    
    if(t.v4!=null){
    
    float x4=t.v4.xr2;
    float y4=t.v4.yr2+h;
    float z4=t.v4.zr2;
    Point3d te4=new Point3d(x4,y4,z4);    
        
    Triangle nt=new Triangle(te1,te2,te3,te4);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_roll_2.add(nt);
    }
}
//character rolling 2

//character rolling 3
for(int q=0;q<R_3D.triangles_enemy_rolling_3.size();q++)
{
    Triangle t=R_3D.triangles_enemy_rolling_3.get(q);
    
    int h=1100;
    
    float x=t.v1.xr2;
    float y=t.v1.yr2+h;
    float z=t.v1.zr2;
    Point3d te1=new Point3d(x,y,z);
    
    float x2=t.v2.xr2;
    float y2=t.v2.yr2+h;
    float z2=t.v2.zr2;
    Point3d te2=new Point3d(x2,y2,z2);
    
    float x3=t.v3.xr2;
    float y3=t.v3.yr2+h;
    float z3=t.v3.zr2;
    Point3d te3=new Point3d(x3,y3,z3);
    
    //Point3d te1=new Point3d(0,0,5000);
    //Point3d te2=new Point3d(0,0,0);
    //Point3d te3=new Point3d(5000,0,0);
    if(t.v4==null){
    Triangle nt=new Triangle(te1,te2,te3);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_roll_3.add(nt);
    }
    
    if(t.v4!=null){
    
    float x4=t.v4.xr2;
    float y4=t.v4.yr2+h;
    float z4=t.v4.zr2;
    Point3d te4=new Point3d(x4,y4,z4);    
        
    Triangle nt=new Triangle(te1,te2,te3,te4);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_roll_3.add(nt);
    }
}
//character rolling 3

//character rolling 4
for(int q=0;q<R_3D.triangles_enemy_rolling_4.size();q++)
{
    Triangle t=R_3D.triangles_enemy_rolling_4.get(q);
    
    int h=1100;
    
    float x=t.v1.xr2;
    float y=t.v1.yr2+h;
    float z=t.v1.zr2;
    Point3d te1=new Point3d(x,y,z);
    
    float x2=t.v2.xr2;
    float y2=t.v2.yr2+h;
    float z2=t.v2.zr2;
    Point3d te2=new Point3d(x2,y2,z2);
    
    float x3=t.v3.xr2;
    float y3=t.v3.yr2+h;
    float z3=t.v3.zr2;
    Point3d te3=new Point3d(x3,y3,z3);
    
    //Point3d te1=new Point3d(0,0,5000);
    //Point3d te2=new Point3d(0,0,0);
    //Point3d te3=new Point3d(5000,0,0);
    if(t.v4==null){
    Triangle nt=new Triangle(te1,te2,te3);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_roll_4.add(nt);
    }
    
    if(t.v4!=null){
    
    float x4=t.v4.xr2;
    float y4=t.v4.yr2+h;
    float z4=t.v4.zr2;
    Point3d te4=new Point3d(x4,y4,z4);    
        
    Triangle nt=new Triangle(te1,te2,te3,te4);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_roll_4.add(nt);
    }
}
//character rolling 4

//character rolling 5
for(int q=0;q<R_3D.triangles_enemy_rolling_5.size();q++)
{
    Triangle t=R_3D.triangles_enemy_rolling_5.get(q);
    
    int h=1100;
    
    float x=t.v1.xr2;
    float y=t.v1.yr2+h;
    float z=t.v1.zr2;
    Point3d te1=new Point3d(x,y,z);
    
    float x2=t.v2.xr2;
    float y2=t.v2.yr2+h;
    float z2=t.v2.zr2;
    Point3d te2=new Point3d(x2,y2,z2);
    
    float x3=t.v3.xr2;
    float y3=t.v3.yr2+h;
    float z3=t.v3.zr2;
    Point3d te3=new Point3d(x3,y3,z3);
    
    //Point3d te1=new Point3d(0,0,5000);
    //Point3d te2=new Point3d(0,0,0);
    //Point3d te3=new Point3d(5000,0,0);
    if(t.v4==null){
    Triangle nt=new Triangle(te1,te2,te3);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_roll_5.add(nt);
    }
    
    if(t.v4!=null){
    
    float x4=t.v4.xr2;
    float y4=t.v4.yr2+h;
    float z4=t.v4.zr2;
    Point3d te4=new Point3d(x4,y4,z4);    
        
    Triangle nt=new Triangle(te1,te2,te3,te4);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_roll_5.add(nt);
    }
}
//character rolling 5

//******************************************************

//character obstacle shot 2 left
for(int q=0;q<R_3D.triangles_enemy_standing_obstacle_shot_2_l.size();q++)
{
    Triangle t=R_3D.triangles_enemy_standing_obstacle_shot_2_l.get(q);
    
    int h=1100;
    
    float x=t.v1.xr2;
    float y=t.v1.yr2+h;
    float z=t.v1.zr2;
    Point3d te1=new Point3d(x,y,z);
    
    float x2=t.v2.xr2;
    float y2=t.v2.yr2+h;
    float z2=t.v2.zr2;
    Point3d te2=new Point3d(x2,y2,z2);
    
    float x3=t.v3.xr2;
    float y3=t.v3.yr2+h;
    float z3=t.v3.zr2;
    Point3d te3=new Point3d(x3,y3,z3);
    
    //Point3d te1=new Point3d(0,0,5000);
    //Point3d te2=new Point3d(0,0,0);
    //Point3d te3=new Point3d(5000,0,0);
    if(t.v4==null){
    Triangle nt=new Triangle(te1,te2,te3);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_o_shot_2_l.add(nt);
    }
    
    if(t.v4!=null){
    
    float x4=t.v4.xr2;
    float y4=t.v4.yr2+h;
    float z4=t.v4.zr2;
    Point3d te4=new Point3d(x4,y4,z4);    
        
    Triangle nt=new Triangle(te1,te2,te3,te4);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_o_shot_2_l.add(nt);
    }
}
//character obstacle shot 2 left

//character obstacle shot 3 left
for(int q=0;q<R_3D.triangles_enemy_standing_obstacle_shot_3_l.size();q++)
{
    Triangle t=R_3D.triangles_enemy_standing_obstacle_shot_3_l.get(q);
    
    int h=1100;
    
    float x=t.v1.xr2;
    float y=t.v1.yr2+h;
    float z=t.v1.zr2;
    Point3d te1=new Point3d(x,y,z);
    
    float x2=t.v2.xr2;
    float y2=t.v2.yr2+h;
    float z2=t.v2.zr2;
    Point3d te2=new Point3d(x2,y2,z2);
    
    float x3=t.v3.xr2;
    float y3=t.v3.yr2+h;
    float z3=t.v3.zr2;
    Point3d te3=new Point3d(x3,y3,z3);
    
    //Point3d te1=new Point3d(0,0,5000);
    //Point3d te2=new Point3d(0,0,0);
    //Point3d te3=new Point3d(5000,0,0);
    if(t.v4==null){
    Triangle nt=new Triangle(te1,te2,te3);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_o_shot_3_l.add(nt);
    }
    
    if(t.v4!=null){
    
    float x4=t.v4.xr2;
    float y4=t.v4.yr2+h;
    float z4=t.v4.zr2;
    Point3d te4=new Point3d(x4,y4,z4);    
        
    Triangle nt=new Triangle(te1,te2,te3,te4);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_o_shot_3_l.add(nt);
    }
}
//character obstacle shot 3 left

//character obstacle shot 4 left
for(int q=0;q<R_3D.triangles_enemy_standing_obstacle_shot_4_l.size();q++)
{
    Triangle t=R_3D.triangles_enemy_standing_obstacle_shot_4_l.get(q);
    
    int h=1100;
    
    float x=t.v1.xr2;
    float y=t.v1.yr2+h;
    float z=t.v1.zr2;
    Point3d te1=new Point3d(x,y,z);
    
    float x2=t.v2.xr2;
    float y2=t.v2.yr2+h;
    float z2=t.v2.zr2;
    Point3d te2=new Point3d(x2,y2,z2);
    
    float x3=t.v3.xr2;
    float y3=t.v3.yr2+h;
    float z3=t.v3.zr2;
    Point3d te3=new Point3d(x3,y3,z3);
    
    //Point3d te1=new Point3d(0,0,5000);
    //Point3d te2=new Point3d(0,0,0);
    //Point3d te3=new Point3d(5000,0,0);
    if(t.v4==null){
    Triangle nt=new Triangle(te1,te2,te3);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_o_shot_4_l.add(nt);
    }
    
    if(t.v4!=null){
    
    float x4=t.v4.xr2;
    float y4=t.v4.yr2+h;
    float z4=t.v4.zr2;
    Point3d te4=new Point3d(x4,y4,z4);    
        
    Triangle nt=new Triangle(te1,te2,te3,te4);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_o_shot_4_l.add(nt);
    }
}
//character obstacle shot 4 left

//character obstacle shot 5 left
for(int q=0;q<R_3D.triangles_enemy_standing_obstacle_shot_5_l.size();q++)
{
    Triangle t=R_3D.triangles_enemy_standing_obstacle_shot_5_l.get(q);
    
    int h=1100;
    
    float x=t.v1.xr2;
    float y=t.v1.yr2+h;
    float z=t.v1.zr2;
    Point3d te1=new Point3d(x,y,z);
    
    float x2=t.v2.xr2;
    float y2=t.v2.yr2+h;
    float z2=t.v2.zr2;
    Point3d te2=new Point3d(x2,y2,z2);
    
    float x3=t.v3.xr2;
    float y3=t.v3.yr2+h;
    float z3=t.v3.zr2;
    Point3d te3=new Point3d(x3,y3,z3);
    
    //Point3d te1=new Point3d(0,0,5000);
    //Point3d te2=new Point3d(0,0,0);
    //Point3d te3=new Point3d(5000,0,0);
    if(t.v4==null){
    Triangle nt=new Triangle(te1,te2,te3);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_o_shot_5_l.add(nt);
    }
    
    if(t.v4!=null){
    
    float x4=t.v4.xr2;
    float y4=t.v4.yr2+h;
    float z4=t.v4.zr2;
    Point3d te4=new Point3d(x4,y4,z4);    
        
    Triangle nt=new Triangle(te1,te2,te3,te4);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_o_shot_5_l.add(nt);
    }
}
//character obstacle shot 5 left

//character obstacle shot 6 left
for(int q=0;q<R_3D.triangles_enemy_standing_obstacle_shot_6_l.size();q++)
{
    Triangle t=R_3D.triangles_enemy_standing_obstacle_shot_6_l.get(q);
    
    int h=1100;
    
    float x=t.v1.xr2;
    float y=t.v1.yr2+h;
    float z=t.v1.zr2;
    Point3d te1=new Point3d(x,y,z);
    
    float x2=t.v2.xr2;
    float y2=t.v2.yr2+h;
    float z2=t.v2.zr2;
    Point3d te2=new Point3d(x2,y2,z2);
    
    float x3=t.v3.xr2;
    float y3=t.v3.yr2+h;
    float z3=t.v3.zr2;
    Point3d te3=new Point3d(x3,y3,z3);
    
    //Point3d te1=new Point3d(0,0,5000);
    //Point3d te2=new Point3d(0,0,0);
    //Point3d te3=new Point3d(5000,0,0);
    if(t.v4==null){
    Triangle nt=new Triangle(te1,te2,te3);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_o_shot_6_l.add(nt);
    }
    
    if(t.v4!=null){
    
    float x4=t.v4.xr2;
    float y4=t.v4.yr2+h;
    float z4=t.v4.zr2;
    Point3d te4=new Point3d(x4,y4,z4);    
        
    Triangle nt=new Triangle(te1,te2,te3,te4);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_o_shot_6_l.add(nt);
    }
}
//character obstacle shot 6 left

//**************************************************************

//character obstacle shot 2 right
for(int q=0;q<R_3D.triangles_enemy_standing_obstacle_shot_2_r.size();q++)
{
    Triangle t=R_3D.triangles_enemy_standing_obstacle_shot_2_r.get(q);
    
    int h=1100;
    
    float x=t.v1.xr2;
    float y=t.v1.yr2+h;
    float z=t.v1.zr2;
    Point3d te1=new Point3d(x,y,z);
    
    float x2=t.v2.xr2;
    float y2=t.v2.yr2+h;
    float z2=t.v2.zr2;
    Point3d te2=new Point3d(x2,y2,z2);
    
    float x3=t.v3.xr2;
    float y3=t.v3.yr2+h;
    float z3=t.v3.zr2;
    Point3d te3=new Point3d(x3,y3,z3);
    
    //Point3d te1=new Point3d(0,0,5000);
    //Point3d te2=new Point3d(0,0,0);
    //Point3d te3=new Point3d(5000,0,0);
    if(t.v4==null){
    Triangle nt=new Triangle(te1,te2,te3);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_o_shot_2_r.add(nt);
    }
    
    if(t.v4!=null){
    
    float x4=t.v4.xr2;
    float y4=t.v4.yr2+h;
    float z4=t.v4.zr2;
    Point3d te4=new Point3d(x4,y4,z4);    
        
    Triangle nt=new Triangle(te1,te2,te3,te4);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_o_shot_2_r.add(nt);
    }
}
//character obstacle shot 2 right

//character obstacle shot 3 right
for(int q=0;q<R_3D.triangles_enemy_standing_obstacle_shot_3_r.size();q++)
{
    Triangle t=R_3D.triangles_enemy_standing_obstacle_shot_3_r.get(q);
    
    int h=1100;
    
    float x=t.v1.xr2;
    float y=t.v1.yr2+h;
    float z=t.v1.zr2;
    Point3d te1=new Point3d(x,y,z);
    
    float x2=t.v2.xr2;
    float y2=t.v2.yr2+h;
    float z2=t.v2.zr2;
    Point3d te2=new Point3d(x2,y2,z2);
    
    float x3=t.v3.xr2;
    float y3=t.v3.yr2+h;
    float z3=t.v3.zr2;
    Point3d te3=new Point3d(x3,y3,z3);
    
    //Point3d te1=new Point3d(0,0,5000);
    //Point3d te2=new Point3d(0,0,0);
    //Point3d te3=new Point3d(5000,0,0);
    if(t.v4==null){
    Triangle nt=new Triangle(te1,te2,te3);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_o_shot_3_r.add(nt);
    }
    
    if(t.v4!=null){
    
    float x4=t.v4.xr2;
    float y4=t.v4.yr2+h;
    float z4=t.v4.zr2;
    Point3d te4=new Point3d(x4,y4,z4);    
        
    Triangle nt=new Triangle(te1,te2,te3,te4);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_o_shot_3_r.add(nt);
    }
}
//character obstacle shot 3 right

//character obstacle shot 4 right
for(int q=0;q<R_3D.triangles_enemy_standing_obstacle_shot_4_r.size();q++)
{
    Triangle t=R_3D.triangles_enemy_standing_obstacle_shot_4_r.get(q);
    
    int h=1100;
    
    float x=t.v1.xr2;
    float y=t.v1.yr2+h;
    float z=t.v1.zr2;
    Point3d te1=new Point3d(x,y,z);
    
    float x2=t.v2.xr2;
    float y2=t.v2.yr2+h;
    float z2=t.v2.zr2;
    Point3d te2=new Point3d(x2,y2,z2);
    
    float x3=t.v3.xr2;
    float y3=t.v3.yr2+h;
    float z3=t.v3.zr2;
    Point3d te3=new Point3d(x3,y3,z3);
    
    //Point3d te1=new Point3d(0,0,5000);
    //Point3d te2=new Point3d(0,0,0);
    //Point3d te3=new Point3d(5000,0,0);
    if(t.v4==null){
    Triangle nt=new Triangle(te1,te2,te3);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_o_shot_4_r.add(nt);
    }
    
    if(t.v4!=null){
    
    float x4=t.v4.xr2;
    float y4=t.v4.yr2+h;
    float z4=t.v4.zr2;
    Point3d te4=new Point3d(x4,y4,z4);    
        
    Triangle nt=new Triangle(te1,te2,te3,te4);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_o_shot_4_r.add(nt);
    }
}
//character obstacle shot 4 right

//character obstacle shot 5 right
for(int q=0;q<R_3D.triangles_enemy_standing_obstacle_shot_5_r.size();q++)
{
    Triangle t=R_3D.triangles_enemy_standing_obstacle_shot_5_r.get(q);
    
    int h=1100;
    
    float x=t.v1.xr2;
    float y=t.v1.yr2+h;
    float z=t.v1.zr2;
    Point3d te1=new Point3d(x,y,z);
    
    float x2=t.v2.xr2;
    float y2=t.v2.yr2+h;
    float z2=t.v2.zr2;
    Point3d te2=new Point3d(x2,y2,z2);
    
    float x3=t.v3.xr2;
    float y3=t.v3.yr2+h;
    float z3=t.v3.zr2;
    Point3d te3=new Point3d(x3,y3,z3);
    
    //Point3d te1=new Point3d(0,0,5000);
    //Point3d te2=new Point3d(0,0,0);
    //Point3d te3=new Point3d(5000,0,0);
    if(t.v4==null){
    Triangle nt=new Triangle(te1,te2,te3);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_o_shot_5_r.add(nt);
    }
    
    if(t.v4!=null){
    
    float x4=t.v4.xr2;
    float y4=t.v4.yr2+h;
    float z4=t.v4.zr2;
    Point3d te4=new Point3d(x4,y4,z4);    
        
    Triangle nt=new Triangle(te1,te2,te3,te4);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_o_shot_5_r.add(nt);
    }
}
//character obstacle shot 5 right

//character obstacle shot 6 right
for(int q=0;q<R_3D.triangles_enemy_standing_obstacle_shot_6_r.size();q++)
{
    Triangle t=R_3D.triangles_enemy_standing_obstacle_shot_6_r.get(q);
    
    int h=1100;
    
    float x=t.v1.xr2;
    float y=t.v1.yr2+h;
    float z=t.v1.zr2;
    Point3d te1=new Point3d(x,y,z);
    
    float x2=t.v2.xr2;
    float y2=t.v2.yr2+h;
    float z2=t.v2.zr2;
    Point3d te2=new Point3d(x2,y2,z2);
    
    float x3=t.v3.xr2;
    float y3=t.v3.yr2+h;
    float z3=t.v3.zr2;
    Point3d te3=new Point3d(x3,y3,z3);
    
    //Point3d te1=new Point3d(0,0,5000);
    //Point3d te2=new Point3d(0,0,0);
    //Point3d te3=new Point3d(5000,0,0);
    if(t.v4==null){
    Triangle nt=new Triangle(te1,te2,te3);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_o_shot_6_r.add(nt);
    }
    
    if(t.v4!=null){
    
    float x4=t.v4.xr2;
    float y4=t.v4.yr2+h;
    float z4=t.v4.zr2;
    Point3d te4=new Point3d(x4,y4,z4);    
        
    Triangle nt=new Triangle(te1,te2,te3,te4);
    nt.tr_color=new Color(255,255,255);
    //nt.tr_color=t.tr_color;
    t_list_o_shot_6_r.add(nt);
    }
}
//character obstacle shot 6 right

//move_center(-500,-500,-500);
move_center(0,1000,0);
}

public void set_character_stand()
{
t_list=t_list_s;
}

public void set_character_crouch()
{
t_list=t_list_d;
}

public void set_character_shot()
{
t_list=t_list_shot;
}

public void set_character_reload()
{
t_list=t_list_reload;
}

public void set_character_obstacle_shot_left()
{
       
        double alpha=(360-R_3D.cube_angleY)*3.14/180;
        double move_x=Math.cos(alpha)*dist;
        double move_y=Math.sin(alpha)*dist;
    
       
    if(counter<=10){
        t_list=t_list_o_shot_5_l;
    }
    if(counter>10&&counter<=20){
        t_list=t_list_o_shot_4_l;
    }
    if(counter>20&&counter<=30){
        t_list=t_list_o_shot_3_l;
    }
    if(counter>30&&counter<=40){
        t_list=t_list_o_shot_2_l;
    }
    if(counter>40&&counter<=50){
        //t_list=t_list_o_shot_1;
    }
    
    if(counter>50&&counter<=65){
        //t_list=t_list_o_shot_1;
    }
    if(counter>60&&counter<=70){
        t_list=t_list_o_shot_2_l;
    }
    
    if(counter>70&&counter<=80){
        t_list=t_list_o_shot_3_l;
    }
    if(counter>80&&counter<=90){
        t_list=t_list_o_shot_4_l;
    }
    if(counter>90&&counter<=100){
        t_list=t_list_o_shot_5_l;
    }
    if(counter>100&&counter<=110){
        t_list=t_list_o_shot_6_l;
    }
    if(counter>110&&counter<120){
        t_list=t_list_o_shot_5_l;
    }
}

public void set_character_obstacle_shot_right()
{
       
        double alpha=(360-R_3D.cube_angleY)*3.14/180;
        double move_x=Math.cos(alpha)*dist;
        double move_y=Math.sin(alpha)*dist;
    
    if(counter<=10){
        t_list=t_list_o_shot_5_r;
    }
    if(counter>10&&counter<=20){
        t_list=t_list_o_shot_4_r;
    }
    if(counter>20&&counter<=30){
        t_list=t_list_o_shot_3_r;
    }
    if(counter>30&&counter<=40){
        t_list=t_list_o_shot_2_r;
    }
    
    if(counter>40&&counter<=50){
        //t_list=t_list_o_shot_1;
    }
    
    if(counter>50&&counter<=60){
        //t_list=t_list_o_shot_1;
    }
    
    if(counter>60&&counter<=70){
        t_list=t_list_o_shot_2_r;
    }
    
    if(counter>70&&counter<=80){
        t_list=t_list_o_shot_3_r;
    }
    if(counter>80&&counter<=90){
        t_list=t_list_o_shot_4_r;
    }
    if(counter>90&&counter<=100){
        t_list=t_list_o_shot_5_r;
    }
    if(counter>100&&counter<=110){
        t_list=t_list_o_shot_6_r;
    }
    if(counter>110&&counter<120){
        t_list=t_list_o_shot_5_r;
    }
        
}

public void set_character_roll_left()
{
       
        double alpha=(360-R_3D.cube_angleY)*3.14/180;
        double move_x=Math.cos(alpha)*dist;
        double move_y=Math.sin(alpha)*dist;
    
    if(counter<=10){
        t_list=t_list_d;
    }
    if(counter>10&&counter<=20){
        t_list=t_list_roll_1;
    }
    if(counter>20&&counter<=30){
        t_list=t_list_roll_2;
    }
    if(counter>30&&counter<=40){
        t_list=t_list_roll_3;
    }
    if(counter>40&&counter<=50){
        t_list=t_list_roll_4;
    }
    if(counter>50&&counter<=60){
        t_list=t_list_roll_5;
    }
    if(counter>60&&counter<70){
        t_list=t_list_d;
    }
    if(counter>=70){
        t_list=t_list_s;
    }
    if(counter<=60) move_character(-(float)move_x,0,(float)move_y);
    
}

public void set_character_roll_right()
{
       
        double alpha=(360-R_3D.cube_angleY)*3.14/180;
        double move_x=Math.cos(alpha)*dist*2;
        double move_y=Math.sin(alpha)*dist*2;
    
    if(counter<=10){
        t_list=t_list_d;
    }
    if(counter>10&&counter<=20){
        t_list=t_list_roll_5;
    }
    if(counter>20&&counter<=30){
        t_list=t_list_roll_4;
    }
    if(counter>30&&counter<=40){
        t_list=t_list_roll_3;
    }
    if(counter>40&&counter<=50){
        t_list=t_list_roll_2;
    }
    if(counter>50&&counter<=60){
        t_list=t_list_roll_1;
    }
    if(counter>60&&counter<70){
        t_list=t_list_d;
    }
    if(counter>=70){
        t_list=t_list_s;
    }
    if(counter<=60) move_character((float)move_x,0,-(float)move_y);
    
}

public void set_character_location(float a,float b,float c)
{
x=a;
y=b;
z=c;
}

public void update_character_ai()
{
counter++;


                        if(counter<30){
                            if(ai_set==0) move_character(-20,-20,-20);
                            if(ai_set==1) move_character(10,0,10);
                            if(ai_set==2) move_character(-50,0,0);
                            if(ai_set==3) move_character(dist,0,0);
                            if(ai_set==4) move_character(-dist,0,0);
                            if(ai_set==5) move_character(0,0,dist);
                            if(ai_set==6) move_character(0,0,-dist);
                            
                            if(ai_set==7) move_character(dist,0,dist);
                            if(ai_set==8) move_character(-dist,0,-dist);
                            if(ai_set==9) move_character(dist,0,-dist);
                            if(ai_set==10) move_character(-dist,0,dist);
                            if(ai_set==11) this.set_character_crouch();
                            if(ai_set==12) this.set_character_crouch();
                            if(ai_set==13) this.set_character_crouch();
                            
                            if(ai_set==14) this.set_character_roll_left();
                            if(ai_set==15) this.set_character_roll_left();
                            if(ai_set==16) this.set_character_roll_left();
                            
                            if(ai_set==17) this.set_character_roll_right();
                            if(ai_set==18) this.set_character_roll_right();
                            if(ai_set==19) this.set_character_roll_right();
                            
                            if(ai_set==20) this.set_character_shot();
                            if(ai_set==21) this.set_character_shot();
                            if(ai_set==22) this.set_character_shot();
                            
                            if(ai_set==23) this.set_character_obstacle_shot_left();
                            if(ai_set==24) this.set_character_obstacle_shot_left();
                            if(ai_set==25) this.set_character_obstacle_shot_left();
                            
                            if(ai_set==26) this.set_character_obstacle_shot_right();
                            if(ai_set==27) this.set_character_obstacle_shot_right();
                            if(ai_set==28) this.set_character_obstacle_shot_right();
                            
                        }
                        if(counter>30&&counter<=70){
                            
                            if(counter<=60){
                                if(ai_set==0) move_character(20,20,20);
                                if(ai_set==1) move_character(-10,0,-10);
                                if(ai_set==2) move_character(50,0,0);
                                if(ai_set==3) move_character(dist,0,0);
                                if(ai_set==4) move_character(-dist,0,0);
                                if(ai_set==5) move_character(0,0,dist);
                                if(ai_set==6) move_character(0,0,-dist);

                                if(ai_set==7) move_character(dist,0,dist);
                                if(ai_set==8) move_character(-dist,0,-dist);
                                if(ai_set==9) move_character(dist,0,-dist);
                                if(ai_set==10) move_character(-dist,0,dist);

                                if(ai_set==20) this.set_character_reload();
                                if(ai_set==21) this.set_character_reload();
                                if(ai_set==22) this.set_character_reload();
                            }
                            
                            if(ai_set==14) this.set_character_roll_left();
                            if(ai_set==15) this.set_character_roll_left();
                            if(ai_set==16) this.set_character_roll_left();
                            
                            if(ai_set==17) this.set_character_roll_right();
                            if(ai_set==18) this.set_character_roll_right();
                            if(ai_set==19) this.set_character_roll_right();
                            
                            if(ai_set==23) this.set_character_obstacle_shot_left();
                            if(ai_set==24) this.set_character_obstacle_shot_left();
                            if(ai_set==25) this.set_character_obstacle_shot_left();
                            
                            if(ai_set==26) this.set_character_obstacle_shot_right();
                            if(ai_set==27) this.set_character_obstacle_shot_right();
                            if(ai_set==28) this.set_character_obstacle_shot_right();
                        }
                        if(counter>70&&counter<120){
                        
                            if(ai_set==23) this.set_character_obstacle_shot_left();
                            if(ai_set==24) this.set_character_obstacle_shot_left();
                            if(ai_set==25) this.set_character_obstacle_shot_left();
                            
                            if(ai_set==26) this.set_character_obstacle_shot_right();
                            if(ai_set==27) this.set_character_obstacle_shot_right();
                            if(ai_set==28) this.set_character_obstacle_shot_right();
                            
                                if(ai_set!=23&&ai_set!=24&&ai_set!=25&&ai_set!=26&&ai_set!=27&&ai_set!=28){
                                        counter=0;
                                        //Random rnd=new Random(System.currentTimeMillis());
                                        int r=R_3D.rn.nextInt(25)+3;
                                        if(ai_set==11 || ai_set==12||ai_set==13||ai_set==20||ai_set==21||ai_set==22||ai_set==23||ai_set==24||ai_set==25||ai_set==26||ai_set==27||ai_set==28) this.set_character_stand();

                                        if(ai_set==3||ai_set==4||ai_set==5||ai_set==6||ai_set==7||ai_set==8||ai_set==9||ai_set==10||
                                                ai_set==11||ai_set==12||ai_set==13||ai_set==14||ai_set==15||ai_set==16||ai_set==17||
                                                ai_set==18||ai_set==19||ai_set==20||ai_set==21||ai_set==22||ai_set==23||ai_set==24||ai_set==25||ai_set==26||ai_set==27||ai_set==28){ai_set=r;}

                                        r=R_3D.rn.nextInt(5)+1;

                                        //if(r==1) dist=15;
                                        if(r==1) dist=20;
                                        if(r==2) dist=20;
                                        if(r==3) dist=20;
                                        if(r==4) dist=20;
                                        if(r==5) dist=20;
                                        if(r==6) dist=20;
                                }
                        }
                        
                        if(counter>=120)
                        {
                        counter=0;
                                        //Random rnd=new Random(System.currentTimeMillis());
                                        int r=R_3D.rn.nextInt(25)+3;
                                        if(ai_set==23||ai_set==24||ai_set==25||ai_set==26||ai_set==27||ai_set==28) this.set_character_stand();

                                        if(ai_set==23||ai_set==24||ai_set==25||ai_set==26||ai_set==27||ai_set==28){ai_set=r;}

                                        r=R_3D.rn.nextInt(5)+1;

                                        //if(r==1) dist=15;
                                        if(r==1) dist=20;
                                        if(r==2) dist=20;
                                        if(r==3) dist=20;
                                        if(r==4) dist=20;
                                        if(r==5) dist=20;
                                        if(r==6) dist=20;
                        }
                        
}

public void move_character(float a,float b,float c)
{
x=x+a;
y=y+b;
z=z+c;
}

public void move_center(float a,float b,float c)
{

for(int q=0;q<t_list.size();q++)
    {
    Triangle t=t_list.get(q);
   
    t.v1.xo=t.v1.xo+a;
    t.v1.yo=t.v1.yo+b;
    t.v1.zo=t.v1.zo+c;
    
    t.v2.xo=t.v2.xo+a;
    t.v2.yo=t.v2.yo+b;
    t.v2.zo=t.v2.zo+c;
    
    t.v3.xo=t.v3.xo+a;
    t.v3.yo=t.v3.yo+b;
    t.v3.zo=t.v3.zo+c;
    
    if(t.v4!=null){
        t.v4.xo=t.v4.xo+a;
        t.v4.yo=t.v4.yo+b;
        t.v4.zo=t.v4.zo+c;
    }
    
    }

}




}
