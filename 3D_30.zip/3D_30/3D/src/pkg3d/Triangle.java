//Mateusz Pawlowski. 3D Software Renderer. 2023.

package pkg3d;

import java.util.ArrayList;


/**
 *
 * @author M
 */
public class Triangle implements Comparable{

Point3d v1=null;
Point3d v2=null;
Point3d v3=null;
Point3d v4=null;

Float z;


Vect A=null;
Vect B=null;

int m=100;

boolean minus=false;
Vect vo=new Vect(0,0,1);

public static int total_trianles_number=0;
int triangle_number=0;


public Triangle(Point3d v1,Point3d v2,Point3d v3)
{
total_trianles_number++;
this.triangle_number=total_trianles_number;


this.v1=v1;
this.v2=v2;
this.v3=v3;

//z=v1.zr2;
z=(v1.zr2+v2.zr2+v3.zr2)/3;
}

public Triangle(Point3d v1,Point3d v2,Point3d v3,Point3d v4)
{
total_trianles_number++;
this.triangle_number=total_trianles_number;

    
this.v1=v1;
this.v2=v2;
this.v3=v3;
this.v4=v4;
//this.v4.calculate2dpoint();

z=(v1.zr2+v2.zr2+v3.zr2)/3;
//z=v1.zr2;
}

    @Override
    public int compareTo(Object o) {
        int wynik=-1;
        if (((Triangle)o).z>(this.z)) wynik=1;
        
        //System.out.println(((Triangle)o).z);
        //System.out.println(this.z);
        
        return wynik;
    }
    
public float calculateNormal()
{
float n=0;


//A=new Vect(v1.xr2-v2.xr2,v1.yr2-v2.yr2,v1.zr2-v2.zr2);
//B=new Vect(v1.xr2-v3.xr2,v1.yr2-v3.yr2,v1.zr2-v3.zr2);

A=new Vect(v2.xr2-v1.xr2,v2.yr2-v1.yr2,v2.zr2-v1.zr2);
B=new Vect(v3.xr2-v1.xr2,v3.yr2-v1.yr2,v3.zr2-v1.zr2);

double l=Math.sqrt((double)(A.x*A.x+A.y*A.y+A.z*A.z));
A.x=(float)(A.x/l);
A.y=(float)(A.y/l);
A.z=(float)(A.z/l);

double l2=Math.sqrt((double)(B.x*B.x+B.y*B.y+B.z*B.z));
B.x=(float)(B.x/l2);
B.y=(float)(B.y/l2);
B.z=(float)(B.z/l2);


Vect vn=Vect.getNormal(A, B);

vn.x=vn.x*m;
vn.y=vn.y*m;
vn.z=vn.z*m;

if(minus==false){
vo=new Vect(0,0,1);
n=Vect.getDotProduct(vn, vo);
} else
{
vo=new Vect(0,0,-1);
n=Vect.getDotProduct(vn, vo);
}


return n;
}

}
